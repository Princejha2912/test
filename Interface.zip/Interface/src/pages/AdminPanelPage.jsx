
import React from "react";
import AdminPanel from "../components/AdminPanel";

const AdminPanelPage = () => {
  return (
    <div>
      <AdminPanel />
    </div>
  );
};

export default AdminPanelPage;
