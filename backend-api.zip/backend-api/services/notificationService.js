const Notification = require('../models/simpleNotification');
const { sendEmail } = require('../util/nodeMailer');
const logger = require('../logger/logger');

/**
 * Simple Notification Service - Easy to Use
 */
class NotificationService {

  /**
   * Create a simple notification
   */
  static async createNotification(userId, type, title, message, amount = null, relatedId = null) {
    try {
      logger.info(`📢 Creating notification: ${type} for user ${userId}`);

      const notification = await Notification.createForUser(
        userId,
        type,
        title,
        message,
        amount,
        relatedId
      );

      // Try to send email to user
      try {
        await this.sendSimpleEmail(userId, title, message);
      } catch (emailError) {
        logger.error(`Email failed: ${emailError.message}`);
      }

      // Also notify admins for important events
      try {
        await this.notifyAdminsIfImportant(type, title, message, amount, relatedId, userId);
      } catch (adminError) {
        logger.error(`Admin notification failed: ${adminError.message}`);
      }

      logger.info(`✅ Notification created: ${notification._id}`);
      return notification;

    } catch (error) {
      logger.error(`❌ Failed to create notification: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create deposit notification
   */


  /**
   * Create withdrawal notification
   */
  static async createWithdrawalNotification(userId, type, withdrawalId, amount) {
    const titles = {
      'withdrawal_approved': 'Withdrawal Approved',
      'withdrawal_rejected': 'Withdrawal Rejected'
    };

    const messages = {
      'withdrawal_approved': `Your withdrawal of ${amount} USDT has been approved.`,
      'withdrawal_rejected': `Your withdrawal of ${amount} USDT has been rejected.`
    };

    return this.createNotification(
      userId,
      type,
      titles[type],
      messages[type],
      amount,
      withdrawalId
    );
  }

  /**
   * Create merchant notification
   */
  static async createMerchantNotification(userId, type) {
    const titles = {
      'merchant_approved': 'Account Approved',
      'merchant_blocked': 'Account Blocked'
    };

    const messages = {
      'merchant_approved': 'Your merchant account has been approved. You can now start accepting payments.',
      'merchant_blocked': 'Your merchant account has been blocked. Please contact support.'
    };

    return this.createNotification(
      userId,
      type,
      titles[type],
      messages[type]
    );
  }

  /**
   * Notify admins for important events
   */
  static async notifyAdminsIfImportant(type, title, message, amount, relatedId, userId) {
    try {
      // Define which events should notify admins
      const adminNotificationTypes = [
        'deposit_success',
        'deposit_failed',
        'withdrawal_approved',
        'withdrawal_rejected',
        'merchant_approved',
        'merchant_blocked'
      ];

      if (!adminNotificationTypes.includes(type)) {
        return; // Not an important event for admins
      }

      // Get user info for context
      const User = require('../models/user');
      const user = await User.findById(userId);
      const userName = user ? user.name || user.email : 'Unknown User';

      // Get all admins and superadmins
      const admins = await User.find({
        role: { $in: ['admin', 'superadmin'] }
      });

      if (admins.length === 0) {
        logger.warn('No admins found to notify');
        return;
      }

      // Create admin notification title and message
      const adminTitle = `[ADMIN ALERT] ${title}`;
      const adminMessage = `${message}\n\nUser: ${userName}\nAmount: ${amount ? amount + ' USDT' : 'N/A'}\nReference: ${relatedId || 'N/A'}`;

      // Send email to all admins
      for (const admin of admins) {
        try {
          await this.sendAdminEmail(admin.email, adminTitle, adminMessage, type);
          logger.info(`✅ Admin notification sent to: ${admin.email}`);
        } catch (emailError) {
          logger.error(`❌ Failed to send admin email to ${admin.email}: ${emailError.message}`);
        }
      }

    } catch (error) {
      logger.error(`❌ Failed to notify admins: ${error.message}`);
    }
  }

  /**
   * Send simple email
   */
  static async sendSimpleEmail(userId, title, message) {
    try {
      // Get user email
      const User = require('../models/user');
      const user = await User.findById(userId);

      if (!user) {
        throw new Error('User not found');
      }

      logger.info(`📧 Sending email to ${user.email}`);

      await sendEmail({
        to: user.email,
        subject: title,
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2>${title}</h2>
            <p>${message}</p>
            <hr>
            <small>Crypto Payment Gateway</small>
          </div>
        `
      });

      logger.info(`✅ Email sent to ${user.email}`);

    } catch (error) {
      logger.error(`❌ Failed to send email: ${error.message}`);
      throw error;
    }
  }

  /**
   * Send admin email with enhanced formatting
   */
  static async sendAdminEmail(adminEmail, title, message, type) {
    try {
      // Get priority color based on type
      const priorityColors = {
        'deposit_failed': '#ff4444',
        'withdrawal_rejected': '#ff4444',
        'merchant_blocked': '#ff4444',
        'deposit_success': '#44ff44',
        'withdrawal_approved': '#44ff44',
        'merchant_approved': '#44ff44'
      };

      const color = priorityColors[type] || '#4444ff';
      const priority = ['deposit_failed', 'withdrawal_rejected', 'merchant_blocked'].includes(type) ? 'HIGH' : 'NORMAL';

      await sendEmail({
        to: adminEmail,
        subject: title,
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px; border-left: 4px solid ${color};">
            <div style="background-color: #f5f5f5; padding: 15px; margin-bottom: 20px;">
              <h2 style="margin: 0; color: ${color};">${title}</h2>
              <span style="background-color: ${color}; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                PRIORITY: ${priority}
              </span>
            </div>
            <div style="background-color: white; padding: 15px; border: 1px solid #ddd;">
              <pre style="white-space: pre-wrap; font-family: Arial, sans-serif;">${message}</pre>
            </div>
            <hr style="margin: 20px 0;">
            <small style="color: #666;">
              Crypto Payment Gateway - Admin Notification System<br>
              Time: ${new Date().toLocaleString()}
            </small>
          </div>
        `
      });

    } catch (error) {
      logger.error(`❌ Failed to send admin email: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get user notifications
   */
  static async getUserNotifications(userId, options = {}) {
    try {
      const { page = 1, limit = 20, unreadOnly = false } = options;

      const filter = { userId };
      if (unreadOnly) filter.isRead = false;

      const notifications = await Notification.find(filter)
        .sort({ createdAt: -1 })
        .limit(limit * 1)
        .skip((page - 1) * limit);

      const total = await Notification.countDocuments(filter);

      return {
        notifications,
        pagination: {
          total,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(total / limit)
        }
      };

    } catch (error) {
      logger.error(`❌ Failed to get user notifications: ${error.message}`);
      throw error;
    }
  }

  /**
   * Mark notification as read
   */
  static async markAsRead(notificationId, userId) {
    try {
      const notification = await Notification.markAsRead(notificationId, userId);

      if (!notification) {
        throw new Error('Notification not found');
      }

      logger.info(`✅ Notification marked as read: ${notificationId}`);
      return notification;

    } catch (error) {
      logger.error(`❌ Failed to mark notification as read: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get simple notification stats
   */
  static async getNotificationStats(userId) {
    try {
      const total = await Notification.countDocuments({ userId });
      const unread = await Notification.getUnreadCount(userId);
      const read = total - unread;

      return {
        total,
        unread,
        read
      };

    } catch (error) {
      logger.error(`❌ Failed to get notification stats: ${error.message}`);
      throw error;
    }
  }

  /**
   * Send immediate admin alert (for critical events)
   */
  static async sendAdminAlert(alertType, message, data = {}) {
    try {
      logger.info(`🚨 Sending admin alert: ${alertType}`);

      // Get all admins and superadmins
      const User = require('../models/user');
      const admins = await User.find({
        role: { $in: ['admin', 'superadmin'] }
      });

      if (admins.length === 0) {
        logger.warn('No admins found for alert');
        return;
      }

      const alertTitle = `🚨 CRITICAL ALERT: ${alertType}`;
      const alertMessage = `${message}\n\nData: ${JSON.stringify(data, null, 2)}\nTime: ${new Date().toLocaleString()}`;

      // Send to all admins
      for (const admin of admins) {
        try {
          // Create notification in database
          await Notification.createForUser(
            admin._id,
            'admin_alert',
            alertTitle,
            alertMessage
          );

          // Send immediate email
          await this.sendAdminEmail(admin.email, alertTitle, alertMessage, 'admin_alert');

          logger.info(`✅ Critical alert sent to admin: ${admin.email}`);
        } catch (error) {
          logger.error(`❌ Failed to send alert to ${admin.email}: ${error.message}`);
        }
      }

    } catch (error) {
      logger.error(`❌ Failed to send admin alert: ${error.message}`);
    }
  }

}

module.exports = NotificationService;
