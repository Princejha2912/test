// Service Layer Index - Central export for all services
const UserService = require('./userService');
const DepositService = require('./depositService');
const WithdrawalService = require('./withdrawalService');

module.exports = {
  UserService,
  DepositService,
  WithdrawalService
};
