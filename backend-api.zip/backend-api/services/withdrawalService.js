const Withdrawal = require('../models/withdrawal');
const User = require('../models/user');
const FeeSetting = require('../models/FeeSetting');
const logger = require('../logger/logger');

class WithdrawalService {
  constructor() {
    logger.info('💼 Withdrawal Service initialized');
  }

  /**
   * Create withdrawal request
   * @param {Object} data - Withdrawal data
   * @returns {Object} Created withdrawal
   */
  async createWithdrawal(data) {
    try {
      const { clientId, amount, clientWallet, clientReference } = data;

      // Validate client exists and get balance
      const client = await User.findById(clientId);
      if (!client) {
        throw new Error('Client not found');
      }

      // Check if client has sufficient balance
      if (client.totalAmt < amount) {
        throw new Error(`Insufficient balance. Available: ${client.totalAmt} USDT, Requested: ${amount} USDT`);
      }

      // Get fee setting (use default if not found)
      let fee = 0;
      try {
        const feeSetting = await FeeSetting.findOne({ isActive: true });
        if (feeSetting) {
          if (feeSetting.type === 'percentage') {
            fee = (amount * feeSetting.value) / 100;
          } else {
            fee = feeSetting.value;
          }
        }
      } catch (error) {
        logger.warn('No fee setting found, using 0 fee');
      }

      // Calculate net amount
      const netAmount = amount - fee;

      if (netAmount <= 0) {
        throw new Error('Net amount after fee deduction must be greater than 0');
      }

      // Create withdrawal
      const withdrawal = new Withdrawal({
        clientId,
        amount,
        fee,
        netAmount,
        clientWallet,
        clientReference,
        status: 'pending'
      });

      await withdrawal.save();

      logger.info(`✅ Withdrawal created: ${withdrawal._id} for client ${clientId}, amount: ${amount} USDT, fee: ${fee} USDT`);

      return {
        withdrawalId: withdrawal._id,
        amount: withdrawal.amount,
        fee: withdrawal.fee,
        netAmount: withdrawal.netAmount,
        clientWallet: withdrawal.clientWallet,
        status: withdrawal.status,
        createdAt: withdrawal.createdAt
      };
    } catch (error) {
      logger.error(`❌ Error creating withdrawal: ${error.message}`);
      throw error;
    }
  }

  /**
   * Approve withdrawal (Admin only)
   * @param {string} withdrawalId - Withdrawal ID
   * @param {string} adminId - Admin ID
   * @param {string} adminNotes - Admin notes
   * @returns {Object} Updated withdrawal
   */
  async approveWithdrawal(withdrawalId, adminId, adminNotes = '') {
    try {
      const withdrawal = await Withdrawal.findById(withdrawalId);
      if (!withdrawal) {
        throw new Error('Withdrawal not found');
      }

      if (withdrawal.status !== 'pending') {
        throw new Error(`Cannot approve withdrawal with status: ${withdrawal.status}`);
      }

      // Update withdrawal
      withdrawal.status = 'approved';
      withdrawal.processedAt = new Date();
      withdrawal.processedBy = adminId;
      withdrawal.adminNotes = adminNotes;
      await withdrawal.save();

      // Deduct amount from client balance
      await User.findByIdAndUpdate(withdrawal.clientId, {
        $inc: { totalAmt: -withdrawal.amount }
      });

      logger.info(`✅ Withdrawal approved: ${withdrawalId} by admin ${adminId}`);

      return {
        withdrawalId: withdrawal._id,
        status: withdrawal.status,
        processedAt: withdrawal.processedAt,
        adminNotes: withdrawal.adminNotes
      };
    } catch (error) {
      logger.error(`❌ Error approving withdrawal: ${error.message}`);
      throw error;
    }
  }

  /**
   * Reject withdrawal (Admin only)
   * @param {string} withdrawalId - Withdrawal ID
   * @param {string} adminId - Admin ID
   * @param {string} adminNotes - Admin notes
   * @returns {Object} Updated withdrawal
   */
  async rejectWithdrawal(withdrawalId, adminId, adminNotes = '') {
    try {
      const withdrawal = await Withdrawal.findById(withdrawalId);
      if (!withdrawal) {
        throw new Error('Withdrawal not found');
      }

      if (withdrawal.status !== 'pending') {
        throw new Error(`Cannot reject withdrawal with status: ${withdrawal.status}`);
      }

      // Update withdrawal
      withdrawal.status = 'rejected';
      withdrawal.processedAt = new Date();
      withdrawal.processedBy = adminId;
      withdrawal.adminNotes = adminNotes;
      await withdrawal.save();

      logger.info(`❌ Withdrawal rejected: ${withdrawalId} by admin ${adminId}`);

      return {
        withdrawalId: withdrawal._id,
        status: withdrawal.status,
        processedAt: withdrawal.processedAt,
        adminNotes: withdrawal.adminNotes
      };
    } catch (error) {
      logger.error(`❌ Error rejecting withdrawal: ${error.message}`);
      throw error;
    }
  }

  /**
   * Complete withdrawal (mark as completed after blockchain transfer)
   * @param {string} withdrawalId - Withdrawal ID
   * @param {string} blockchainTxHash - Blockchain transaction hash
   * @returns {Object} Updated withdrawal
   */
  async completeWithdrawal(withdrawalId, blockchainTxHash) {
    try {
      const withdrawal = await Withdrawal.findById(withdrawalId);
      if (!withdrawal) {
        throw new Error('Withdrawal not found');
      }

      if (withdrawal.status !== 'approved') {
        throw new Error(`Cannot complete withdrawal with status: ${withdrawal.status}`);
      }

      // Update withdrawal
      withdrawal.status = 'completed';
      withdrawal.blockchainTxHash = blockchainTxHash;
      await withdrawal.save();

      logger.info(`✅ Withdrawal completed: ${withdrawalId}, txHash: ${blockchainTxHash}`);

      return {
        withdrawalId: withdrawal._id,
        status: withdrawal.status,
        blockchainTxHash: withdrawal.blockchainTxHash
      };
    } catch (error) {
      logger.error(`❌ Error completing withdrawal: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get client withdrawals with pagination
   * @param {string} clientId - Client ID
   * @param {Object} options - Query options
   * @returns {Object} Withdrawals list
   */
  async getClientWithdrawals(clientId, options = {}) {
    try {
      const { page = 1, limit = 20, status } = options;
      const skip = (page - 1) * limit;

      // Build query
      const query = { clientId };
      if (status) query.status = status;

      // Get withdrawals
      const withdrawals = await Withdrawal.find(query)
        .populate('processedBy', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean();

      const total = await Withdrawal.countDocuments(query);

      return {
        withdrawals,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalRecords: total,
          limit: parseInt(limit)
        }
      };
    } catch (error) {
      logger.error(`❌ Error getting client withdrawals: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get all withdrawals for admin (with pagination)
   * @param {Object} options - Query options
   * @returns {Object} All withdrawals
   */
  async getAllWithdrawals(options = {}) {
    try {
      const { page = 1, limit = 20, status, clientId } = options;
      const skip = (page - 1) * limit;

      // Build query
      const query = {};
      if (status) query.status = status;
      if (clientId) query.clientId = clientId;

      // Get withdrawals with client and admin info
      const withdrawals = await Withdrawal.find(query)
        .populate('clientId', 'name email walletAddress')
        .populate('processedBy', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean();

      const total = await Withdrawal.countDocuments(query);

      return {
        withdrawals,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalRecords: total,
          limit: parseInt(limit)
        }
      };
    } catch (error) {
      logger.error(`❌ Error getting all withdrawals: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get withdrawal statistics
   * @param {string} clientId - Client ID (optional)
   * @returns {Object} Statistics
   */
  async getWithdrawalStats(clientId = null) {
    try {
      const matchQuery = clientId ? { clientId: require('mongoose').Types.ObjectId(clientId) } : {};

      const stats = await Withdrawal.aggregate([
        { $match: matchQuery },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            totalAmount: { $sum: '$amount' },
            totalFee: { $sum: '$fee' },
            totalNetAmount: { $sum: '$netAmount' }
          }
        }
      ]);

      const result = {
        totalWithdrawals: 0,
        pendingWithdrawals: 0,
        approvedWithdrawals: 0,
        completedWithdrawals: 0,
        rejectedWithdrawals: 0,
        totalAmount: 0,
        totalFees: 0,
        totalNetAmount: 0
      };

      stats.forEach(stat => {
        result.totalWithdrawals += stat.count;
        result.totalAmount += stat.totalAmount;
        result.totalFees += stat.totalFee;
        result.totalNetAmount += stat.totalNetAmount;

        switch (stat._id) {
          case 'pending':
            result.pendingWithdrawals = stat.count;
            break;
          case 'approved':
            result.approvedWithdrawals = stat.count;
            break;
          case 'completed':
            result.completedWithdrawals = stat.count;
            break;
          case 'rejected':
            result.rejectedWithdrawals = stat.count;
            break;
        }
      });

      return result;
    } catch (error) {
      logger.error(`❌ Error getting withdrawal stats: ${error.message}`);
      throw error;
    }
  }
}

module.exports = new WithdrawalService();
