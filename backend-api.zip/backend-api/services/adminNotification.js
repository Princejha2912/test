const NotificationService = require('./notificationService');
const User = require('../models/user');
const logger = require('../logger/logger');

/**
 * Admin Notification Service
 * Handles notifications to Super Admin and other admin users
 */
class AdminNotificationService {

  /**
   * Notify Super Admin about successful deposit
   */
  static async notifyDepositSuccess(transaction, merchant) {
    try {
      logger.info(`📢 Notifying Super Admin about successful deposit: ${transaction.transactionId}`);

      // Get all super admin users
      const superAdmins = await User.find({ role: 'superadmin' });

      for (const admin of superAdmins) {
        await NotificationService.createNotification(
          admin._id,
          'deposit_success',
          `Deposit Confirmed - ${transaction.amount} USDT`,
          `Merchant ${merchant.name} deposited ${transaction.amount} USDT. ID: ${transaction.transactionId}`,
          transaction.amount,
          transaction.transactionId
        );
      }

      logger.info(`✅ Super Admin notified about successful deposit: ${transaction.transactionId}`);

    } catch (error) {
      logger.error(`❌ Failed to notify Super Admin about deposit success: ${error.message}`);
    }
  }

  /**
   * Notify Super Admin about failed deposit
   */
  static async notifyDepositFailed(transaction, merchant) {
    try {
      logger.info(`📢 Notifying Super Admin about failed deposit: ${transaction.transactionId}`);

      // Get all super admin users
      const superAdmins = await User.find({ role: 'superadmin' });

      for (const admin of superAdmins) {
        await NotificationService.createNotification(
          admin._id,
          'deposit_failed',
          `Deposit Failed - ${transaction.amount} USDT`,
          `Merchant ${merchant.name} deposit of ${transaction.amount} USDT failed. ID: ${transaction.transactionId}`,
          transaction.amount,
          transaction.transactionId
        );
      }

      logger.info(`✅ Super Admin notified about failed deposit: ${transaction.transactionId}`);

    } catch (error) {
      logger.error(`❌ Failed to notify Super Admin about deposit failure: ${error.message}`);
    }
  }

  /**
   * Notify admins about new withdrawal request
   */
  static async notifyWithdrawalRequest(withdrawal, merchant) {
    try {
      logger.info(`📢 Notifying admins about withdrawal request: ${withdrawal._id}`);

      // Get all admin and super admin users
      const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } });

      for (const admin of admins) {
        await NotificationService.createNotification(
          admin._id,
          'admin_alert',
          `New Withdrawal Request - ${withdrawal.amount} USDT`,
          `Merchant ${merchant.name} requested withdrawal of ${withdrawal.amount} USDT. Please review.`,
          withdrawal.amount,
          withdrawal._id.toString()
        );
      }

      logger.info(`✅ Admins notified about withdrawal request: ${withdrawal._id}`);

    } catch (error) {
      logger.error(`❌ Failed to notify admins about withdrawal request: ${error.message}`);
    }
  }

}

module.exports = AdminNotificationService;
