const Deposit = require('../models/depositeAmt');
const User = require('../models/user');
const logger = require('../logger/logger');

class DepositService {
  constructor() {
    logger.info('💼 Deposit Service initialized');
  }

  /**
   * Create a new deposit transaction
   * @param {Object} data - Deposit data
   * @returns {Object} Created deposit
   */
  async createDeposit(data) {
    try {
      const { clientId, amount, currencyType = 'USDT-TRC20', walletAddress, clientReference } = data;

      // Validate client exists
      const client = await User.findById(clientId);
      if (!client) {
        throw new Error('Client not found');
      }

      // Generate unique transaction ID
      const transactionId = this.generateTransactionId();

      // Create deposit
      const deposit = new Deposit({
        transactionId,
        clientId,
        amount,
        currencyType,
        walletAddress,
        clientReference,
        status: 'initiated'
      });

      await deposit.save();

      logger.info(`✅ Deposit created: ${transactionId} for client ${clientId}, amount: ${amount} USDT`);

      return {
        transactionId: deposit.transactionId,
        amount: deposit.amount,
        currencyType: deposit.currencyType,
        walletAddress: deposit.walletAddress,
        status: deposit.status,
        expiresAt: deposit.expiresAt,
        timeRemaining: deposit.timeRemaining
      };
    } catch (error) {
      logger.error(`❌ Error creating deposit: ${error.message}`);
      throw error;
    }
  }

  /**
   * Confirm deposit transaction
   * @param {string} walletAddress - Wallet address
   * @param {string} clientId - Client ID
   * @returns {Object} Confirmation result
   */
  async confirmDeposit(walletAddress, clientId) {
    try {
      // Find deposit by wallet address and client
      const deposit = await Deposit.findOne({
        walletAddress,
        clientId,
        status: 'initiated'
      });

      if (!deposit) {
        throw new Error('Deposit not found or already processed');
      }

      // Check if expired
      if (deposit.isExpired) {
        deposit.status = 'expired';
        await deposit.save();
        throw new Error('Deposit has expired (10 minutes timeout)');
      }

      // Update deposit status
      deposit.status = 'confirmed';
      deposit.confirmedAt = new Date();
      await deposit.save();

      // Update client total amount
      await User.findByIdAndUpdate(clientId, {
        $inc: { totalAmt: deposit.amount }
      });

      logger.info(`✅ Deposit confirmed: ${deposit.transactionId}, amount: ${deposit.amount} USDT`);

      return {
        transactionId: deposit.transactionId,
        status: 'confirmed',
        amount: deposit.amount,
        confirmedAt: deposit.confirmedAt
      };
    } catch (error) {
      logger.error(`❌ Error confirming deposit: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get deposit status
   * @param {string} transactionId - Transaction ID
   * @param {string} clientId - Client ID
   * @returns {Object} Deposit status
   */
  async getDepositStatus(transactionId, clientId) {
    try {
      const deposit = await Deposit.findOne({
        transactionId,
        clientId
      });

      if (!deposit) {
        throw new Error('Deposit not found');
      }

      return {
        transactionId: deposit.transactionId,
        status: deposit.status,
        amount: deposit.amount,
        currencyType: deposit.currencyType,
        walletAddress: deposit.walletAddress,
        createdAt: deposit.createdAt,
        confirmedAt: deposit.confirmedAt,
        expiresAt: deposit.expiresAt,
        timeRemaining: deposit.timeRemaining,
        isExpired: deposit.isExpired
      };
    } catch (error) {
      logger.error(`❌ Error getting deposit status: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get client deposits with pagination
   * @param {string} clientId - Client ID
   * @param {Object} options - Query options
   * @returns {Object} Deposits list
   */
  async getClientDeposits(clientId, options = {}) {
    try {
      const { page = 1, limit = 20, status } = options;
      const skip = (page - 1) * limit;

      // Build query
      const query = { clientId };
      if (status) query.status = status;

      // Get deposits
      const deposits = await Deposit.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean();

      const total = await Deposit.countDocuments(query);

      return {
        deposits,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalRecords: total,
          limit: parseInt(limit)
        }
      };
    } catch (error) {
      logger.error(`❌ Error getting client deposits: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get client deposit statistics
   * @param {string} clientId - Client ID
   * @returns {Object} Statistics
   */
  async getClientDepositStats(clientId) {
    try {
      const stats = await Deposit.aggregate([
        { $match: { clientId: require('mongoose').Types.ObjectId(clientId) } },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            totalAmount: { $sum: '$amount' }
          }
        }
      ]);

      const result = {
        totalDeposits: 0,
        confirmedDeposits: 0,
        pendingDeposits: 0,
        failedDeposits: 0,
        totalAmount: 0,
        confirmedAmount: 0
      };

      stats.forEach(stat => {
        result.totalDeposits += stat.count;
        if (stat._id === 'confirmed') {
          result.confirmedDeposits = stat.count;
          result.confirmedAmount = stat.totalAmount;
          result.totalAmount += stat.totalAmount;
        } else if (stat._id === 'initiated') {
          result.pendingDeposits += stat.count;
        } else {
          result.failedDeposits += stat.count;
        }
      });

      return result;
    } catch (error) {
      logger.error(`❌ Error getting deposit stats: ${error.message}`);
      throw error;
    }
  }

  /**
   * Expire old deposits (cleanup job)
   */
  async expireOldDeposits() {
    try {
      const result = await Deposit.updateMany(
        {
          status: 'initiated',
          expiresAt: { $lte: new Date() }
        },
        { status: 'expired' }
      );

      if (result.modifiedCount > 0) {
        logger.info(`🧹 Expired ${result.modifiedCount} old deposits`);
      }

      return result.modifiedCount;
    } catch (error) {
      logger.error(`❌ Error expiring old deposits: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate unique transaction ID
   * @returns {string} Transaction ID
   */
  generateTransactionId() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `dep_${timestamp}_${random}`;
  }

  /**
   * Get all deposits for admin (with pagination)
   * @param {Object} options - Query options
   * @returns {Object} All deposits
   */
  async getAllDeposits(options = {}) {
    try {
      const { page = 1, limit = 20, status, clientId } = options;
      const skip = (page - 1) * limit;

      // Build query
      const query = {};
      if (status) query.status = status;
      if (clientId) query.clientId = clientId;

      // Get deposits with client info
      const deposits = await Deposit.find(query)
        .populate('clientId', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean();

      const total = await Deposit.countDocuments(query);

      return {
        deposits,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalRecords: total,
          limit: parseInt(limit)
        }
      };
    } catch (error) {
      logger.error(`❌ Error getting all deposits: ${error.message}`);
      throw error;
    }
  }
}

module.exports = new DepositService();
