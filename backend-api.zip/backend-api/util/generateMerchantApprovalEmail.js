module.exports.generateMerchantApprovalEmail = function ({
  name,
  email,
  password,
  apiKey,
  apiSecret,
  walletAddress,
  walletNetwork,
  walletGenerated,
  walletGeneratedAt,
  feeType,
  feeValue
}) {
  const walletSection = walletGenerated ? `
      <h3>💰 Your Merchant Wallet</h3>
      <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
        <ul>
          <li><strong>Wallet Address:</strong> <code style="background-color: #e9ecef; padding: 2px 4px; border-radius: 3px;">${walletAddress}</code></li>
          <li><strong>Network:</strong> ${walletNetwork}</li>
          <li><strong>Generated:</strong> ${walletGeneratedAt ? new Date(walletGeneratedAt).toLocaleString() : 'Just now'}</li>
        </ul>
        <p style="color: #28a745; font-weight: bold;">✅ Wallet successfully generated and ready for use!</p>
      </div>
  ` : `
      <h3>💰 Merchant Wallet</h3>
      <div style="background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0; border-left: 4px solid #ffc107;">
        <p style="color: #856404; margin: 0;">⚠️ Wallet generation failed. Please contact support for manual wallet setup.</p>
      </div>
  `;

  const feeSection = `
      <h3>💸 Transaction Fee</h3>
      <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
        <ul>
          <li><strong>Fee Type:</strong> ${feeType === 'percentage' ? 'Percentage' : 'Flat'}</li>
          <li><strong>Fee Value:</strong> ${feeType === 'percentage' ? `${feeValue}%` : `${feeValue} USDT`}</li>
        </ul>
        <p style="color: #6c757d; font-size: 14px; margin: 0;">This fee will be applied on each transaction processed through your account.</p>
      </div>
  `;

  return `
    <div style="font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;">
      <div style="background-color: #28a745; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;">
        <h2 style="margin: 0;">✅ Merchant Account Approved</h2>
      </div>

      <div style="padding: 20px; border: 1px solid #dee2e6; border-top: none; border-radius: 0 0 5px 5px;">
        <p>Dear <strong>${name}</strong>,</p>

        <p>Congratulations! Your merchant account has been <strong>approved</strong> and is now ready for use. Below are your complete account details:</p>

        <h3>🔐 Login Credentials</h3>
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
          <ul>
            <li><strong>Email:</strong> ${email}</li>
            <li><strong>Temporary Password:</strong> <code style="background-color: #e9ecef; padding: 2px 4px; border-radius: 3px;">${password}</code></li>
          </ul>
        </div>

        <h3>⚙️ API Integration</h3>
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;">
          <ul>
            <li><strong>API Key:</strong> <code style="background-color: #e9ecef; padding: 2px 4px; border-radius: 3px;">${apiKey}</code></li>
            <li><strong>API Secret:</strong> <code style="background-color: #e9ecef; padding: 2px 4px; border-radius: 3px;">${apiSecret}</code></li>
          </ul>
          <p style="color: #6c757d; font-size: 14px; margin: 10px 0 0 0;">Use these credentials to integrate our payment gateway into your application.</p>
        </div>

        ${walletSection}

        ${feeSection}

        <h3>🚀 Next Steps</h3>
        <ol>
          <li><strong>Login:</strong> Use your email and temporary password to access your account</li>
          <li><strong>Change Password:</strong> Update your password immediately after first login</li>
          <li><strong>API Integration:</strong> Use your API credentials to integrate our payment gateway</li>
          <li><strong>Test Transactions:</strong> Start with small test amounts to verify integration</li>
          ${walletGenerated ? '<li><strong>Wallet Ready:</strong> Your merchant wallet is ready to receive payments</li>' : '<li><strong>Contact Support:</strong> Get assistance with wallet setup</li>'}
        </ol>

        <div style="background-color: #d1ecf1; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #17a2b8;">
          <h4 style="color: #0c5460; margin-top: 0;">🔒 Security Reminders</h4>
          <ul style="color: #0c5460; margin-bottom: 0;">
            <li>Store your API credentials securely and never share them publicly</li>
            <li>Change your temporary password immediately</li>
            <li>Keep your wallet address safe - this is where your funds will be sent</li>
            <li>Contact support if you notice any suspicious activity</li>
          </ul>
        </div>

        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6;">
          <p style="color: #6c757d;">Need help? Contact our support team</p>
          <p style="margin: 0;"><strong>Secure Crypto Gateway Team</strong></p>
        </div>
      </div>
    </div>
  `;
};
