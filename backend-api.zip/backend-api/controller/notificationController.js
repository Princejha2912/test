const NotificationService = require('../services/notificationService');
const Notification = require('../models/simpleNotification');
const logger = require('../logger/logger');

/**
 * Get user notifications with pagination and filtering
 */
exports.getUserNotifications = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const {
      page = 1,
      limit = 20,
      status,
      type,
      unreadOnly
    } = req.query;

    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      status,
      type,
      unreadOnly: unreadOnly === 'true'
    };

    const result = await NotificationService.getUserNotifications(userId, options);

    res.status(200).json({
      success: true,
      data: result.notifications,
      pagination: result.pagination,
      error: null
    });

  } catch (error) {
    logger.error(`Get notifications error: ${error.message}`);
    next(error);
  }
};

/**
 * Get notification by ID
 */
exports.getNotificationById = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const userId = req.user._id;

    const notification = await Notification.findOne({
      _id: notificationId,
      userId: userId
    });

    if (!notification) {
      return res.status(404).json({
        success: false,
        message: 'Notification not found',
        error: 'Invalid notification ID'
      });
    }

    res.status(200).json({
      success: true,
      data: notification,
      error: null
    });

  } catch (error) {
    logger.error(`Get notification by ID error: ${error.message}`);
    next(error);
  }
};

/**
 * Mark notification as read
 */
exports.markAsRead = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const userId = req.user._id;

    const notification = await NotificationService.markAsRead(notificationId, userId);

    res.status(200).json({
      success: true,
      message: 'Notification marked as read',
      data: notification,
      error: null
    });

  } catch (error) {
    logger.error(`Mark as read error: ${error.message}`);
    next(error);
  }
};

/**
 * Mark all notifications as read
 */
exports.markAllAsRead = async (req, res, next) => {
  try {
    const userId = req.user._id;

    const result = await Notification.updateMany(
      {
        userId: userId,
        isRead: false
      },
      {
        isRead: true
      }
    );

    res.status(200).json({
      success: true,
      message: `${result.modifiedCount} notifications marked as read`,
      data: {
        modifiedCount: result.modifiedCount
      },
      error: null
    });

  } catch (error) {
    logger.error(`Mark all as read error: ${error.message}`);
    next(error);
  }
};

/**
 * Get notification statistics
 */
exports.getNotificationStats = async (req, res, next) => {
  try {
    const userId = req.user._id;

    const stats = await NotificationService.getNotificationStats(userId);

    res.status(200).json({
      success: true,
      data: stats,
      error: null
    });

  } catch (error) {
    logger.error(`Get notification stats error: ${error.message}`);
    next(error);
  }
};

/**
 * Delete notification
 */
exports.deleteNotification = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const userId = req.user._id;

    const notification = await Notification.findOneAndDelete({
      _id: notificationId,
      userId: userId
    });

    if (!notification) {
      return res.status(404).json({
        success: false,
        message: 'Notification not found',
        error: 'Invalid notification ID'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Notification deleted successfully',
      error: null
    });

  } catch (error) {
    logger.error(`Delete notification error: ${error.message}`);
    next(error);
  }
};

// Simplified controller - removed complex admin methods for easier client handling
