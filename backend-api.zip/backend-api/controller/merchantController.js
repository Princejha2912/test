const User = require('../models/user');
const Transaction = require('../models/depositeAmt');
const logger = require('../logger/logger');
const { generateCredentials } = require('../util/generateApiKeySecret');

// Get all merchants with enhanced filtering and search
exports.getAllMerchants = async (req, res, next) => {
  try {
    let {
      page,
      limit,
      status,
      search,
      name,
      apiKey,
      apiSecret,
      country,
      companyName,
      includeApiCredentials
    } = req.query;

    // Convert page and limit to numbers, or set to 1 and 10 if not provided or invalid
    page = parseInt(page);
    limit = parseInt(limit);

    if (isNaN(page) || page < 1) page = 1;
    if (isNaN(limit) || limit < 1) limit = 10;

    const query = {
      role: 'merchant',
    };

    // Status filter (approved field)
    if (status) {
      query.approved = status;
    }

    // Name filter
    if (name) {
      query.name = { $regex: name, $options: 'i' };
    }

    // API Key filter
    if (apiKey) {
      query.apiKey = { $regex: apiKey, $options: 'i' };
    }

    // API Secret filter
    if (apiSecret) {
      query.apiSecret = { $regex: apiSecret, $options: 'i' };
    }

    // Country filter
    if (country) {
      query.country = { $regex: country, $options: 'i' };
    }

    // Company name filter
    if (companyName) {
      query.companyName = { $regex: companyName, $options: 'i' };
    }

    // General search functionality (name, email, company, API key, API secret)
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { companyName: { $regex: search, $options: 'i' } },
        { phoneNo: { $regex: search, $options: 'i' } },
        { apiKey: { $regex: search, $options: 'i' } },
        { apiSecret: { $regex: search, $options: 'i' } }
      ];
    }

    // Select fields - include API credentials by default for admin
    let selectFields = '-password -resetPasswordToken -resetPasswordExpires -tempPassword -otp -otpExpires';

    // Option to exclude API credentials if needed
    if (includeApiCredentials === 'false') {
      selectFields += ' -apiKey -apiSecret';
    }

    const merchants = await User.find(query)
      .skip((page - 1) * limit)
      .limit(limit)
      .select(selectFields)
      .sort({ createdAt: -1 });

    const total = await User.countDocuments(query);

    res.status(200).json({
      success: true,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      filters: {
        status,
        search,
        name,
        apiKey,
        apiSecret,
        country,
        companyName,
        includeApiCredentials: includeApiCredentials !== 'false'
      },
      data: merchants,
    });
  } catch (err) {
    next(err);
  }
};

// Get specific merchant by ID
exports.getMerchantById = async (req, res, next) => {
  try {
    const merchant = await User.findById(req.params.merchantId).select('-password -tempPassword -resetPasswordExpires -tempPassword -otp -otpExpires');

    if (!merchant ) {
      return res.status(404).json({
        success: false,
        error: 'Merchant not found',
      });
    }

    res.status(200).json({
      success: true,
      data: merchant,
    });
  } catch (err) {
    next(err);
  }
};

// Get merchant transactions by merchant ID with pagination
exports.getMerchantTransactions = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const { merchantId } = req.params;

    const merchant = await User.findById(merchantId);
    if (!merchant || merchant.role !== 'merchant') {
      return res.status(404).json({
        success: false,
        error: 'Merchant not found',
      });
    }

    const transactions = await Transaction.find({ merchantId })
      .select('-walletSecretKey') // 🚫 exclude the field
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Transaction.countDocuments({ merchantId });

    res.status(200).json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / limit),
      data: transactions,
    });
  } catch (err) {
    next(err);
  }
};

// Generate API credentials for merchant
exports.generateApiCredentials = async (req, res, next) => {
  try {
    const { merchantId } = req.params;

    const merchant = await User.findById(merchantId);
    if (!merchant || merchant.role !== 'merchant') {
      return res.status(404).json({
        success: false,
        message: 'Merchant not found',
        error: 'Invalid merchant ID'
      });
    }

    if (merchant.approved !== 'approved') {
      return res.status(400).json({
        success: false,
        message: 'Merchant must be approved before generating API credentials',
        error: 'Merchant not approved'
      });
    }

    // Generate new API credentials
    const credentials = generateCredentials();
    merchant.apiKey = credentials.apiKey;
    merchant.apiSecret = credentials.apiSecret;
    await merchant.save();

    res.status(200).json({
      success: true,
      message: 'API credentials generated successfully',
      data: {
        merchantId: merchant._id,
        apiKey: credentials.apiKey,
        apiSecret: credentials.apiSecret,
        generatedAt: new Date()
      },
      error: null
    });

  } catch (err) {
    next(err);
  }
};

// Regenerate API credentials for merchant
exports.regenerateApiCredentials = async (req, res, next) => {
  try {
    const { merchantId } = req.params;

    const merchant = await User.findById(merchantId);
    if (!merchant || merchant.role !== 'merchant') {
      return res.status(404).json({
        success: false,
        message: 'Merchant not found',
        error: 'Invalid merchant ID'
      });
    }

    // Generate new API credentials
    const credentials = generateCredentials();
    merchant.apiKey = credentials.apiKey;
    merchant.apiSecret = credentials.apiSecret;
    await merchant.save();

    res.status(200).json({
      success: true,
      message: 'API credentials regenerated successfully',
      data: {
        merchantId: merchant._id,
        apiKey: credentials.apiKey,
        apiSecret: credentials.apiSecret,
        regeneratedAt: new Date()
      },
      error: null
    });

  } catch (err) {
    next(err);
  }
};

// Get merchant API credentials (admin only)
exports.getMerchantApiCredentials = async (req, res, next) => {
  try {
    const { merchantId } = req.params;

    const merchant = await User.findById(merchantId).select('name email apiKey apiSecret approved');
    if (!merchant || merchant.role !== 'merchant') {
      return res.status(404).json({
        success: false,
        message: 'Merchant not found',
        error: 'Invalid merchant ID'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        merchantId: merchant._id,
        name: merchant.name,
        email: merchant.email,
        apiKey: merchant.apiKey,
        apiSecret: merchant.apiSecret,
        approved: merchant.approved,
        hasCredentials: !!(merchant.apiKey && merchant.apiSecret)
      },
      error: null
    });

  } catch (err) {
    next(err);
  }
};
