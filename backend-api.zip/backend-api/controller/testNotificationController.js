const NotificationService = require('../services/notificationService');
const logger = require('../logger/logger');

/**
 * Test notification endpoints (for testing admin notifications)
 */

/**
 * Test admin notification system
 */
exports.testAdminNotification = async (req, res, next) => {
  try {
    const { type = 'deposit_success', amount = 1000 } = req.body;
    
    // Create a test notification that will trigger admin notification
    await NotificationService.createNotification(
      req.user._id,
      type,
      'Test Notification',
      `This is a test ${type} notification for ${amount} USDT`,
      amount,
      'test_' + Date.now()
    );

    res.status(200).json({
      success: true,
      message: 'Test notification sent to user and admins',
      data: {
        type,
        amount,
        userId: req.user._id
      },
      error: null
    });

  } catch (error) {
    logger.error(`Test notification error: ${error.message}`);
    next(error);
  }
};

/**
 * Test admin alert system
 */
exports.testAdminAlert = async (req, res, next) => {
  try {
    const { alertType = 'Test Alert', message = 'This is a test admin alert' } = req.body;
    
    // Send immediate admin alert
    await NotificationService.sendAdminAlert(
      alertType,
      message,
      {
        testData: 'This is test data',
        userId: req.user._id,
        userName: req.user.name,
        timestamp: new Date().toISOString()
      }
    );

    res.status(200).json({
      success: true,
      message: 'Test admin alert sent successfully',
      data: {
        alertType,
        message,
        sentBy: req.user._id
      },
      error: null
    });

  } catch (error) {
    logger.error(`Test admin alert error: ${error.message}`);
    next(error);
  }
};
