const blockchainService = require('../services/blockchainService');
const WalletCounter = require('../models/walletCounter');
const logger = require('../logger/logger');

// Get wallet counter statistics
exports.getCounterStatistics = async (req, res, next) => {
  try {
    logger.info('Admin requesting wallet counter statistics');
    
    const statistics = await blockchainService.getCounterStatistics();
    
    if (statistics.success) {
      res.status(200).json({
        success: true,
        message: 'Counter statistics retrieved successfully',
        data: statistics.statistics,
        error: null
      });
    } else {
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve counter statistics',
        error: statistics.error
      });
    }
  } catch (error) {
    logger.error(`Get counter statistics error: ${error.message}`);
    next(error);
  }
};

// Reset counter for a specific network
exports.resetCounter = async (req, res, next) => {
  try {
    const { network } = req.params;
    const { newCount } = req.body;
    
    logger.info(`Admin resetting ${network} counter to: ${newCount || 'timestamp'}`);
    
    // Validate network
    if (!['ERC20', 'TRC20'].includes(network)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid network. Must be ERC20 or TRC20',
        error: 'Invalid network parameter'
      });
    }
    
    // Validate newCount if provided
    if (newCount !== undefined && (!Number.isInteger(newCount) || newCount < 0)) {
      return res.status(400).json({
        success: false,
        message: 'New count must be a positive integer',
        error: 'Invalid count value'
      });
    }
    
    const result = await blockchainService.resetCounter(network, newCount);
    
    if (result.success) {
      res.status(200).json({
        success: true,
        message: `${network} counter reset successfully`,
        data: {
          network: result.network,
          newCount: result.newCount,
          resetAt: result.resetAt
        },
        error: null
      });
    } else {
      res.status(500).json({
        success: false,
        message: `Failed to reset ${network} counter`,
        error: result.error
      });
    }
  } catch (error) {
    logger.error(`Reset counter error: ${error.message}`);
    next(error);
  }
};

// Get detailed counter information
exports.getCounterDetails = async (req, res, next) => {
  try {
    const { network } = req.params;
    
    logger.info(`Admin requesting ${network} counter details`);
    
    // Validate network
    if (!['ERC20', 'TRC20'].includes(network)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid network. Must be ERC20 or TRC20',
        error: 'Invalid network parameter'
      });
    }
    
    const counter = await WalletCounter.findOne({ network: network });
    
    if (!counter) {
      return res.status(404).json({
        success: false,
        message: `${network} counter not found`,
        error: 'Counter not initialized'
      });
    }
    
    res.status(200).json({
      success: true,
      message: `${network} counter details retrieved successfully`,
      data: {
        network: counter.network,
        currentCount: counter.currentCount,
        lastUsedAt: counter.lastUsedAt,
        createdAt: counter.createdAt,
        updatedAt: counter.updatedAt
      },
      error: null
    });
    
  } catch (error) {
    logger.error(`Get counter details error: ${error.message}`);
    next(error);
  }
};

// Initialize or reinitialize all counters
exports.initializeCounters = async (req, res, next) => {
  try {
    logger.info('Admin initializing wallet counters');

    await WalletCounter.initializeCounters();

    // Get current statistics after initialization
    const statistics = await blockchainService.getCounterStatistics();

    res.status(200).json({
      success: true,
      message: 'Wallet counters initialized successfully',
      data: statistics.success ? statistics.statistics : null,
      error: null
    });

  } catch (error) {
    logger.error(`Initialize counters error: ${error.message}`);
    next(error);
  }
};

// Reset counters to start from 1
exports.resetCountersToOne = async (req, res, next) => {
  try {
    logger.info('Admin resetting wallet counters to start from 1');

    await WalletCounter.resetCount('ERC20', 1);
    await WalletCounter.resetCount('TRC20', 1);

    // Get current statistics after reset
    const statistics = await blockchainService.getCounterStatistics();

    res.status(200).json({
      success: true,
      message: 'Wallet counters reset to start from 1',
      data: statistics.success ? statistics.statistics : null,
      error: null
    });

  } catch (error) {
    logger.error(`Reset counters to one error: ${error.message}`);
    next(error);
  }
};

// Get next count for a network (preview without incrementing)
exports.previewNextCount = async (req, res, next) => {
  try {
    const { network } = req.params;
    
    logger.info(`Admin previewing next count for ${network}`);
    
    // Validate network
    if (!['ERC20', 'TRC20'].includes(network)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid network. Must be ERC20 or TRC20',
        error: 'Invalid network parameter'
      });
    }
    
    const currentCount = await WalletCounter.getCurrentCount(network);
    const nextCount = currentCount + 1;
    
    res.status(200).json({
      success: true,
      message: `Next count preview for ${network}`,
      data: {
        network: network,
        currentCount: currentCount,
        nextCount: nextCount
      },
      error: null
    });
    
  } catch (error) {
    logger.error(`Preview next count error: ${error.message}`);
    next(error);
  }
};
