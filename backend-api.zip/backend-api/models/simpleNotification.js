const mongoose = require('mongoose');

// Simple Notification Model - Easy for Client Handling
const notificationSchema = new mongoose.Schema({
  // Who gets the notification
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },

  // What type of notification
  type: {
    type: String,
    required: true,
    enum: [
      'deposit_success',
      'deposit_failed',
      'withdrawal_approved',
      'withdrawal_rejected',
      'merchant_approved',
      'merchant_blocked'
    ]
  },

  // Notification content
  title: {
    type: String,
    required: true,
    maxLength: 80
  },

  message: {
    type: String,
    required: true,
    maxLength: 200
  },

  // Is it read?
  isRead: {
    type: Boolean,
    default: false,
    index: true
  },

  // Related info (optional)
  amount: {
    type: Number
  },

  relatedId: {
    type: String // transaction ID, withdrawal ID, etc.
  }

}, {
  timestamps: true,
  toJSON: {
    transform: function(doc, ret) {
      // Return only what client needs
      return {
        id: ret._id,
        type: ret.type,
        title: ret.title,
        message: ret.message,
        isRead: ret.isRead,
        amount: ret.amount,
        relatedId: ret.relatedId,
        createdAt: ret.createdAt
      };
    }
  }
});

// Index for fast queries
notificationSchema.index({ userId: 1, isRead: 1 });
notificationSchema.index({ createdAt: -1 });

// Simple static methods
notificationSchema.statics.createForUser = function(userId, type, title, message, amount = null, relatedId = null) {
  return this.create({
    userId,
    type,
    title,
    message,
    amount,
    relatedId
  });
};

notificationSchema.statics.markAsRead = function(notificationId, userId) {
  return this.findOneAndUpdate(
    { _id: notificationId, userId },
    { isRead: true },
    { new: true }
  );
};

notificationSchema.statics.getUnreadCount = function(userId) {
  return this.countDocuments({ userId, isRead: false });
};

module.exports = mongoose.model('Notification', notificationSchema);
