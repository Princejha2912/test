const mongoose = require('mongoose');

// Very Simple Statistics Model - Easy to Understand
const simpleStatsSchema = new mongoose.Schema({
  // Which merchant (null = all merchants combined)
  merchantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
    index: true
  },

  // Simple counters
  totalDeposits: {
    type: Number,
    default: 0
  },

  successfulDeposits: {
    type: Number,
    default: 0
  },

  failedDeposits: {
    type: Number,
    default: 0
  },

  totalWithdrawals: {
    type: Number,
    default: 0
  },

  approvedWithdrawals: {
    type: Number,
    default: 0
  },

  rejectedWithdrawals: {
    type: Number,
    default: 0
  },

  // Simple amounts
  totalDepositAmount: {
    type: Number,
    default: 0
  },

  totalWithdrawalAmount: {
    type: Number,
    default: 0
  },

  totalFees: {
    type: Number,
    default: 0
  },

  // Current balance
  currentBalance: {
    type: Number,
    default: 0
  }

}, {
  timestamps: true
});

// Index for fast queries
simpleStatsSchema.index({ merchantId: 1 });

// Simple methods to update stats
simpleStatsSchema.statics.addDeposit = async function(merchantId, amount, isSuccessful) {
  // Update merchant stats
  if (merchantId) {
    await this.findOneAndUpdate(
      { merchantId: merchantId },
      {
        $inc: {
          totalDeposits: 1,
          successfulDeposits: isSuccessful ? 1 : 0,
          failedDeposits: isSuccessful ? 0 : 1,
          totalDepositAmount: amount,
          currentBalance: isSuccessful ? amount : 0
        }
      },
      { upsert: true }
    );
  }

  // Update platform stats (merchantId = null)
  await this.findOneAndUpdate(
    { merchantId: null },
    {
      $inc: {
        totalDeposits: 1,
        successfulDeposits: isSuccessful ? 1 : 0,
        failedDeposits: isSuccessful ? 0 : 1,
        totalDepositAmount: amount
      }
    },
    { upsert: true }
  );
};

simpleStatsSchema.statics.addWithdrawal = async function(merchantId, amount, isApproved, fee = 0) {
  // Update merchant stats
  if (merchantId) {
    await this.findOneAndUpdate(
      { merchantId: merchantId },
      {
        $inc: {
          totalWithdrawals: 1,
          approvedWithdrawals: isApproved ? 1 : 0,
          rejectedWithdrawals: isApproved ? 0 : 1,
          totalWithdrawalAmount: amount,
          totalFees: fee,
          currentBalance: isApproved ? -amount : 0
        }
      },
      { upsert: true }
    );
  }

  // Update platform stats (merchantId = null)
  await this.findOneAndUpdate(
    { merchantId: null },
    {
      $inc: {
        totalWithdrawals: 1,
        approvedWithdrawals: isApproved ? 1 : 0,
        rejectedWithdrawals: isApproved ? 0 : 1,
        totalWithdrawalAmount: amount,
        totalFees: fee
      }
    },
    { upsert: true }
  );
};

// Get merchant stats
simpleStatsSchema.statics.getMerchantStats = function(merchantId) {
  return this.findOne({ merchantId: merchantId });
};

// Get platform stats
simpleStatsSchema.statics.getPlatformStats = function() {
  return this.findOne({ merchantId: null });
};

// Get all merchant stats
simpleStatsSchema.statics.getAllMerchantStats = function() {
  return this.find({ merchantId: { $ne: null } }).populate('merchantId', 'name email');
};

module.exports = mongoose.model('SimpleStats', simpleStatsSchema);
