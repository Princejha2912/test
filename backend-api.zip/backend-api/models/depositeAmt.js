const mongoose = require('mongoose');

const depositSchema = new mongoose.Schema({
  transactionId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  amount: {
    type: Number,
    min: 0.01
  },
  fee: {
    type: Number,
    default: 0
  },
  netAmount: {
    type: Number,
    min: 0
  },
  actualBalance: {
    type: Number,
    min: 0.01
  },
  currencyType: {
    type: String,
    default: 'USDT-TRC20',
    enum: ['USDT-TRC20', 'USDT-ERC20']
  },
  walletAddress: {
    type: String,
    required: true
  },
  walletSecretKey: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: [
      'initiated',
      'confirmed',
      'failed',
      'expired',
      'pending',
      'api_failed',
      'amount confirmed',
      'admin_transfer_failed'
      , 'amount present on wallet'
    ],
    default: 'initiated',
    index: true
  },
  expiresAt: {
    type: Date,
    index: true
  },
  confirmedAt: {
    type: Date
  },
  verificationData: {
    actualBalance: { type: Number },
    rawBalance: { type: String },
    expectedAmount: { type: Number },
    contractAddress: { type: String },
    network: { type: String },
    responseMessage: { type: String },
    verifiedAt: { type: Date },
    error: { type: String },
    failureReason: { type: String }
  },
  adminTransferData: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  blockchainTxHash: {
    type: String
  },
  clientReference: {
    type: String
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true }
});


depositSchema.index({ clientId: 1, status: 1 });
depositSchema.index({ status: 1, expiresAt: 1 });

module.exports = mongoose.model('Deposit', depositSchema);
