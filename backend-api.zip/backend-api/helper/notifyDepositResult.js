const NotificationService = require('../services/notificationService.js');
module.exports.notifyDepositResult = async ({ merchantId, status, transactionId, amount }) => {
  const type = status === 'confirmed' ? 'deposit_success' : 'deposit_failed';
  try {
    await NotificationService.createDepositNotification(
      merchantId,
      type,
      transactionId,
      amount
    );
    console.log(`[NOTIFY] Sent ${type} email for transaction ${transactionId}`);
  } catch (err) {
    console.error(`[NOTIFY] Email failed: ${err.message}`);
  }
};
