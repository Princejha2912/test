// Minimal server to test route loading without Swagger
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const app = express();

// Basic middleware
app.use(cors());
app.use(express.json());
app.use(cookieParser());


try {
  const authRoutes = require('./routes/authRoute.js');
  app.use('/api/v1/auth', authRoutes);

  console.log('2. Loading admin routes...');
  const adminRoutes = require('./routes/adminRoute.js');
  app.use('/api/v1/admin', adminRoutes);
  console.log('✅ Admin routes loaded successfully');

  console.log('3. Loading merchant routes...');
  const merchantRoute = require('./routes/merchantRoute.js');
  app.use('/api/v1/merchant', merchantRoute);
  console.log('✅ Merchant routes loaded successfully');

  console.log('4. Loading transaction routes...');
  const transactionRoute = require('./routes/transaction.js');
  app.use('/api/v1/transaction', transactionRoute);
  console.log('✅ Transaction routes loaded successfully');

  console.log('5. Loading fee routes...');
  const feeRoutes = require('./routes/feeRoute.js');
  app.use('/api/v1/fee', feeRoutes);
  console.log('✅ Fee routes loaded successfully');

  console.log('6. Loading withdrawal routes...');
  const withdrawalRoute = require('./routes/widthdrawalRoute.js');
  app.use('/api/v1/withdrawal', withdrawalRoute);
  console.log('✅ Withdrawal routes loaded successfully');

  console.log('\n🎉 All routes loaded successfully!');
  console.log('The path-to-regexp error is likely coming from Swagger JSDoc parsing.');

  const PORT = process.env.PORT || 5001;
  app.listen(PORT, () => {
    console.log(`✅ Test server running on port ${PORT}`);
    console.log('If this works, the issue is in Swagger configuration.');
  });

} catch (error) {
  console.error('❌ Error loading routes:', error.message);
  console.error('Stack trace:', error.stack);
}
