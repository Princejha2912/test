
const express = require('express');
const router = express.Router()
const {
  getAllMerchants,
  getMerchantById,
  getMerchantTransactions,
  generateApiCredentials,
  regenerateApiCredentials,
  getMerchantApiCredentials
} = require('../controller/merchantController.js');
const { validatePagination } = require('../validations/paginationAndFilter.js');
const { validateRequest } = require('../middleware/validateIncomingRequest.js');
const {IdValidator} = require('../validations/merchantVlidator.js')
const { protect, authorizeRoles } = require('../middleware/routeProtector.js');

/**
 * @swagger
 * components:
 *   schemas:
 *     Merchant:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           example: "60d5ecb74b24a1234567890a"
 *         name:
 *           type: string
 *           example: "John Doe"
 *         email:
 *           type: string
 *           example: "merchant@example.com"
 *         role:
 *           type: string
 *           example: "merchant"
 *         approved:
 *           type: string
 *           enum: [pending, approved, block]
 *           example: "approved"
 *         apiKey:
 *           type: string
 *           example: "mk_1234567890_abcdef"
 *         walletAddress:
 *           type: string
 *           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *         totalAmt:
 *           type: number
 *           example: 1500.50
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:00:00.000Z"
 *
 *     MerchantTransaction:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           example: "60d5ecb74b24a1234567890b"
 *         transactionId:
 *           type: string
 *           example: "dep_1234567890_abcdef"
 *         amount:
 *           type: number
 *           example: 500
 *         currencyType:
 *           type: string
 *           example: "USDT-TRC20"
 *         status:
 *           type: string
 *           enum: [initiated, confirmed, failed, expired]
 *           example: "confirmed"
 *         walletAddress:
 *           type: string
 *           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *         createdAt:
 *           type: string
 *           format: date-time
 *         confirmedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *
 *     PaginationResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         total:
 *           type: number
 *           example: 25
 *         page:
 *           type: number
 *           example: 1
 *         totalPages:
 *           type: number
 *           example: 3
 *         data:
 *           type: array
 *           items:
 *             oneOf:
 *               - $ref: '#/components/schemas/Merchant'
 *               - $ref: '#/components/schemas/Merchant'
 */

/**
 * @swagger
 * /merchant:
 *   get:
 *     summary: Get all merchants with advanced filtering (Admin only)
 *     description: |
 *       Retrieve a paginated list of all merchants with comprehensive search and filtering options.
 *
 *       **Admin Only**: Requires admin or superadmin authentication.
 *
 *       **Enhanced Features**:
 *       - Pagination support
 *       - Filter by approval status, name, API credentials
 *       - Search across multiple fields (name, email, company, phone, API key/secret)
 *       - Country and company name filtering
 *       - Option to include/exclude API credentials
 *       - Sorted by creation date (newest first)
 *
 *       **Use Cases**:
 *       - Admin dashboard merchant list
 *       - Merchant management interface
 *       - API credential management
 *       - Platform statistics and monitoring
 *     tags: [Merchant Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of merchants per page
 *         example: 20
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, approved, rejected, block]
 *         description: Filter merchants by approval status
 *         example: "approved"
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search across name, email, company, phone, API key, and API secret
 *         example: "john"
 *       - in: query
 *         name: name
 *         schema:
 *           type: string
 *         description: Filter by merchant name
 *         example: "John Doe"
 *       - in: query
 *         name: apiKey
 *         schema:
 *           type: string
 *         description: Filter by API key
 *         example: "mk_1234567890"
 *       - in: query
 *         name: apiSecret
 *         schema:
 *           type: string
 *         description: Filter by API secret
 *         example: "sk_1234567890"
 *       - in: query
 *         name: country
 *         schema:
 *           type: string
 *         description: Filter by country
 *         example: "United States"
 *       - in: query
 *         name: companyName
 *         schema:
 *           type: string
 *         description: Filter by company name
 *         example: "ABC Trading"
 *       - in: query
 *         name: includeApiCredentials
 *         schema:
 *           type: string
 *           enum: [true, false]
 *           default: true
 *         description: Include API credentials in response (true by default)
 *         example: "true"
 *     responses:
 *       200:
 *         description: Merchants retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 total:
 *                   type: number
 *                   example: 25
 *                 page:
 *                   type: number
 *                   example: 1
 *                 totalPages:
 *                   type: number
 *                   example: 3
 *                 filters:
 *                   type: object
 *                   properties:
 *                     status:
 *                       type: string
 *                       example: "approved"
 *                     search:
 *                       type: string
 *                       example: "john"
 *                     name:
 *                       type: string
 *                       example: "John Doe"
 *                     apiKey:
 *                       type: string
 *                       example: "mk_1234567890"
 *                     apiSecret:
 *                       type: string
 *                       example: "sk_1234567890"
 *                     country:
 *                       type: string
 *                       example: "United States"
 *                     companyName:
 *                       type: string
 *                       example: "ABC Trading"
 *                     includeApiCredentials:
 *                       type: boolean
 *                       example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Merchant'
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get('/', protect, authorizeRoles('admin', 'superadmin'), validatePagination, validateRequest, getAllMerchants);

/**
 * @swagger
 * /merchant/{merchantId}:
 *   get:
 *     summary: Get merchant by ID
 *     description: |
 *       Retrieve detailed information about a specific merchant.
 *
 *       **Access Control**:
 *       - Admins: Can view any merchant
 *       - Merchants: Can only view their own profile
 *
 *       **Data Returned**:
 *       - Complete merchant profile
 *       - Balance information
 *       - API credentials (for own profile)
 *       - Account status and approval details
 *     tags: [Merchant Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *     responses:
 *       200:
 *         description: Merchant details retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/Merchant'
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Access denied
 *       404:
 *         description: Merchant not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 error:
 *                   type: string
 *                   example: "Merchant not found"
 *       500:
 *         description: Internal server error
 */
router.get('/:merchantId', protect, authorizeRoles('admin', 'superadmin','merchant'),IdValidator,validateRequest, getMerchantById);

/**
 * @swagger
 * /merchant/{merchantId}/transactions:
 *   get:
 *     summary: Get merchant transactions
 *     description: |
 *       Retrieve paginated transaction history for a specific merchant.
 *
 *       **Access Control**:
 *       - Admins: Can view any merchant's transactions
 *       - Merchants: Can only view their own transactions
 *
 *       **Features**:
 *       - Pagination support
 *       - Sorted by creation date (newest first)
 *       - Includes all transaction statuses
 *       - Shows deposit amounts and wallet addresses
 *
 *       **Use Cases**:
 *       - Merchant dashboard transaction history
 *       - Admin transaction monitoring
 *       - Financial reporting and reconciliation
 *     tags: [Merchant Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of transactions per page
 *         example: 20
 *     responses:
 *       200:
 *         description: Merchant transactions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 total:
 *                   type: number
 *                   example: 15
 *                 page:
 *                   type: number
 *                   example: 1
 *                 totalPages:
 *                   type: number
 *                   example: 2
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/MerchantTransaction'
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Access denied
 *       404:
 *         description: Merchant not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 error:
 *                   type: string
 *                   example: "Merchant not found"
 *       500:
 *         description: Internal server error
 */
router.get('/:merchantId/transactions', protect, authorizeRoles('admin', 'superadmin','merchant'), validatePagination,validateRequest, getMerchantTransactions);

/**
 * @swagger
 * /merchant/{merchantId}/generate-api-credentials:
 *   post:
 *     summary: Generate API credentials for merchant
 *     description: Generate new API key and secret for an approved merchant (Admin only)
 *     tags: [Merchants]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *     responses:
 *       200:
 *         description: API credentials generated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "API credentials generated successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     merchantId:
 *                       type: string
 *                       example: "60d5ecb74b24a1234567890a"
 *                     apiKey:
 *                       type: string
 *                       example: "mk_1234567890_abcdef"
 *                     apiSecret:
 *                       type: string
 *                       example: "sk_1234567890_abcdef123456"
 *                     generatedAt:
 *                       type: string
 *                       format: date-time
 *                       example: "2024-01-01T10:00:00.000Z"
 *       400:
 *         description: Merchant not approved
 *       404:
 *         description: Merchant not found
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 */
router.post('/:merchantId/generate-api-credentials', protect, authorizeRoles('admin', 'superadmin'), IdValidator, validateRequest, generateApiCredentials);

/**
 * @swagger
 * /merchant/{merchantId}/regenerate-api-credentials:
 *   put:
 *     summary: Regenerate API credentials for merchant
 *     description: Regenerate API key and secret for a merchant (Admin only)
 *     tags: [Merchants]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *     responses:
 *       200:
 *         description: API credentials regenerated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "API credentials regenerated successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     merchantId:
 *                       type: string
 *                       example: "60d5ecb74b24a1234567890a"
 *                     apiKey:
 *                       type: string
 *                       example: "mk_0987654321_fedcba"
 *                     apiSecret:
 *                       type: string
 *                       example: "sk_0987654321_fedcba654321"
 *                     regeneratedAt:
 *                       type: string
 *                       format: date-time
 *                       example: "2024-01-01T10:05:00.000Z"
 *       404:
 *         description: Merchant not found
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 */
router.put('/:merchantId/regenerate-api-credentials', protect, authorizeRoles('admin', 'superadmin'), IdValidator, validateRequest, regenerateApiCredentials);

/**
 * @swagger
 * /merchant/{merchantId}/api-credentials:
 *   get:
 *     summary: Get merchant API credentials
 *     description: Retrieve API key and secret for a merchant (Admin only)
 *     tags: [Merchants]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *     responses:
 *       200:
 *         description: API credentials retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     merchantId:
 *                       type: string
 *                       example: "60d5ecb74b24a1234567890a"
 *                     name:
 *                       type: string
 *                       example: "John Doe"
 *                     email:
 *                       type: string
 *                       example: "merchant@example.com"
 *                     apiKey:
 *                       type: string
 *                       example: "mk_1234567890_abcdef"
 *                     apiSecret:
 *                       type: string
 *                       example: "sk_1234567890_abcdef123456"
 *                     approved:
 *                       type: string
 *                       example: "approved"
 *                     hasCredentials:
 *                       type: boolean
 *                       example: true
 *       404:
 *         description: Merchant not found
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 */
router.get('/:merchantId/api-credentials', protect, authorizeRoles('admin', 'superadmin'), IdValidator, validateRequest, getMerchantApiCredentials);

module.exports = router;