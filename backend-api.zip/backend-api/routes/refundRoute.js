const express = require('express');
const router = express.Router();

const {
  getAllRefunds,
  createRefund,
  getRefundById,
  deleteRefund,
  getAllRefundsMerchant,
  updateRefundByMerchant,
  updateRefundByAdmin
} = require('../controller/refundController.js');

const { validatePagination } = require('../validations/paginationAndFilter.js');
const { validateRequest } = require('../middleware/validateIncomingRequest.js');
const { authorizeRoles, protect } = require('../middleware/routeProtector.js');
const {validateTransactionRequest} = require('../validations/refundValidate.js')
const { apiAuth } = require('../middleware/VerifyMerchant.js');

router.post('/',apiAuth,validateTransactionRequest,validateRequest,createRefund);
router.get('/', protect, authorizeRoles('admin', 'superadmin'), validatePagination, validateRequest, getAllRefunds);
router.get('/merchant', protect, authorizeRoles('merchant','admin'), validatePagination, validateRequest, getAllRefundsMerchant);
router.get('/:id', protect, authorizeRoles('admin', 'superadmin'), getRefundById);
router.put('/merchant/:id',protect, authorizeRoles('merchant','admin'),updateRefundByMerchant);
router.put('/admin/:id',protect, authorizeRoles('admin', 'superadmin'),updateRefundByAdmin);



router.delete('/:id', protect, authorizeRoles('admin', 'superadmin'), deleteRefund);

module.exports = router;
  