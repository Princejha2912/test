const express = require('express');
const router = express.Router();

const {
  testAdminNotification,
  testAdminAlert
} = require('../controller/testNotificationController');

const { protect, authorizeRoles } = require('../middleware/routeProtector');

/**
 * @swagger
 * /test-notifications/admin-notification:
 *   post:
 *     summary: Test admin notification system
 *     description: Send a test notification that will trigger admin notifications via email
 *     tags: [Test Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [deposit_success, deposit_failed, withdrawal_approved, withdrawal_rejected, merchant_approved, merchant_blocked]
 *                 default: deposit_success
 *                 example: deposit_success
 *               amount:
 *                 type: number
 *                 default: 1000
 *                 example: 1000
 *     responses:
 *       200:
 *         description: Test notification sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Test notification sent to user and admins"
 *                 data:
 *                   type: object
 *                   properties:
 *                     type:
 *                       type: string
 *                       example: "deposit_success"
 *                     amount:
 *                       type: number
 *                       example: 1000
 *                     userId:
 *                       type: string
 *                       example: "60d5ecb74b24a1234567890c"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.post(
  '/admin-notification',
  protect,
  testAdminNotification
);

/**
 * @swagger
 * /test-notifications/admin-alert:
 *   post:
 *     summary: Test admin alert system
 *     description: Send a test critical alert to all admins via email
 *     tags: [Test Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               alertType:
 *                 type: string
 *                 default: Test Alert
 *                 example: "System Test Alert"
 *               message:
 *                 type: string
 *                 default: This is a test admin alert
 *                 example: "This is a test critical alert message"
 *     responses:
 *       200:
 *         description: Test admin alert sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Test admin alert sent successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     alertType:
 *                       type: string
 *                       example: "System Test Alert"
 *                     message:
 *                       type: string
 *                       example: "This is a test critical alert message"
 *                     sentBy:
 *                       type: string
 *                       example: "60d5ecb74b24a1234567890c"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.post(
  '/admin-alert',
  protect,
  testAdminAlert
);

module.exports = router;
