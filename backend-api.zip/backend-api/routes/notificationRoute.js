const express = require('express');
const router = express.Router();

const {
  getUserNotifications,
  getNotificationById,
  markAsRead,
  markAllAsRead,
  getNotificationStats,
  deleteNotification
} = require('../controller/notificationController');

const { protect, authorizeRoles } = require('../middleware/routeProtector');
const { validateRequest } = require('../middleware/validateIncomingRequest');
const { validatePagination } = require('../validations/paginationAndFilter');
const { 
  notificationIdValidation,
  createNotificationValidation 
} = require('../validations/notificationValidation');

/**
 * @swagger
 * components:
 *   schemas:
 *     SimpleNotification:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: "60d5ecb74b24a1234567890c"
 *         type:
 *           type: string
 *           enum: [deposit_success, deposit_failed, withdrawal_approved, withdrawal_rejected, merchant_approved, merchant_blocked]
 *           example: "deposit_success"
 *         title:
 *           type: string
 *           example: "Deposit Confirmed"
 *         message:
 *           type: string
 *           example: "Your deposit of 1000 USDT has been confirmed."
 *         isRead:
 *           type: boolean
 *           example: false
 *         amount:
 *           type: number
 *           example: 1000
 *         relatedId:
 *           type: string
 *           example: "dep_1234567890_abcdef"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:00:00.000Z"
 */

// User notification routes (authenticated users)

/**
 * @swagger
 * /notifications:
 *   get:
 *     summary: Get user notifications
 *     description: Get paginated list of notifications for the authenticated user
 *     tags: [Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Number of notifications per page
 *       - in: query
 *         name: unreadOnly
 *         schema:
 *           type: boolean
 *           default: false
 *         description: Show only unread notifications
 *     responses:
 *       200:
 *         description: Notifications retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/SimpleNotification'
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     total:
 *                       type: number
 *                       example: 25
 *                     page:
 *                       type: number
 *                       example: 1
 *                     limit:
 *                       type: number
 *                       example: 20
 *                     totalPages:
 *                       type: number
 *                       example: 2
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get(
  '/',
  protect,
  validatePagination,
  validateRequest,
  getUserNotifications
);

/**
 * @swagger
 * /notifications/stats:
 *   get:
 *     summary: Get notification statistics
 *     description: Get simple notification statistics for the authenticated user
 *     tags: [Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Notification statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     total:
 *                       type: number
 *                       example: 25
 *                       description: Total notifications
 *                     unread:
 *                       type: number
 *                       example: 5
 *                       description: Unread notifications
 *                     read:
 *                       type: number
 *                       example: 20
 *                       description: Read notifications
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get(
  '/stats',
  protect,
  getNotificationStats
);

// Get specific notification
router.get(
  '/:notificationId',
  protect,
  notificationIdValidation,
  validateRequest,
  getNotificationById
);

/**
 * @swagger
 * /notifications/{notificationId}/read:
 *   patch:
 *     summary: Mark notification as read
 *     description: Mark a specific notification as read for the authenticated user
 *     tags: [Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: notificationId
 *         required: true
 *         schema:
 *           type: string
 *         description: Notification ID
 *         example: "60d5ecb74b24a1234567890c"
 *     responses:
 *       200:
 *         description: Notification marked as read successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Notification marked as read"
 *                 data:
 *                   $ref: '#/components/schemas/SimpleNotification'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid notification ID
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Notification not found
 *       500:
 *         description: Internal server error
 */
router.patch(
  '/:notificationId/read',
  protect,
  notificationIdValidation,
  validateRequest,
  markAsRead
);

/**
 * @swagger
 * /notifications/read-all:
 *   patch:
 *     summary: Mark all notifications as read
 *     description: Mark all unread notifications as read for the authenticated user
 *     tags: [Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: All notifications marked as read successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "5 notifications marked as read"
 *                 data:
 *                   type: object
 *                   properties:
 *                     modifiedCount:
 *                       type: number
 *                       example: 5
 *                       description: Number of notifications marked as read
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.patch(
  '/read-all',
  protect,
  markAllAsRead
);

/**
 * @swagger
 * /notifications/{notificationId}:
 *   delete:
 *     summary: Delete notification
 *     description: Delete a specific notification for the authenticated user
 *     tags: [Notifications]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: notificationId
 *         required: true
 *         schema:
 *           type: string
 *         description: Notification ID
 *         example: "60d5ecb74b24a1234567890c"
 *     responses:
 *       200:
 *         description: Notification deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Notification deleted successfully"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid notification ID
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Notification not found
 *       500:
 *         description: Internal server error
 */
router.delete(
  '/:notificationId',
  protect,
  notificationIdValidation,
  validateRequest,
  deleteNotification
);

// Simplified notification routes - removed complex admin features for easier client handling

module.exports = router;
