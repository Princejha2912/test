const express = require('express');
const router = express.Router();

const {
  withdrawalRequestValidation,
  withdrawalActionValidation
} = require('../validations/withdrawaValidator');

const {
  getAllWithdrawals,
  getMerchantWithdrawals,
  getMyWithdrawals,
  initiateWithdrawal,
  handleWithdrawalStatus
} = require('../controller/widthdrawalController');

const { validatePagination } = require('../validations/paginationAndFilter');
const { validateRequest } = require('../middleware/validateIncomingRequest');
const { protect, authorizeRoles } = require('../middleware/routeProtector');

/**
 * @swagger
 * components:
 *   schemas:
 *     WithdrawalRequest:
 *       type: object
 *       required:
 *         - amount
 *         - merchantWallet
 *       properties:
 *         amount:
 *           type: number
 *           minimum: 0.01
 *           example: 1000
 *           description: Amount to withdraw in USDT
 *         merchantWallet:
 *           type: string
 *           example: "0xED738B258B7c1012a34aD07c049105C8Be84B785"
 *           description: Merchant's wallet address for receiving funds
 *
 *     WithdrawalResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Withdrawal request submitted successfully"
 *         data:
 *           type: object
 *           properties:
 *             withdrawalId:
 *               type: string
 *               example: "60d5ecb74b24a1234567890c"
 *             amount:
 *               type: number
 *               example: 1000
 *             status:
 *               type: string
 *               example: "pending"
 *             clientWallet:
 *               type: string
 *               example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *             createdAt:
 *               type: string
 *               format: date-time
 *               example: "2024-01-01T10:00:00.000Z"
 *         error:
 *           type: string
 *           nullable: true
 *           example: null
 *
 *     WithdrawalActionRequest:
 *       type: object
 *       required:
 *         - action
 *       properties:
 *         action:
 *           type: string
 *           enum: [approve, reject]
 *           example: "approve"
 *           description: Action to take on the withdrawal
 *         fee:
 *           type: number
 *           minimum: 0
 *           example: 50
 *           description: Fee amount (required for approval)
 *         reason:
 *           type: string
 *           example: "Approved by admin"
 *           description: Reason for the action
 *
 *     Withdrawal:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           example: "60d5ecb74b24a1234567890c"
 *         clientId:
 *           type: object
 *           properties:
 *             _id:
 *               type: string
 *               example: "60d5ecb74b24a1234567890a"
 *             name:
 *               type: string
 *               example: "John Doe"
 *             email:
 *               type: string
 *               example: "john@example.com"
 *         amount:
 *           type: number
 *           example: 1000
 *         fee:
 *           type: number
 *           example: 50
 *         netAmount:
 *           type: number
 *           example: 950
 *         clientWallet:
 *           type: string
 *           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *         status:
 *           type: string
 *           enum: [pending, approved, rejected, completed]
 *           example: "pending"
 *         processedBy:
 *           type: string
 *           example: "60d5ecb74b24a1234567890b"
 *         processedAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:05:00.000Z"
 *         reason:
 *           type: string
 *           example: "Approved by admin"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:00:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:05:00.000Z"
 */

/**
 * @swagger
 * /withdrawal:
 *   post:
 *     summary: Request withdrawal
 *     description: Merchant can request a withdrawal from their balance. The request will be pending until admin approval.
 *     tags: [Withdrawals]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WithdrawalRequest'
 *           example:
 *             amount: 1000
 *             merchantWallet: "0xED738B258B7c1012a34aD07c049105C8Be84B785"
 *     responses:
 *       201:
 *         description: Withdrawal request submitted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/WithdrawalResponse'
 *       400:
 *         description: Insufficient balance or validation error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Insufficient balance. Available: 500 USDT, Requested: 1000 USDT"
 *                 error:
 *                   type: string
 *                   example: "Insufficient funds"
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Merchant role required
 *       500:
 *         description: Internal server error
 */
// Merchant withdrawal request endpoint
router.post(
  '/',
  protect,
  authorizeRoles('merchant','admin'),
  withdrawalRequestValidation,
  validateRequest,
  initiateWithdrawal
);

/**
 * @swagger
 * /withdrawal/{withdrawalId}:
 *   patch:
 *     summary: Approve or reject withdrawal
 *     description: Admin or merchant can approve or reject a pending withdrawal request. For approval, fee must be specified.
 *     tags: [Withdrawals]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: withdrawalId
 *         required: true
 *         schema:
 *           type: string
 *         description: Withdrawal request ID
 *         example: "60d5ecb74b24a1234567890c"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WithdrawalActionRequest'
 *           examples:
 *             approve:
 *               summary: Approve withdrawal
 *               value:
 *                 action: "approve"
 *                 fee: 50
 *                 reason: "Approved by admin"
 *             reject:
 *               summary: Reject withdrawal
 *               value:
 *                 action: "reject"
 *                 reason: "Insufficient documentation"
 *     responses:
 *       200:
 *         description: Withdrawal action processed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Withdrawal approved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/Withdrawal'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid action, withdrawal already processed, or validation error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Withdrawal already processed"
 *                 error:
 *                   type: string
 *                   example: "Invalid withdrawal status"
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Withdrawal not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Withdrawal not found"
 *                 error:
 *                   type: string
 *                   example: "Invalid withdrawal ID"
 *       500:
 *         description: Internal server error
 */
// Admin approve/reject withdrawal endpoint
router.patch(
  '/:withdrawalId',
  protect,
  authorizeRoles('admin', 'superadmin'),
  withdrawalActionValidation,
  validateRequest,
  handleWithdrawalStatus
);

/**
 * @swagger
 * /withdrawal:
 *   get:
 *     summary: Get all withdrawal requests
 *     description: Admin can view all withdrawal requests with pagination and filtering options.
 *     tags: [Withdrawals]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of withdrawals per page
 *         example: 20
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, approved, rejected, completed]
 *         description: Filter by withdrawal status
 *         example: "pending"
 *     responses:
 *       200:
 *         description: Withdrawal requests retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 total:
 *                   type: number
 *                   example: 25
 *                 page:
 *                   type: number
 *                   example: 1
 *                 totalPages:
 *                   type: number
 *                   example: 3
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Withdrawal'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
// Admin get all withdrawals endpoint
router.get(
  '/',
  protect,
  authorizeRoles('admin', 'superadmin'),
  validatePagination,
  validateRequest,
  getAllWithdrawals
);

/**
 * @swagger
 * /withdrawal/merchant/{merchantId}:
 *   get:
 *     summary: Get specific merchant's withdrawals
 *     description: Admin can view withdrawal requests for a specific merchant with pagination.
 *     tags: [Withdrawals]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID
 *         example: "60d5ecb74b24a1234567890a"
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of withdrawals per page
 *         example: 20
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, approved, rejected, completed]
 *         description: Filter by withdrawal status
 *         example: "pending"
 *     responses:
 *       200:
 *         description: Merchant withdrawals retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 total:
 *                   type: number
 *                   example: 8
 *                 page:
 *                   type: number
 *                   example: 1
 *                 totalPages:
 *                   type: number
 *                   example: 1
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Withdrawal'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Merchant not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Merchant not found"
 *                 error:
 *                   type: string
 *                   example: "Invalid merchant ID"
 *       500:
 *         description: Internal server error
 */
// Admin get merchant withdrawals endpoint
router.get(
  '/merchant/:merchantId',
  protect,
  authorizeRoles('admin', 'superadmin'),
  validatePagination,
  validateRequest,
  getMerchantWithdrawals
);

/**
 * @swagger
 * /withdrawal/my-withdrawals:
 *   get:
 *     summary: Get merchant's own withdrawals
 *     description: Merchant can view their own withdrawal requests with pagination and filtering.
 *     tags: [Withdrawals]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of withdrawals per page
 *         example: 20
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, approved, rejected, completed]
 *         description: Filter by withdrawal status
 *         example: "pending"
 *     responses:
 *       200:
 *         description: Merchant's withdrawals retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 total:
 *                   type: number
 *                   example: 5
 *                 page:
 *                   type: number
 *                   example: 1
 *                 totalPages:
 *                   type: number
 *                   example: 1
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Withdrawal'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Merchant role required
 *       500:
 *         description: Internal server error
 */
// Merchant get own withdrawals endpoint
router.get(
  '/my-withdrawals',
  protect,
  authorizeRoles('merchant'),
  validatePagination,
  validateRequest,
  getMyWithdrawals
);

module.exports = router;
