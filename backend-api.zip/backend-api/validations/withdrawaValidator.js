const { body, param, query } = require('express-validator');

// ✅ Validation for initiating a withdrawal (client/merchant)
exports.withdrawalRequestValidation = [
  body('amount')
    .isFloat({ gt: 0.01 })
    .withMessage('Amount must be a number greater than 0.01 USDT'),
  body('merchantWallet')
    .isString()
    .withMessage('Client wallet address is required'),
];
// ✅ Validation for admin approving/rejecting a withdrawal
exports.withdrawalActionValidation = [
  param('withdrawalId')
    .isMongoId()
    .withMessage('Valid withdrawal ID is required'),
  body('action')
    .isIn(['approve', 'reject'])
    .withMessage('Action must be either "approve" or "reject"'),
  body('adminNotes')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Admin notes must be less than 500 characters'),
];
