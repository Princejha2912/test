const { body } = require('express-validator');

const validateTransactionRequest = [
  body('walletAddress')
    .isString().withMessage('Wallet address must be a string')
    .isLength({ min: 10 }).withMessage('Wallet address must be at least 10 characters long'),

  body('message')
    .optional()
    .isString().withMessage('Message must be a string'),

  body('subject')
    .isString().withMessage('Subject must be a string')
    .isLength({ min: 3 }).withMessage('Subject must be at least 3 characters'),

  body('amount')
    .isFloat({ gt: 0 }).withMessage('Amount must be a number greater than 0'),

  body('currencyType')
    .isIn(['USDT-ERC20', 'USDT-TRC20']).withMessage('Currency type must be either USDT-ERC20 or USDT-TRC20'),
];

module.exports = {
validateTransactionRequest
};