const { body, param, query } = require('express-validator');

// Notification ID validation
exports.notificationIdValidation = [
  param('notificationId')
    .isMongoId()
    .withMessage('Valid notification ID is required'),
];

// Create custom notification validation
exports.createNotificationValidation = [
  body('type')
    .isIn([
      'deposit_success',
      'deposit_failed', 
      'deposit_timeout',
      'withdrawal_request',
      'withdrawal_approved',
      'withdrawal_rejected',
      'withdrawal_completed',
      'merchant_approved',
      'merchant_blocked',
      'merchant_registered',
      'password_reset',
      'admin_alert',
      'system_alert',
      'balance_update',
      'api_access_granted',
      'api_access_revoked'
    ])
    .withMessage('Invalid notification type'),

  body('recipientId')
    .isMongoId()
    .withMessage('Valid recipient ID is required'),

  body('title')
    .isLength({ min: 1, max: 200 })
    .withMessage('Title must be between 1 and 200 characters'),

  body('message')
    .isLength({ min: 1, max: 1000 })
    .withMessage('Message must be between 1 and 1000 characters'),

  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'critical'])
    .withMessage('Priority must be low, medium, high, or critical'),

  body('emailSubject')
    .optional()
    .isLength({ max: 200 })
    .withMessage('Email subject must be less than 200 characters'),

  body('emailBody')
    .optional()
    .isLength({ max: 5000 })
    .withMessage('Email body must be less than 5000 characters'),

  body('sendEmail')
    .optional()
    .isBoolean()
    .withMessage('sendEmail must be a boolean value'),

  body('relatedData')
    .optional()
    .isObject()
    .withMessage('relatedData must be an object'),
];

// Notification filtering validation
exports.notificationFilterValidation = [
  query('status')
    .optional()
    .isIn(['pending', 'sent', 'delivered', 'failed', 'read'])
    .withMessage('Invalid status filter'),

  query('type')
    .optional()
    .isIn([
      'deposit_success',
      'deposit_failed', 
      'deposit_timeout',
      'withdrawal_request',
      'withdrawal_approved',
      'withdrawal_rejected',
      'withdrawal_completed',
      'merchant_approved',
      'merchant_blocked',
      'merchant_registered',
      'password_reset',
      'admin_alert',
      'system_alert',
      'balance_update',
      'api_access_granted',
      'api_access_revoked'
    ])
    .withMessage('Invalid type filter'),

  query('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'critical'])
    .withMessage('Invalid priority filter'),

  query('unreadOnly')
    .optional()
    .isBoolean()
    .withMessage('unreadOnly must be a boolean value'),

  query('userId')
    .optional()
    .isMongoId()
    .withMessage('Invalid user ID filter'),

  query('startDate')
    .optional()
    .isISO8601()
    .withMessage('Invalid start date format'),

  query('endDate')
    .optional()
    .isISO8601()
    .withMessage('Invalid end date format'),

  query('days')
    .optional()
    .isInt({ min: 1, max: 365 })
    .withMessage('Days must be between 1 and 365'),
];
