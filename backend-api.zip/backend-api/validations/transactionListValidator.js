const { body, query, param } = require('express-validator');

/**
 * Validation for merchant transaction list
 */
const merchantTransactionListValidation = [
  // Pagination validation
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer')
    .toInt(),

  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
    .toInt(),

  // Status filter validation
  query('status')
    .optional()
    .isIn(['initiated', 'confirmed', 'failed', 'expired', 'pending', 'api_failed'])
    .withMessage('Invalid status. Must be one of: initiated, confirmed, failed, expired, pending, api_failed'),

  // Currency type validation
  query('currencyType')
    .optional()
    .isIn(['USDT-ERC20', 'USDT-TRC20'])
    .withMessage('Invalid currency type. Must be USDT-ERC20 or USDT-TRC20'),

  // Sort field validation
  query('sortBy')
    .optional()
    .isIn(['createdAt', 'amount', 'status', 'confirmedAt'])
    .withMessage('Invalid sort field. Must be one of: createdAt, amount, status, confirmedAt'),

  // Sort order validation
  query('sortOrder')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage('Invalid sort order. Must be asc or desc'),

  // Date range validation
  query('dateFrom')
    .optional()
    .isISO8601()
    .withMessage('Invalid dateFrom format. Use YYYY-MM-DD'),

  query('dateTo')
    .optional()
    .isISO8601()
    .withMessage('Invalid dateTo format. Use YYYY-MM-DD')
];

/**
 * Validation for admin transaction list
 */
const adminTransactionListValidation = [
  // Pagination validation
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer')
    .toInt(),

  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
    .toInt(),

  // Status filter validation
  query('status')
    .optional()
    .isIn(['initiated', 'confirmed', 'failed', 'expired', 'pending', 'api_failed'])
    .withMessage('Invalid status. Must be one of: initiated, confirmed, failed, expired, pending, api_failed'),

  // Currency type validation
  query('currencyType')
    .optional()
    .isIn(['USDT-ERC20', 'USDT-TRC20'])
    .withMessage('Invalid currency type. Must be USDT-ERC20 or USDT-TRC20'),

  // Merchant ID validation
  query('merchantId')
    .optional()
    .isMongoId()
    .withMessage('Invalid merchant ID format'),

  // Merchant email validation
  query('merchantEmail')
    .optional()
    .isEmail()
    .withMessage('Invalid email format')
    .normalizeEmail(),

  // Sort field validation
  query('sortBy')
    .optional()
    .isIn(['createdAt', 'amount', 'status', 'confirmedAt', 'merchant.name', 'merchant.email'])
    .withMessage('Invalid sort field. Must be one of: createdAt, amount, status, confirmedAt, merchant.name, merchant.email'),

  // Sort order validation
  query('sortOrder')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage('Invalid sort order. Must be asc or desc'),

  // Date range validation
  query('dateFrom')
    .optional()
    .isISO8601()
    .withMessage('Invalid dateFrom format. Use YYYY-MM-DD'),

  query('dateTo')
    .optional()
    .isISO8601()
    .withMessage('Invalid dateTo format. Use YYYY-MM-DD')
    .custom((value, { req }) => {
      if (req.query.dateFrom && value) {
        const fromDate = new Date(req.query.dateFrom);
        const toDate = new Date(value);
        if (toDate < fromDate) {
          throw new Error('dateTo must be after dateFrom');
        }
      }
      return true;
    })
];

/**
 * Validation for admin merchant-specific transaction list
 */
const adminMerchantTransactionValidation = [
  // Just ensure merchantId exists (no MongoID check)
  param('merchantId')
    .notEmpty()
    .withMessage('merchantId is required'),

  // Pagination for deposits
  query('pageDeposits')
    .optional()
    .isInt({ min: 1 })
    .withMessage('pageDeposits must be a positive integer')
    .toInt(),

  // Pagination for withdrawals
  query('pageWithdrawals')
    .optional()
    .isInt({ min: 1 })
    .withMessage('pageWithdrawals must be a positive integer')
    .toInt(),

  // Common limit
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
    .toInt()
]


// Validation middleware
const validateCreateTransaction = [
  query('amount')
    .exists().withMessage('Amount is required')
    .isFloat({ gt: 0 }).withMessage('Amount must be a number greater than 0'),

  query('currencyType')
    .exists().withMessage('currencyType is required')
    .isString().withMessage('currencyType must be a string')
    .isIn(['USDT-ERC20', 'USDT-TRC20']) // adjust as per allowed values
    .withMessage('Invalid currencyType'),

  query('callbackUrl')
    .optional()
    .isURL().withMessage('callbackUrl must be a valid URL'),

  query('failbackUrl')
    .optional()
    .isURL().withMessage('failbackUrl must be a valid URL'),

]
module.exports = {
  merchantTransactionListValidation,
  adminTransactionListValidation,
  adminMerchantTransactionValidation,
  validateCreateTransaction
};
