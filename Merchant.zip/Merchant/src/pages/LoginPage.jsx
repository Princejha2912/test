
import React from "react";
import Login from "../components/Login";

const DashboardPage = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default DashboardPage;
