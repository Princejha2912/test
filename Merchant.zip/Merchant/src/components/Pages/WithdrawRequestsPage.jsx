import React, { useState, useEffect } from "react";
import {
  ArrowUpRight,
  Clock,
  CheckCircle,
  AlertCircle,
  Wallet,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Send,
  CreditCard,
  TrendingUp,
  ArrowLeft,
  Copy,
  Filter,
  Calendar,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const WithdrawRequestsPage = () => {
  const navigate = useNavigate();
  const [amount, setAmount] = useState("");
  const [merchantWallet, setMerchantWallet] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [withdrawals, setWithdrawals] = useState([]);
  const [allWithdrawals, setAllWithdrawals] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const ITEMS_PER_PAGE = 10;
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [currencyType, setCurrencyType] = useState("USDT-ERC20");
  const [globalTotalRequests, setGlobalTotalRequests] = useState(0);
  const [globalTotalApproved, setGlobalTotalApproved] = useState(0);
  const [globalTotalPending, setGlobalTotalPending] = useState(0);
  const [globalTotalFailed, setGlobalTotalFailed] = useState(0);
  const [globalPendingAmount, setGlobalPendingAmount] = useState(0);
  const [globalFailedAmount, setGlobalFailedAmount] = useState(0);
  const [globalTotalRejected, setGlobalTotalRejected] = useState(0);

  // Filter states
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const API_BASE_URL = "https://backend.payglobal.co.in/api/v1";
  // const API_BASE_URL = "http://localhost:5000/api/v1";

  // Filter withdrawals based on date and status
  const filterWithdrawals = (data) => {
    let filtered = data.filter(transaction => transaction.type !== "refund");

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter(w => w.status === statusFilter);
    }

    // Date filter
    if (dateFilter !== "all") {
      const now = new Date();

      filtered = filtered.filter(w => {
        const wDate = new Date(w.createdAt);

        switch (dateFilter) {
          case "today":
            return wDate.toDateString() === now.toDateString();
          case "week":
            const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            return wDate >= weekAgo;
          case "month":
            const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            return wDate >= monthAgo;
          case "custom":
            if (startDate && endDate) {
              const start = new Date(startDate);
              const end = new Date(endDate);
              end.setHours(23, 59, 59, 999); // Include the entire end date
              return wDate >= start && wDate <= end;
            }
            return true;
          default:
            return true;
        }
      });
    }

    return filtered;
  };

  // Apply client-side pagination to filtered data
  const applyPagination = (filteredData) => {
    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const paginatedData = filteredData.slice(startIndex, endIndex);
    const totalPagesCalculated = Math.ceil(filteredData.length / ITEMS_PER_PAGE);

    setWithdrawals(paginatedData);
    setTotalPages(totalPagesCalculated);
  };

  // Fetch ALL withdrawals from all pages
  const fetchAllWithdrawals = async () => {
    setLoading(true);
    try {
      let pageNum = 1;
      let allData = [];
      let totalPagesLocal = 1;

      do {
        const response = await fetch(
          `${API_BASE_URL}/withdrawal/my-withdrawals?page=${pageNum}&limit=50`,
          {
            method: "GET",
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        const data = await response.json();

        if (response.ok) {
          allData = [...allData, ...data.data];
          totalPagesLocal = data.totalPages;
          pageNum++;
        } else {
          setError(data.message);
          break;
        }
      } while (pageNum <= totalPagesLocal);

      // Store all withdrawals
      setAllWithdrawals(allData);

      // Apply filters and pagination
      const filteredData = filterWithdrawals(allData);
      applyPagination(filteredData);

    } catch (err) {
      setError("An error occurred while fetching withdrawals.");
    } finally {
      setLoading(false);
    }
  };

  // Handle page change for client-side pagination
  const handlePageChange = (newPage) => {
    if (newPage > 0 && newPage <= totalPages) {
      setPage(newPage);
    }
  };

  // Apply filters when filter state changes
  useEffect(() => {
    if (allWithdrawals.length > 0) {
      const filteredData = filterWithdrawals(allWithdrawals);
      setPage(1); // Reset to first page when filters change
      applyPagination(filteredData);
    }
  }, [statusFilter, dateFilter, startDate, endDate]);

  // Apply pagination when page changes
  useEffect(() => {
    if (allWithdrawals.length > 0) {
      const filteredData = filterWithdrawals(allWithdrawals);
      applyPagination(filteredData);
    }
  }, [page]);

  // Initial data fetch
  useEffect(() => {
    fetchAllWithdrawals();
  }, []);

  const fetchAllWithdrawalsForStats = async () => {
    try {
      // Use the already fetched data for stats calculation
      const allData = allWithdrawals.length > 0 ? allWithdrawals : [];

      if (allData.length === 0) return;

      // Filter out refunds and apply current filters for stats
      const filteredData = filterWithdrawals(allData);

      // Filter by status
      const approvedItems = filteredData.filter(w => w.status === "completed");
      const pendingItems = filteredData.filter(w => w.status === "pending");
      const failedItems = filteredData.filter(w => w.status === "failed");
      const rejectedItems = filteredData.filter(w => w.status === "rejected");

      // Aggregate
      setGlobalTotalRequests(filteredData.length);
      setGlobalTotalApproved(
        approvedItems.reduce((sum, w) => sum + parseFloat(w.amount || 0), 0)
      );
      setGlobalTotalPending(pendingItems.length);
      setGlobalTotalFailed(failedItems.length);

      setGlobalPendingAmount(
        pendingItems.reduce((sum, w) => sum + parseFloat(w.amount || 0), 0)
      );
      setGlobalFailedAmount(
        failedItems.reduce((sum, w) => sum + parseFloat(w.amount || 0), 0)
      );
      setGlobalTotalRejected(
        rejectedItems.reduce((sum, w) => sum + parseFloat(w.amount || 0), 0)
      );

    } catch (err) {
      console.error("Error calculating stats:", err);
    }
  };

  useEffect(() => {
    fetchAllWithdrawalsForStats();
  }, [allWithdrawals, statusFilter, dateFilter, startDate, endDate]);

  // Handle form submit to initiate withdrawal
  const handleSubmit = async () => {
    setError("");
    setSuccessMessage("");

    if (!amount || !merchantWallet) {
      setError("Please fill in all fields");
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/withdrawal`, {
        // ✅ use correct endpoint
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: parseFloat(amount),
          merchantWallet: merchantWallet,
          currencyType: currencyType, // ✅ or dynamically set if you want
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccessMessage(
          data.message || "Withdrawal request submitted successfully."
        );
        setAmount("");
        setMerchantWallet("");
        fetchAllWithdrawals(); // ✅ refresh list
      } else {
        setError(
          data.message || "Something went wrong while submitting withdrawal."
        );
      }
    } catch (err) {
      setError("An error occurred while processing your request.");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-700 border-green-300";
      case "confirmed":
        return "bg-green-100 text-green-700 border-green-300";
      case "pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "failed":
        return "bg-red-100 text-red-700 border-red-300";
      case "rejected":
        return "bg-red-100 text-red-700 border-red-300";
      default:
        return "bg-gray-100 text-gray-600 border-gray-300";
    }
  };

  // Refresh data
  const refreshData = () => {
    setIsRefreshing(true);
    fetchAllWithdrawals();
    setTimeout(() => setIsRefreshing(false), 1500);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div className="mb-4 md:mb-0 ">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => navigate(-1)}
                className="p-2 rounded-lg hover:bg-blue-100 transition-colors"
                title="Back"
              >
                <ArrowLeft className="w-5 h-5 text-blue-600" />
              </button>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
                Payout Requests
              </h2>
            </div>
            <p className="text-gray-600 text-sm md:text-base">
              Submit new Payout requests and track their status
            </p>
          </div>
          <div className="flex flex-row md:items-center md:justify-between mb-8 gap-4 md:gap-8">
            <button
              onClick={refreshData}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg font-medium transition-all duration-300 inline-flex items-center justify-center space-x-2 shadow-lg hover:shadow-blue-500/25 w-auto"
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`}
              />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg font-medium transition-all duration-300 inline-flex items-center justify-center space-x-2 shadow-lg hover:shadow-purple-500/25 w-auto"
            >
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filters</span>
            </button>
          </div>

        </div>

        {/* Filters Section */}
        {showFilters && (
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-lg mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Status Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filter by Status
                </label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="completed">Completed</option>
                  <option value="failed">Failed</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>

              {/* Date Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filter by Date
                </label>
                <select
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Time</option>
                  <option value="today">Today</option>
                  <option value="week">Last 7 Days</option>
                  <option value="month">Last 30 Days</option>
                  <option value="custom">Custom Range</option>
                </select>
              </div>

              {/* Custom Date Range */}
              {dateFilter === "custom" && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}
            </div>

            {/* Clear Filters Button */}
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => {
                  setStatusFilter("all");
                  setDateFilter("all");
                  setStartDate("");
                  setEndDate("");
                }}
                className="px-4 py-2 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
              >
                Clear Filters
              </button>
            </div>
          </div>
        )}

        {/* Success and Error Messages */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-center space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            <span className="text-red-700">{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-4 flex items-center space-x-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <span className="text-green-700">{successMessage}</span>
          </div>
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Payout Form */}
          <div className="lg:col-span-1 bg-white border border-gray-200 rounded-xl p-6 shadow-xl">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center shadow-lg">
                <Send className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">
                  New Payout
                </h3>
                <p className="text-sm text-gray-600">Submit a Payout request</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label
                  htmlFor="currencyType"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Currency Type
                </label>
                <select
                  id="currencyType"
                  value={currencyType}
                  onChange={(e) => setCurrencyType(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                >
                  <option value="USDT-TRC20">USDT-TRC20</option>
                  <option value="USDT-ERC20">USDT-ERC20</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="amount"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Amount (USDT)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    id="amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full px-4 py-3 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  />
                  <CreditCard className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label
                  htmlFor="merchantWallet"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Merchant Wallet Address
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="merchantWallet"
                    value={merchantWallet}
                    onChange={(e) => setMerchantWallet(e.target.value)}
                    placeholder="Enter wallet address"
                    className="w-full px-4 py-3 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  />
                  <Wallet className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                </div>
              </div>

              <button
                onClick={handleSubmit}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 shadow-lg hover:shadow-blue-500/25 flex items-center justify-center space-x-2"
              >
                <Send className="w-5 h-5" />
                <span>Submit Payout Request</span>
              </button>
            </div>

            {/* Quick Stats */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              {/* Total & Approved */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-800">
                    {globalTotalRequests}
                  </div>
                  <div className="text-xs text-gray-600">Total Requests</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-600">
                    {globalTotalApproved.toFixed(2)} USDT
                  </div>
                  <div className="text-xs text-gray-600">Total Amount Approved</div>
                </div>
              </div>

              {/* Pending */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-yellow-600">
                    {globalTotalPending}
                  </div>
                  <div className="text-xs text-gray-600">Pending Requests</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-yellow-600">
                    {globalPendingAmount.toFixed(2)} USDT
                  </div>
                  <div className="text-xs text-gray-600">Pending Amount</div>
                </div>
              </div>
            </div>

          </div>

          {/* Payout History */}
          <div className="lg:col-span-2 bg-white border border-gray-200 rounded-xl overflow-hidden shadow-xl">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center shadow-lg">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      Payout History
                    </h3>
                    <p className="text-sm text-gray-600">
                      Track your Payout requests
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <div className="divide-y divide-gray-200 min-h-[400px]">
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
                    <span className="ml-3 text-gray-600">
                      Loading withdrawals...
                    </span>
                  </div>
                ) : withdrawals.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Wallet className="w-16 h-16 text-gray-300 mb-4" />
                    <p className="text-gray-500 text-lg">
                      No Payout requests found
                    </p>
                    <p className="text-gray-400 text-sm">
                      Submit your first Payout request above
                    </p>
                  </div>
                ) : (
                  withdrawals.map((withdrawal) => (
                    <div
                      key={withdrawal._id}
                      className="p-4 hover:bg-gray-50 transition-colors duration-200 group"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <ArrowUpRight className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="text-gray-800 font-medium">
                                Payout Request
                              </span>
                              <span
                                className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                                  withdrawal.status
                                )}`}
                              >
                                {withdrawal.status.toUpperCase()}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-500 text-sm">
                                {withdrawal.clientWallet.slice(0, 12)}...
                                {withdrawal.clientWallet.slice(-6)}
                              </span>
                              <button
                                onClick={() =>
                                  copyToClipboard(withdrawal.clientWallet)
                                }
                                className="text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
  {/* Amount with Status-based Colors */}
  <div
    className={`text-lg font-semibold ${
      withdrawal.status === "completed"
        ? "text-green-600"
        : withdrawal.status === "rejected"
        ? "text-red-600"
        : withdrawal.status === "pending"
        ? "text-orange-600"
        : "text-gray-500"
    }`}
  >
    {/* Remove negative sign */}
   {withdrawal.status === "completed" ? `-${Math.abs(withdrawal.amount).toFixed(2)}` : Math.abs(withdrawal.amount).toFixed(2)}

  </div>
  {/* Uncomment if you need to show fee */}
  {/* <div className="text-sm text-red-600">
    Fee-{withdrawal.fee} USDT
  </div> */}
  {/* Uncomment if you want to show net amount */}
  {/* <div className="text-sm text-red-600">
    Received Amount -{(withdrawal.netAmount)?.toFixed(3)} USDT
  </div> */}
  <div className="text-sm text-gray-500">
    {new Date(withdrawal.createdAt).toLocaleDateString()}{" "}
    {new Date(withdrawal.createdAt).toLocaleTimeString()}
  </div>
</div>

                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Pagination */}
            {withdrawals.length > 0 && (
              <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => handlePageChange(page - 1)}
                    disabled={page === 1}
                    className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-700">
                      Page <span className="font-medium">{page}</span> of{" "}
                      <span className="font-medium">{totalPages}</span>
                    </span>
                  </div>

                  <button
                    onClick={() => handlePageChange(page + 1)}
                    disabled={page === totalPages}
                    className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div >
  );
};

export default WithdrawRequestsPage;