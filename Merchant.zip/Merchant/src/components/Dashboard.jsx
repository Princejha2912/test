import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  TrendingDown,
  Clock,
  CheckCircle,
  AlertCircle,
  Wallet,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Eye,
  Copy,
  MessageSquare,
  ExternalLink,
  QrCode,
} from "lucide-react";

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [complaintsError, setComplaintsError] = useState(null);
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [userId, setUserId] = useState("");
  const [apiCredentialsLoading, setApiCredentialsLoading] = useState(false);

  // const API_BASE_URL = "http://localhost:5000/api/v1";
  const API_BASE_URL = "https://backend.payglobal.co.in/api/v1";

  // Get user data from localStorage
  const getUserDataFromStorage = () => {
    try {
      const storedUserId = localStorage.getItem("userId");
      const storedUserRole = localStorage.getItem("userRole");
      const storedUserEmail = localStorage.getItem("userEmail");
      const storedExpiry = localStorage.getItem("token_expiry");

      if (!storedUserId) {
        console.error("No userId found in localStorage");
        return null;
      }

      // Check if session has expired
      if (storedExpiry && Date.now() > parseInt(storedExpiry)) {
        console.error("Session expired");
        localStorage.clear();
        window.location.href = "#/";
        return null;
      }

      setUserId(storedUserId);
      return storedUserId;
    } catch (error) {
      console.error("Failed to get user data from localStorage:", error);
      return null;
    }
  };

  // Fetch API credentials
  const fetchApiKey = async () => {
    const currentUserId = getUserDataFromStorage();

    if (!currentUserId) {
      console.log("No valid user ID found, stopping API call");
      return;
    }

    console.log("Making API call with userId:", currentUserId);

    try {
      setApiCredentialsLoading(true);
      const response = await fetch(
        `${API_BASE_URL}/merchant/${currentUserId}`,
        {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Response status:", response.status);
      console.log("Response headers:", [...response.headers.entries()]);

      if (!response.ok) {
        throw new Error(
          `Failed to fetch API key: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      console.log("Full API response data:", data);

      // Try different possible locations for the API key and secret
      let foundApiKey = null;
      let foundApiSecret = null;

      // Check for API Key
      if (data && data.apiKey) {
        foundApiKey = data.apiKey;
      } else if (data && data.data && data.data.apiKey) {
        foundApiKey = data.data.apiKey;
      } else if (data && data.merchant && data.merchant.apiKey) {
        foundApiKey = data.merchant.apiKey;
      } else if (data && data.api_key) {
        foundApiKey = data.api_key;
      } else if (data && data.key) {
        foundApiKey = data.key;
      }

      // Check for API Secret
      if (data && data.apiSecret) {
        foundApiSecret = data.apiSecret;
      } else if (data && data.data && data.data.apiSecret) {
        foundApiSecret = data.data.apiSecret;
      } else if (data && data.merchant && data.merchant.apiSecret) {
        foundApiSecret = data.merchant.apiSecret;
      } else if (data && data.api_secret) {
        foundApiSecret = data.api_secret;
      } else if (data && data.secret) {
        foundApiSecret = data.secret;
      }

      let hasErrors = false;
      let errorMessages = [];

      if (foundApiKey) {
        setApiKey(foundApiKey);
      } else {
        hasErrors = true;
        errorMessages.push("API Key not found in response");
      }

      if (foundApiSecret) {
        setApiSecret(foundApiSecret);
      } else {
        hasErrors = true;
        errorMessages.push("API Secret not found in response");
      }

      if (hasErrors) {
        console.error(
          errorMessages.join(". ") + ". Check the API response structure."
        );
        console.log("Available keys in response:", Object.keys(data));
      }
    } catch (error) {
      console.error("Error fetching API credentials:", error);
    } finally {
      setApiCredentialsLoading(false);
    }
  };

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/dashboard/merchant`, {
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setDashboardData(data.data);
        setError(null);
      } else {
        throw new Error(data.error || "Failed to fetch dashboard data");
      }
    } catch (err) {
      console.error("Error fetching dashboard data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  const fetchComplaints = async () => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/refund/merchant?page=1&limit=3`,
        {
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      if (data.success) {
        setComplaints(data.data || []);
      } else {
        throw new Error(data.error || "Failed to fetch complaints");
      }
    } catch (err) {
      console.error("Error fetching complaints:", err);
      setComplaints([]);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchDashboardData();
    fetchComplaints();
    fetchApiKey(); // Fetch API credentials on mount
  }, []);

  const refreshData = async () => {
    setIsRefreshing(true);
    await fetchDashboardData();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  // Process transactions for display
  const processTransactions = () => {
    if (!dashboardData?.recentTransactions) return [];

    const deposits = dashboardData.recentTransactions.deposits || [];
    const withdrawals = dashboardData.recentTransactions.withdrawals || [];

    // Sort each list individually
    const sortedDeposits = deposits
      .slice()
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 5);

    const sortedWithdrawals = withdrawals
      .slice()
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 5);

    const depositTx = sortedDeposits.map((deposit, index) => ({
      id: `deposit_${index}`,
      type: "Deposit",
      amount: deposit.actualBalance || 0,
      status: deposit.status || "pending",
      time: deposit.createdAt
        ? new Date(deposit.createdAt).toLocaleString()
        : "N/A",
      hash: deposit.walletAddress
        ? `${deposit.walletAddress.slice(0, 6)}...`
        : "N/A",
      fullHash: deposit.walletAddress || "",
      network: deposit.currencyType || "USDT-ERC20",
    }));

    const withdrawalTx = sortedWithdrawals.map((withdrawal, index) => ({
      id: `withdrawal_${index}`,
      type: "Payout",
      amount: withdrawal.amount || 0,
      status:
        withdrawal.status === "completed"
          ? "confirmed"
          : withdrawal.status || "pending",
      time: withdrawal.createdAt
        ? new Date(withdrawal.createdAt).toLocaleString()
        : "N/A",
      hash: withdrawal.clientWallet
        ? `${withdrawal.clientWallet.slice(0, 6)}...`
        : "N/A",
      fullHash: withdrawal.clientWallet || "",
      network: withdrawal.currencyType || "USDT-ERC20",
    }));

    // Combine and sort all 10 together if needed by time
    const allTx = [...depositTx, ...withdrawalTx];
    return allTx.sort((a, b) => new Date(b.time) - new Date(a.time));
  };

  console.log("Transactions", processTransactions);
  // Calculate stats from API data
  const getStats = () => {
    if (!dashboardData) return [];

    // Parse avgTransaction to ensure it's a number and not NaN
    const avgTransaction = Number(dashboardData.avgTransaction);

    return [
      {
        label: "Today's Deposit Volume",
        value: dashboardData.todayVolume?.toFixed(2) || "0.00",
        // change: '+0.0%',
        trend: "up",
      },
      {
        label: "Today's Success Rate",
        value: dashboardData.successRate || "0%",
        // change: '+0.0%',
        trend: "up",
      },
      {
        label: "Today's Avg. Transaction",
        value: !isNaN(avgTransaction) ? avgTransaction.toFixed(2) : "0.00", // Check if it's a valid number
        // change: '+0.0%',
        trend: "up",
      },
    ];
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "confirmed":
      case "completed":
        return "bg-green-100 text-green-700 border-green-300";
      case "initiated":
        return "bg-orange-200 text-yellow-700 border-orange-300";
      case "pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "failed":
        return "bg-red-100 text-red-700 border-red-300";
      default:
        return "bg-gray-100 text-gray-600 border-gray-300";
    }
  };

  const getComplaintStatusColor = (status) => {
    switch (status) {
      case "resolved":
        return "bg-green-100 text-green-700 border-green-300";
      case "pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "in-progress":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "rejected":
        return "bg-red-100 text-red-700 border-red-300";
      default:
        return "bg-gray-100 text-gray-600 border-gray-300";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-8 h-8 text-red-600 mx-auto mb-4" />
          <p className="text-red-600 mb-4">Error loading dashboard: {error}</p>
          <button
            onClick={refreshData}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }
  // Generate QR Generator URL
  const generateQRGeneratorUrl = () => {
    const baseUrl = "https://gateway.payglobal.co.in";
    // const baseUrl = "http://localhost:3003";

    return `${baseUrl}/qr-generator?api_key=${apiKey}&api_secret=${apiSecret}`;
  };

  // Open QR Generator in new tab
  const openQRGenerator = () => {
    console.log(
      "QR Generator clicked. API Key:",
      apiKey ? "Available" : "Not available",
      "API Secret:",
      apiSecret ? "Available" : "Not available"
    );
    if (apiKey && apiSecret) {
      const url = generateQRGeneratorUrl();
      console.log("Opening QR Generator URL:", url);
      window.open(url, "_blank");
    } else {
      console.error(
        "API credentials not available. API Key:",
        !!apiKey,
        "API Secret:",
        !!apiSecret
      );
      alert("API credentials not available. Please try refreshing the page.");
    }
  };
  const transactions = processTransactions().slice(0, 10);

  const stats = getStats();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div className="mb-4 md:mb-0">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
              Merchant Dashboard
            </h2>
            <p className="text-gray-600 text-sm md:text-base">
              Monitor your crypto payments and track performance in real-time
            </p>
          </div>

          <div className="flex items-center space-x-3">
            {/* <select 
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
              className="bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
            >
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
            </select> */}
            <button
              onClick={openQRGenerator}
              // disabled={isRefreshing}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-blue-500/25 disabled:opacity-50"
              disabled={apiCredentialsLoading}
            >
              <QrCode
                className={`w-4 h-4 ${apiCredentialsLoading ? "animate-spin" : ""
                  }`}
              />
              <span className="hidden sm:inline">QR Generator</span>
            </button>
            <button
              onClick={refreshData}
              disabled={isRefreshing}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-blue-500/25 disabled:opacity-50"
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`}
              />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-xl p-6 hover:bg-gray-50 transition-all duration-300 group shadow-lg"
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-gray-600 text-sm font-medium">
                  {stat.label}
                </h3>
                {stat.trend === "up" ? (
                  <ArrowUpRight className="w-4 h-4 text-green-600" />
                ) : (
                  <ArrowDownRight className="w-4 h-4 text-red-600" />
                )}
              </div>
              <div className="flex items-end space-x-2">
                <span className="text-2xl font-bold text-gray-800">
                  {stat.value}
                </span>
                <span
                  className={`text-sm font-medium ${stat.trend === "up" ? "text-green-600" : "text-red-600"
                    }`}
                >
                  {stat.change}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Transaction History */}
        <div className="lg:col-span-2 bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl overflow-hidden shadow-xl">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center shadow-lg">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    Transaction History
                  </h3>
                  <p className="text-sm text-gray-600">
                    Recent payment activities
                  </p>
                </div>
              </div>
              <button
                onClick={() => navigate("/transactions")}
                className="text-blue-500 hover:text-blue-600 transition-colors duration-300"
              >
                <Eye className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <div className="divide-y divide-gray-200">
              {transactions.length > 0 ? (
                transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-4 hover:bg-gray-50 transition-colors duration-200 group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center ${tx.type === "Payout" ? "bg-red-100" : "bg-green-100"
                            }`}
                        >
                          {tx.type === "Payout" ? (
                            <ArrowDownRight className="w-5 h-5 text-red-600" />
                          ) : (
                            <ArrowUpRight className="w-5 h-5 text-green-600" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-800 font-medium">
                              {tx.type}
                            </span>
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                                tx.status
                              )}`}
                            >
                              {tx.status.toUpperCase()}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            <span className="text-gray-500 text-sm">
                              {tx.hash}
                            </span>
                            <span className="text-gray-400 text-xs">
                              {tx.network}
                            </span>
                            {tx.fullHash && (
                              <button
                                className="text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                                onClick={() =>
                                  navigator.clipboard.writeText(tx.fullHash)
                                }
                                title="Copy full hash"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`text-lg font-semibold ${tx.status === "failed"
                              ? "text-red-600" // failed -> red
                              : tx.status === "initiated"
                                ? "text-orange-600"
                                 : tx.status === "pending"
                                ? "text-orange-600"
                                : tx.status === "rejected"
                                ? "text-gray-600"
                                : tx.status === "expired"
                                ? "text-gray-600"
                                : tx.type === "Deposit"
                                  ? "text-green-600"
                                  : "text-red-600"
                            }`}
                        >
                          {
                            tx.status === "failed"
                              ? `${tx.amount}` // failed -> no plus sign
                              : tx.status === "initiated"
                                ? `${tx.amount}` // initiated -> no plus sign
                                : tx.status === "pending"
                                ? `${tx.amount}` // initiated -> no - sign
                                : tx.status === "rejected"
                                ? `${tx.amount}`
                                : tx.status === "expired"
                                ? `${tx.amount}`
                                : tx.type === "Deposit"
                                  ? `+${tx.amount}` // successful deposit
                                  : `-${tx.amount}` // payout
                          }{" "}
                          USDT
                        </div>


                        <div className="text-sm text-gray-500">{tx.time}</div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No transactions found</p>
                </div>
              )}
            </div>
          </div>

          <div className="p-4 border-t border-gray-200">
            <button
              onClick={() => navigate("/transactions")}
              className="w-full text-center text-blue-600 hover:text-blue-700 text-sm font-medium py-2 transition-colors duration-200"
            >
              View All Transactions
            </button>
          </div>
        </div>

        {/* Sidebar Cards */}
        <div className="space-y-6">
          {/* Real-time Balance */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 relative overflow-hidden shadow-lg">
            <div className="relative">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                    <Wallet className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">
                      Real-time Balance
                    </h3>
                    <p className="text-sm text-blue-700">Live wallet status</p>
                  </div>
                </div>
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">

                    <span className="text-blue-700 text-sm">Receivable</span>
                  </div>
                  <div className="flex items-center justify-between mb-2">

                    <div className="text-xl font-bold text-gray-800">
                      {(
                        (dashboardData?.realTimeBalance *
                          (100 - dashboardData.user.feeAmt)) /
                        100
                      ).toFixed(2)}{" "}
                      <span className="text-lg text-blue-700">USDT</span>
                    </div>

                  </div>
                </div>

                {/* <div className="pt-4 border-t border-blue-200">
                  <div className="flex justify-between text-sm">
                    <span className="text-blue-700">Available</span>
                    <span className="text-gray-800 font-medium">{dashboardData?.availableBalance?.toFixed(2) || '0.00'} USDT</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-blue-700">Pending</span>
                    <span className="text-yellow-600 font-medium">{dashboardData?.pendingBalance?.toFixed(2) || '0.00'} USDT</span>
                  </div>
                </div> */}
              </div>
            </div>
          </div>

          {/* Earnings Overview */}
          {/* <div className="bg-gradient-to-br from-green-50 to-emerald-50 backdrop-blur-lg border border-green-200 rounded-xl p-6 relative overflow-hidden shadow-lg">
            <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-br from-green-200/50 to-emerald-200/50 rounded-full blur-xl"></div>
            <div className="relative">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center shadow-lg">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Earnings Overview</h3>
                  <p className="text-sm text-green-700">Monthly performance</p>
                </div>
              </div> */}

          {/* <div className="space-y-4">
                <div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    {dashboardData?.earningsOverview?.thisMonth?.toFixed(2) || '0.00'} <span className="text-lg text-green-700">USDT</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <ArrowUpRight className="w-4 h-4 text-green-600" />
                    <span className="text-green-600 text-sm font-medium">Monthly earnings</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-green-200">
                  <div>
                    <div className="text-green-700 text-xs mb-1">This Week</div>
                    <div className="text-gray-800 font-semibold">{dashboardData?.earningsOverview?.thisWeek?.toFixed(2) || '0.00'} USDT</div>
                  </div>
                  {/* <div>
                    <div className="text-green-700 text-xs mb-1">This Month</div>
                    <div className="text-gray-800 font-semibold">{dashboardData?.earningsOverview?.thisMonth?.toFixed(2) || '0.00'} USDT</div>
                  </div> */}
          {/* </div>
              </div> */}
          {/* </div>
          </div> */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 relative overflow-hidden shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                  <TrendingDown className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    Latest Withdrawals
                  </h3>
                  <p className="text-sm text-blue-700">
                    Recent withdrawals tickets
                  </p>
                </div>
              </div>
              <button
                onClick={() => navigate("/complaints")}
                className="text-blue-600 hover:text-blue-700 transition-colors duration-300"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {complaints.length > 0 ? (
                complaints.map((c) => (
                  <div
                    key={c._id}
                    className="bg-white/60 border border-blue-200 rounded-lg p-3 hover:bg-white/80 transition-colors duration-200"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-medium text-gray-800 truncate">
                            {c.title || "Withdrawal"}
                          </span>
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium border ${getComplaintStatusColor(
                              c.status
                            )}`}
                          >
                            {c.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                          Amount: {c.withdrawalId.amount ? `${c.withdrawalId.amount} USDT` : "N/A"}
                        </p>
                        <div className="text-xs text-gray-500">
                          {c.submittedAt
                            ? new Date(c.submittedAt).toLocaleDateString()
                            : "N/A"}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-gray-500 py-4">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No withdrawal found</p>
                </div>
              )}
            </div>

            {complaints.length > 0 && (
              <div className="mt-4 pt-4 border-t border-blue-200">
                <button
                  onClick={() => navigate("/complaints")}
                  className="w-full text-center text-blue-600 hover:text-blue-700 text-sm font-medium py-2 transition-colors duration-200"
                >
                  View All Withdrawals
                </button>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="bg-white/80 backdrop-blur-lg border border-gray-200 rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Quick Actions
            </h3>
            <div className="space-y-3">
              <button
                onClick={() => navigate("/transactions")}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-4 rounded-lg font-medium transition-all duration-300 border border-gray-300"
              >
                View Transactions
              </button>
              <button
                onClick={() => navigate("/api-credentials")}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-4 rounded-lg font-medium transition-all duration-300 border border-gray-300"
              >
                API Documentation
              </button>
              <button
                onClick={() => navigate("/withdraw-requests")}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-4 rounded-lg font-medium transition-all duration-300 border border-gray-300"
              >
                Payout Requests
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
