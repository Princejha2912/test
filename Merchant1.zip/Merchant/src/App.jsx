import React from "react";
import { HashRouter as Router, Routes, Route, useLocation } from "react-router-dom";  // Use HashRouter
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import Login from "./components/Login";
import TransactionsPage from "./components/Pages/TransactionsPage";  // Import additional pages
import APICredentialsPage from "./components/Pages/APICredentialsPage";
import WithdrawRequestsPage from "./components/Pages/WithdrawRequestsPage";
import WalletBalancePage from "./components/Pages/WalletBalancePage";
import ComplaintsPage from "./components/Pages/ComplaintsPage";
import AuthGuard from './components/AuthGuard'; //


const App = () => {
    const location = useLocation();

  // If on Login page, don't render Header
  const showHeader = location.pathname !== "/";
  return (
    // <Router>
      <div className="min-h-screen bg-gray-100">
      {showHeader && <Header />}
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<AuthGuard><Dashboard /></AuthGuard>} />
          <Route path="/transactions" element={<AuthGuard><TransactionsPage /></AuthGuard>} />
          <Route path="/api-credentials" element={<AuthGuard><APICredentialsPage /></AuthGuard>} />
          <Route path="/withdraw-requests" element={<AuthGuard><WithdrawRequestsPage /></AuthGuard>} />
          <Route path="/wallet-balances" element={<AuthGuard><WalletBalancePage /></AuthGuard>} />
          <Route path="/complaints" element={<AuthGuard><ComplaintsPage /></AuthGuard>} />
        </Routes>
      </div>
    // </Router>
  );
};

export default App;
