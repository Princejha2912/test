import React, { useState, useRef, useEffect } from "react";
import NotificationBell from "./NotificationBell"; // Adjust path as needed
import { Link, useNavigate } from "react-router-dom";
import {
  Menu,
  X,
  Zap,
  Shield,
  User,
  LogOut,
  KeyRound,
  TrendingUp,
} from "lucide-react";

const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';
// const API_BASE_URL = "http://localhost:5000/api/v1";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [changePwdLoading, setChangePwdLoading] = useState(false);
  const [changePwdMsg, setChangePwdMsg] = useState("");
  const [changePwdErr, setChangePwdErr] = useState("");
  const profileRef = useRef(null);
  const navigate = useNavigate();

  // Profile dropdown click-outside logic
  useEffect(() => {
    const handler = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        // setIsProfileOpen(false);
      }
    };
    if (isProfileOpen) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [isProfileOpen]);

  // Logout logic
  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE_URL}/auth/logout`, {
        method: "POST",
        credentials: "include",
      });
      localStorage.clear();
      sessionStorage.clear();
      // Optionally close profile menu
      setIsProfileOpen(false);
      navigate("/");
    } catch (err) {
      alert("Logout failed!");
    }
  };

  // Change password logic
  const handleChangePassword = async (e) => {
    e.preventDefault();
    setChangePwdLoading(true);
    setChangePwdErr("");
    setChangePwdMsg("");
    try {
      const token =
        localStorage.getItem("token") || sessionStorage.getItem("token");
      const res = await fetch(`${API_BASE_URL}/auth/change-password`, {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          ...(token && { Authorization: `Bearer ${token}` }),
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setChangePwdErr(data.message || "Failed to change password");
      } else {
        setChangePwdMsg("Password changed successfully! Logging out...");
        setCurrentPassword("");
        setNewPassword("");
        // Auto logout after 1.2s
        setTimeout(async () => {
          await fetch(`${API_BASE_URL}/auth/logout`, {
            method: "POST",
            credentials: "include",
          });
          localStorage.clear();
          sessionStorage.clear();
          setShowChangePassword(false);
          navigate("/");
        }, 1200);
      }
    } catch {
      setChangePwdErr("Network error");
    } finally {
      setChangePwdLoading(false);
    }
  };

  return (
    <header className="relative bg-white border-b border-gray-200 z-50">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo Section */}
          <div className="">
            <img src="./logo.png" alt="Logo" className="h-10 md:h-12" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            <NotificationBell />
            {/* Profile Section (Always Visible) */}
            <div className="relative ml-3" ref={profileRef}>
              <button
                onClick={() => setIsProfileOpen((v) => !v)}
                className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-white shadow-md hover:bg-slate-100 transition-all duration-200"
              >
                <User className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-slate-700">Profile</span>
              </button>
              {isProfileOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-lg shadow-lg z-50">
                  <button
                    className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center space-x-2"
                    onClick={() => {
                      setIsProfileOpen(false);
                      setTimeout(() => setShowChangePassword(true), 100);
                    }}
                  >
                    <KeyRound className="w-4 h-4 text-blue-600" />
                    <span>Change Password</span>
                  </button>
                  <button
                    className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center space-x-2 text-red-600"
                    onClick={() => {
                      // setIsProfileOpen(false);
                      setTimeout(handleLogout, 100);
                    }}
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          </nav>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center">
            <NotificationBell />
            {/* Profile for mobile (Always Visible) */}
            <div className="relative mr-3 ml-2" ref={profileRef}>
              <button
                onClick={() => setIsProfileOpen((v) => !v)}
                className="flex items-center space-x-1 px-2 py-2 rounded-xl bg-white shadow-md hover:bg-slate-100 transition-all duration-200"
              >
                <User className="w-5 h-5 text-blue-600" />
              </button>
              {isProfileOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white border border-slate-200 rounded-lg shadow-lg z-100">
                  <button
                    className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center space-x-2"
                    onClick={() => {
                      setIsProfileOpen(false);
                      setTimeout(() => setShowChangePassword(true), 100);
                    }}
                  >
                    <KeyRound className="w-4 h-4 text-blue-600" />
                    <span>Change Password</span>
                  </button>

                  <button
                    className="w-full px-4 py-3 text-left hover:bg-slate-50 flex items-center space-x-2 text-red-600"
                    onClick={() => {
                      // setIsProfileOpen(false);
                      setTimeout(handleLogout, 100);
                    }}
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
            
          </div>
        </div>

        {/* Mobile Navigation */}
      </div>

      {/* Change Password Modal */}
      {showChangePassword && (
        <div className="absolute min-h-screen w-full z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-lg p-8 shadow-lg w-full max-w-md relative">
            <button
              onClick={() => setShowChangePassword(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold mb-4">Change Password</h2>
            <form onSubmit={handleChangePassword} className="space-y-4">
              {changePwdErr && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-2 rounded">
                  {changePwdErr}
                </div>
              )}
              {changePwdMsg && (
                <div className="bg-green-50 border border-green-200 text-green-700 p-2 rounded">
                  {changePwdMsg}
                </div>
              )}
              <div>
                <label className="block text-sm font-medium mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-blue-500"
                  required
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-2 rounded font-medium hover:bg-blue-700"
                disabled={changePwdLoading}
              >
                {changePwdLoading ? "Changing..." : "Change Password"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Bottom border gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-300 to-transparent"></div>
    </header>
  );
};

export default Header;
