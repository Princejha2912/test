import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Login from "./components/Login";
import AdminPanel from "./components/AdminPanel";
import ManageMerchant from './components/Pages/ManageMerchant';
import Transactions from './components/Pages/transactionmanagement';
import AllTransactions from './components/Pages/Transaction';
import AuthGuard from './components/AuthGuard'; // ✅ import AuthGuard

const App = () => {
  const location = useLocation();

  // If on Login page, don't render Header
  const showHeader = location.pathname !== "/";

  return (
    <div className="min-h-screen bg-gray-100">
      {showHeader && <Header />}
      <Routes>
        {/* Public Route */}
        <Route path="/" element={<Login />} />

        {/* Protected Routes */}
        <Route
          path="/admin"
          element={
            <AuthGuard>
              <AdminPanel />
            </AuthGuard>
          }
        />
        <Route
          path="/manage"
          element={
            <AuthGuard>
              <ManageMerchant />
            </AuthGuard>
          }
        />
        <Route
          path="/transactions"
          element={
            <AuthGuard>
              <Transactions />
            </AuthGuard>
          }
        />
        <Route
          path="/all-transactions"
          element={
            <AuthGuard>
              <AllTransactions />
            </AuthGuard>
          }
        />
      </Routes>
    </div>
  );
};

export default App;
