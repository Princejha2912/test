import React, { useState, useEffect } from "react";
import {
  DollarSign,
  CreditCard,
  List,
  ChevronLeft,
  MessageCircle,
  Loader2,
  AlertTriangle,
  Eye,
  CheckCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  Copy,
  Calendar,
  Filter,
  RotateCcw,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Search,
} from "lucide-react";

const CopyButton = ({ value }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="ml-1 sm:ml-2 p-1 text-gray-400 hover:text-gray-600 transition-colors"
      title="Copy to clipboard"
    >
      <Copy size={12} />
      {copied && <span className="text-xs ml-1 text-green-600 hidden sm:inline">Copied!</span>}
    </button>
  );
};

const AllTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [selectedTab, setSelectedTab] = useState("deposit");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hasNextPage, setHasNextPage] = useState(true);
  // const [backButtonVisible, setBackButtonVisible] = useState(true);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [totalPages, setTotalPages] = useState(1);
  
  // Filter states
  const [dateFilter, setDateFilter] = useState({
    startDate: "",
    endDate: "",
  });
  const [statusFilter, setStatusFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';
  // const API_BASE_URL = "http://localhost:5000/api/v1";

  // Get unique statuses based on current tab
  const getUniqueStatuses = () => {
    const statuses = [...new Set(transactions.map((tx) => tx.status))];
    return statuses.sort();
  };

  // Check if any filters are active
  const hasActiveFilters = () => {
    return dateFilter.startDate || dateFilter.endDate || statusFilter;
  };

  // Filter transactions based on active filters
  const getFilteredTransactions = () => {
    let filtered = [...transactions];

    // Apply date filter
    if (dateFilter.startDate) {
      filtered = filtered.filter((tx) => {
        const txDate = new Date(tx.createdAt);
        const startDate = new Date(dateFilter.startDate);
        return txDate >= startDate;
      });
    }

    if (dateFilter.endDate) {
      filtered = filtered.filter((tx) => {
        const txDate = new Date(tx.createdAt);
        const endDate = new Date(dateFilter.endDate);
        endDate.setHours(23, 59, 59, 999);
        return txDate <= endDate;
      });
    }

    // Apply status filter
    if (statusFilter) {
      filtered = filtered.filter((tx) => tx.status === statusFilter);
    }

    return filtered;
  };

  // Clear all filters
  const clearFilters = () => {
    setDateFilter({ startDate: "", endDate: "" });
    setStatusFilter("");
    setCurrentPage(1);
  };

  const fetchTransactions = async (page = 1) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `${API_BASE_URL}/dashboard/admin?${selectedTab}Page=${page}&limit=${limit}`,
        {
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const data = await response.json();

      if (data.success) {
        const dashboardData = data.data;
        
        let recentTransactions = [];
        
        if (selectedTab === "deposit") {
          recentTransactions = dashboardData.recentTransactions?.deposits || [];
        } else if (selectedTab === "payout") {
          // Filter out refund transactions from withdrawals
          const withdrawals = dashboardData.recentTransactions?.withdrawals || [];
          recentTransactions = withdrawals.filter(tx => tx.type !== "refund");
        } else if (selectedTab === "refund") {
          // Get only refund transactions from withdrawals
          const withdrawals = dashboardData.recentTransactions?.withdrawals || [];
          recentTransactions = withdrawals.filter(tx => tx.type === "refund");
        }

        const formattedTransactions = recentTransactions.map((tx, index) => {
          let paymentStatus = "";
          
          // Only calculate payment status for deposits
          if (selectedTab === "deposit" && tx.actualBalance !== undefined) {
            if (tx.actualBalance < tx.amount) {
              paymentStatus = "Underpaid";
            } else if (tx.actualBalance > tx.amount) {
              paymentStatus = "Overpaid";
            } else {
              paymentStatus = "Exact Paid";
            }
          }

          return {
            ...tx,
            type: selectedTab,
            _id: `${selectedTab}_${tx.wallet || tx.clientWallet}_${tx.amount || "no-amount"}_${tx.email}_${page}_${index}`,
            createdAt: tx.createdAt || new Date().toISOString(),
            displayAmount: tx.amount || 0,
            paymentStatus: selectedTab === "deposit" ? paymentStatus : null,
          };
        });

        setTransactions(formattedTransactions);
        setHasNextPage(formattedTransactions.length === limit);
        
        // Reset filters when switching tabs
        if (page === 1) {
          clearFilters();
        }
      }
    } catch (err) {
      console.error("Failed to fetch transactions:", err);
      setError(err.message);
      setHasNextPage(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setCurrentPage(1);
    fetchTransactions(1);
  }, [selectedTab]);

  useEffect(() => {
    fetchTransactions(currentPage);
  }, [currentPage]);

  const handlePageChange = (direction) => {
    const newPage = Math.max(1, currentPage + direction);
    if (direction > 0 && hasNextPage) {
      setCurrentPage(newPage);
    } else if (direction < 0 && currentPage > 1) {
      setCurrentPage(newPage);
    }
  };

  // const handleBackClick = () => {
  //   window.history.back();
  // };

  const getTransactionIcon = (type, status) => {
    if (status === "failed" || status === "rejected") {
      return (
        <div className="w-8 h-8 sm:w-12 sm:h-12 bg-red-50 border border-red-200 rounded-lg flex items-center justify-center">
          <XCircle className="w-4 h-4 sm:w-6 sm:h-6 text-red-500" />
        </div>
      );
    }

    if (status === "initiated") {
      return (
        <div className="w-8 h-8 sm:w-12 sm:h-12 bg-orange-50 border border-orange-200 rounded-lg flex items-center justify-center">
          <Loader2 className="w-4 h-4 sm:w-6 sm:h-6 text-orange-500 animate-spin" />
        </div>
      );
    }

    if (status === "expired") {
      return (
        <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-center">
          <XCircle className="w-4 h-4 sm:w-6 sm:h-6 text-gray-500" />
        </div>
      );
    }

    if (type === "deposit") {
      return (
        <div className="w-8 h-8 sm:w-12 sm:h-12 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-center">
          <TrendingUp className="w-4 h-4 sm:w-6 sm:h-6 text-blue-600" />
        </div>
      );
    }

    if (type === "refund") {
      return (
        <div className="w-8 h-8 sm:w-12 sm:h-12 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-center">
          <RefreshCw className="w-4 h-4 sm:w-6 sm:h-6 text-blue-600" />
        </div>
      );
    }

    return (
      <div className="w-8 h-8 sm:w-12 sm:h-12 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-center">
        <TrendingDown className="w-4 h-4 sm:w-6 sm:h-6 text-blue-600" />
      </div>
    );
  };

  const getStatusColor = (status, paymentStatus = null) => {
    // For underpaid deposits, use gray status regardless of actual status
    if (paymentStatus === "Underpaid") {
      return "bg-gray-100 text-gray-700 border-gray-300";
    }

    switch (status) {
      case "completed":
      case "approved":
      case "confirmed":
        return "bg-green-100 text-green-700 border-green-300";
      case "pending":
      case "processing":
        return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "failed":
      case "blocked":
      case "cancelled":
      case "rejected":
        return "bg-red-100 text-red-700 border-red-300";
      case "initiated":
        return "bg-orange-100 text-orange-700 border-orange-300";
      case "expired":
        return "bg-gray-100 text-gray-700 border-gray-300";
      default:
        return "bg-gray-100 text-gray-700 border-gray-300";
    }
  };

  const getPaymentStatusColor = (paymentStatus) => {
    switch (paymentStatus) {
      case "Exact Paid":
        return "bg-green-100 text-green-800 border-green-300";
      case "Overpaid":
        return "bg-blue-100 text-blue-800 border-blue-300";
      case "Underpaid":
        return "bg-red-100 text-red-800 border-red-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getAmountColor = (transaction) => {
    // For rejected, failed, blocked, or cancelled transactions, show gray
    if (["rejected", "failed", "blocked", "cancelled"].includes(transaction.status)) {
      return "text-red-600";
    }
    
    // For initiated deposits, show orange
    if (transaction.type === "deposit" && transaction.status === "initiated") {
      return "text-orange-600";
    }
    
    // For underpaid deposits, show red
    if (transaction.type === "deposit" && transaction.paymentStatus === "Underpaid") {
      return "text-red-600";
    }
    
    // For successful deposits, show green
    if (transaction.type === "deposit" && 
        (transaction.status === "completed" || transaction.status === "approved" || transaction.status === "confirmed")) {
      return "text-green-600";
    }
    
    // For expired transactions, show gray
    if (transaction.status === "expired") {
      return "text-gray-600";
    }
    
    // For payouts and refunds, show blue
    if (transaction.type === "payout" || transaction.type === "refund") {
      return "text-blue-600";
    }
    
    return "text-slate-600";
  };

  const getAmountPrefix = (transaction) => {
    // Don't show prefix for rejected, failed, blocked, or cancelled transactions
    if (["rejected", "failed", "blocked", "cancelled"].includes(transaction.status)) {
      return "";
    }
    
    // Show + sign only for successful deposit transactions
    if (transaction.type === "deposit" && 
        (transaction.status === "completed" || transaction.status === "approved" || transaction.status === "confirmed")) {
      return "+";
    }
    
    // Show - sign for successful payout transactions (not rejected ones)
    if (transaction.type === "payout" && 
        !["rejected", "failed", "blocked", "cancelled"].includes(transaction.status)) {
      return "-";
    }
    
    // Show ~ sign for refund transactions
    if (transaction.type === "refund") {
      return "~";
    }
    
    return "";
  };

  const Button = ({
    onClick,
    children,
    variant = "primary",
    disabled = false,
    icon: Icon,
    className = "",
  }) => {
    const baseClasses =
      "flex items-center justify-center space-x-1 sm:space-x-2 px-3 py-2 sm:px-6 sm:py-3 rounded-lg font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 text-sm sm:text-base";
    const variants = {
      primary:
        "bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg",
      secondary:
        "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300 shadow-sm",
      outline:
        "border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 shadow-sm hover:shadow-md",
    };

    return (
      <button
        onClick={onClick}
        disabled={disabled}
        className={`${baseClasses} ${variants[variant]} ${className}`}
      >
        {Icon && <Icon className="w-3 h-3 sm:w-4 sm:h-4" />}
        <span>{children}</span>
      </button>
    );
  };

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction);
    setShowDetailsModal(true);
  };

  // Get filtered transactions for display
  const filteredTransactions = getFilteredTransactions();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-2 sm:p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* {backButtonVisible && (
              <Button
                onClick={handleBackClick}
                variant="outline"
                icon={ChevronLeft}
              >
                <span className="hidden sm:inline">Back</span>
              </Button>
            )} */}
            <div>
              <h1 className="text-lg sm:text-2xl font-bold text-gray-900">
                Transaction Management
              </h1>
              <p className="text-gray-600 mt-1 text-sm sm:text-base">Monitor and track all transactions</p>
            </div>
          </div>
        </div>

        {/* Modern Tab Switcher with Enhanced Styling */}
        <div className="bg-white rounded-xl sm:rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
          {/* Enhanced Tab Navigation */}
          <div className="relative bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 border-b border-gray-200">
            <div className="px-4 sm:px-8 py-4 sm:py-6">
              <div className="flex space-x-1 sm:space-x-2 bg-white rounded-lg sm:rounded-xl p-1 sm:p-2 shadow-inner border border-gray-100">
                <button
                  onClick={() => setSelectedTab("deposit")}
                  className={`relative flex-1 flex flex-col sm:flex-row items-center justify-center space-y-1 sm:space-y-0 sm:space-x-3 py-2 sm:py-4 px-2 sm:px-6 rounded-md sm:rounded-lg font-semibold text-xs sm:text-sm transition-all duration-300 transform ${
                    selectedTab === "deposit"
                      ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg scale-105 shadow-blue-300/50"
                      : "text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:scale-102"
                  }`}
                >
                  <div className={`p-1 sm:p-2 rounded-md sm:rounded-lg ${
                    selectedTab === "deposit" 
                      ? "bg-white/20" 
                      : "bg-blue-100"
                  }`}>
                    <TrendingUp className={`w-3 h-3 sm:w-5 sm:h-5 ${
                      selectedTab === "deposit" ? "text-white" : "text-blue-600"
                    }`} />
                  </div>
                  <span className="font-bold">Deposits</span>
                </button>
                
                <button
                  onClick={() => setSelectedTab("payout")}
                  className={`relative flex-1 flex flex-col sm:flex-row items-center justify-center space-y-1 sm:space-y-0 sm:space-x-3 py-2 sm:py-4 px-2 sm:px-6 rounded-md sm:rounded-lg font-semibold text-xs sm:text-sm transition-all duration-300 transform ${
                    selectedTab === "payout"
                      ? " bg-blue-600 text-white shadow-lg scale-105 shadow-blue-300/50"
                      : "text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:scale-102"
                  }`}
                >
                  <div className={`p-1 sm:p-2 rounded-md sm:rounded-lg ${
                    selectedTab === "payout" 
                      ? "bg-white/20" 
                      : "bg-blue-100"
                  }`}>
                    <TrendingDown className={`w-3 h-3 sm:w-5 sm:h-5 ${
                      selectedTab === "payout" ? "text-white" : "text-blue-600"
                    }`} />
                  </div>
                  <span className="font-bold">Payouts</span>
                </button>
                
                <button
                  onClick={() => setSelectedTab("refund")}
                  className={`relative flex-1 flex flex-col sm:flex-row items-center justify-center space-y-1 sm:space-y-0 sm:space-x-3 py-2 sm:py-4 px-2 sm:px-6 rounded-md sm:rounded-lg font-semibold text-xs sm:text-sm transition-all duration-300 transform ${
                    selectedTab === "refund"
                      ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg scale-105 shadow-blue-300/50"
                      : "text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:scale-102"
                  }`}
                >
                  <div className={`p-1 sm:p-2 rounded-md sm:rounded-lg ${
                    selectedTab === "refund" 
                      ? "bg-white/20" 
                      : "bg-blue-100"
                  }`}>
                    <RefreshCw className={`w-3 h-3 sm:w-5 sm:h-5 ${
                      selectedTab === "refund" ? "text-white" : "text-blue-600"
                    }`} />
                  </div>
                  <span className="font-bold">Refunds</span>
                </button>
              </div>
            </div>
          </div>

          {/* Enhanced Filters Section */}
          <div className="border-b border-gray-100">
            <div className="p-4 sm:p-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={`flex items-center space-x-2 sm:space-x-3 px-4 sm:px-6 py-2 sm:py-3 rounded-lg sm:rounded-xl font-semibold text-xs sm:text-sm transition-all duration-300 transform hover:scale-105 shadow-lg ${
                    showFilters 
                      ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-blue-300/50" 
                      : "bg-white border-2 border-gray-200 text-gray-700 hover:border-blue-300 hover:shadow-md"
                  }`}
                >
                  <div className={`p-1 sm:p-2 rounded-md sm:rounded-lg ${
                    showFilters 
                      ? "bg-white/20" 
                      : "bg-blue-50"
                  }`}>
                    <Filter className={`w-3 h-3 sm:w-4 sm:h-4 ${
                      showFilters ? "text-white" : "text-blue-600"
                    }`} />
                  </div>
                  <span>Advanced Filters</span>
                  {hasActiveFilters() && (
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                        showFilters 
                          ? "bg-white/20 text-white" 
                          : "bg-blue-600 text-white"
                      }`}>
                        {Object.values({...dateFilter, statusFilter}).filter(Boolean).length}
                      </span>
                    </div>
                  )}
                  <div className={`transition-transform duration-300 ${showFilters ? "rotate-180" : ""}`}>
                    <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4" />
                  </div>
                </button>
                
                {hasActiveFilters() && (
                  <button
                    onClick={clearFilters}
                    className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-lg font-medium text-xs sm:text-sm text-red-600 bg-red-50 border border-red-200 hover:bg-red-100 transition-all duration-200 hover:scale-105"
                  >
                    <RotateCcw className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span>Clear All</span>
                  </button>
                )}
              </div>
              
              {showFilters && (
                <div className="mt-4 sm:mt-6 bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-200 shadow-inner">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                    {/* Enhanced Date Filters */}
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3 h-3 sm:w-4 sm:h-4 text-blue-600" />
                        <label className="block text-xs sm:text-sm font-bold text-gray-800">
                          Start Date
                        </label>
                      </div>
                      <div className="relative">
                        <input
                          type="date"
                          value={dateFilter.startDate}
                          onChange={(e) =>
                            setDateFilter((prev) => ({ ...prev, startDate: e.target.value }))
                          }
                          className="w-full px-3 sm:px-4 py-2 sm:py-3 bg-white border-2 border-gray-200 rounded-lg sm:rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 text-xs sm:text-sm transition-all shadow-sm hover:shadow-md font-medium"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3 h-3 sm:w-4 sm:h-4 text-blue-600" />
                        <label className="block text-xs sm:text-sm font-bold text-gray-800">
                          End Date
                        </label>
                      </div>
                      <div className="relative">
                        <input
                          type="date"
                          value={dateFilter.endDate}
                          onChange={(e) =>
                            setDateFilter((prev) => ({ ...prev, endDate: e.target.value }))
                          }
                          className="w-full px-3 sm:px-4 py-2 sm:py-3 bg-white border-2 border-gray-200 rounded-lg sm:rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 text-xs sm:text-sm transition-all shadow-sm hover:shadow-md font-medium"
                        />
                      </div>
                    </div>
                    
                    {/* Enhanced Status Filter */}
                    <div className="space-y-2 sm:space-y-3 sm:col-span-2 lg:col-span-1">
                      <div className="flex items-center space-x-2">
                        <Search className="w-3 h-3 sm:w-4 sm:h-4 text-blue-600" />
                        <label className="block text-xs sm:text-sm font-bold text-gray-800">Status</label>
                      </div>
                      <div className="relative">
                        <select
                          value={statusFilter}
                          onChange={(e) => setStatusFilter(e.target.value)}
                          className="w-full px-3 sm:px-4 py-2 sm:py-3 bg-white border-2 border-gray-200 rounded-lg sm:rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 text-xs sm:text-sm transition-all shadow-sm hover:shadow-md font-medium appearance-none cursor-pointer"
                        >
                          <option value="">All Statuses</option>
                          {getUniqueStatuses().map((status) => (
                            <option key={status} value={status}>
                              {status.charAt(0).toUpperCase() + status.slice(1)}
                            </option>
                          ))}
                        </select>
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                          <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 text-gray-400" />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Enhanced Active Filters Summary */}
                  {hasActiveFilters() && (
                    <div className="mt-4 sm:mt-6 p-3 sm:p-4 bg-white rounded-lg sm:rounded-xl border-2 border-blue-200 shadow-sm">
                      <div className="flex items-center space-x-2 mb-3">
                        <div className="w-2 sm:w-3 h-2 sm:h-3 bg-blue-600 rounded-full animate-pulse"></div>
                        <p className="text-xs sm:text-sm text-blue-800 font-bold">
                          Active Filters Applied
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {dateFilter.startDate && (
                          <span className="px-2 sm:px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full text-xs font-bold shadow-md">
                            From: {new Date(dateFilter.startDate).toLocaleDateString()}
                          </span>
                        )}
                        {dateFilter.endDate && (
                          <span className="px-2 sm:px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full text-xs font-bold shadow-md">
                            To: {new Date(dateFilter.endDate).toLocaleDateString()}
                          </span>
                        )}
                        {statusFilter && (
                          <span className="px-2 sm:px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full text-xs font-bold shadow-md">
                            Status: {statusFilter.charAt(0).toUpperCase() + statusFilter.slice(1)}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 sm:px-6 py-3 sm:py-4 rounded-lg sm:rounded-xl shadow-sm">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="font-semibold text-sm sm:text-base">Error: {error}</span>
            </div>
          </div>
        )}

        {/* Content Area */}
        <div className="bg-white rounded-lg sm:rounded-xl border border-gray-200 shadow-lg overflow-hidden">
          <div className="p-4 sm:p-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 sm:mb-8">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">
                {selectedTab === "deposit" ? "Deposit" : selectedTab === "payout" ? "Payout" : "Refund"} Transactions
                {hasActiveFilters() && (
                  <span className="block sm:inline text-xs sm:text-sm font-normal text-blue-600 sm:ml-2">
                    ({filteredTransactions.length} of {transactions.length} shown)
                  </span>
                )}
              </h2>
              <div className="text-xs sm:text-sm text-gray-500 bg-gray-100 px-3 sm:px-4 py-1 sm:py-2 rounded-full font-medium">
                Page {currentPage}
              </div>
            </div>

            {loading ? (
              <div className="text-center py-12 sm:py-16">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-blue-600 rounded-lg sm:rounded-xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                  <Loader2 className="w-6 h-6 sm:w-8 sm:h-8 text-white animate-spin" />
                </div>
                <p className="text-gray-600 font-semibold text-base sm:text-lg">
                  Loading {selectedTab} transactions...
                </p>
              </div>
            ) : (
              <div className="space-y-3 sm:space-y-4">
                {filteredTransactions.length === 0 ? (
                  <div className="text-center py-12 sm:py-16">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gray-100 rounded-lg sm:rounded-xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-sm">
                      <List className="w-8 h-8 sm:w-10 sm:h-10 text-gray-400" />
                    </div>
                    <p className="text-gray-500 font-semibold text-base sm:text-lg">
                      {transactions.length === 0 
                        ? `No ${selectedTab} transactions found` 
                        : "No transactions match your filters"
                      }
                    </p>
                  </div>
                ) : (
                  filteredTransactions.map((transaction) => (
                    <div
                      key={transaction._id}
                      className="group border border-gray-200 p-3 sm:p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white cursor-pointer rounded-lg sm:rounded-xl hover:border-blue-300"
                      onClick={() => handleTransactionClick(transaction)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 sm:space-x-4 flex-1 min-w-0">
                          {getTransactionIcon(transaction.type, transaction.status)}
                          <div className="space-y-1 flex-1 min-w-0">
                            <div className="font-bold text-gray-900 text-sm sm:text-lg truncate">
                              {transaction.clientId?.email || "Unknown User"}
                            </div>
                            <div className="flex flex-wrap items-center gap-1 sm:gap-3">
                              <span className="text-gray-600 text-xs sm:text-sm font-semibold">
                                {transaction.type === "deposit" ? "Deposit" : 
                                 transaction.type === "payout" ? "Withdrawal" : "Refund"}
                              </span>
                              <span
                                className={`px-2 sm:px-3 py-1 text-xs font-semibold rounded-full ${getStatusColor(
                                  transaction.status,
                                  transaction.paymentStatus
                                )}`}
                              >
                                {transaction.status.toUpperCase()}
                              </span>
                              {/* Only show payment status for deposits */}
                              {transaction.type === "deposit" && transaction.paymentStatus && (
                                <span
                                  className={`px-2 sm:px-3 py-1 text-xs font-semibold rounded-full ${getPaymentStatusColor(
                                    transaction.paymentStatus
                                  )}`}
                                >
                                  {transaction.paymentStatus}
                                </span>
                              )}
                            </div>
                            
                            {/* Transaction Details */}
                            <div className="space-y-1 text-xs text-gray-500">
                              {transaction.type === "deposit" && transaction.transactionId && (
                                <div className="flex items-center">
                                  <span className="font-medium">TX ID:</span>
                                  <span className="ml-1 font-mono truncate">
                                    {transaction.transactionId.substring(0, 12)}...
                                  </span>
                                  <CopyButton value={transaction.transactionId} />
                                </div>
                              )}
                              
                              <div className="flex items-center">
                                <span className="font-medium">Client ID:</span>
                                <span className="ml-1 font-mono truncate">
                                  {(transaction.id || transaction.clientId?.id || "N/A").toString().substring(0, 8)}...
                                </span>
                                <CopyButton value={transaction.id || transaction.clientId?.id || ""} />
                              </div>
                              
                              {(transaction.walletAddress || transaction.clientWallet) && (
                                <div className="flex items-center">
                                  <span className="font-medium">Wallet:</span>
                                  <span className="ml-1 font-mono truncate">
                                    {(transaction.walletAddress || transaction.clientWallet).substring(0, 8)}...
                                  </span>
                                  <CopyButton value={transaction.walletAddress || transaction.clientWallet} />
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="text-right space-y-2 flex-shrink-0 ml-2">
                          <div className="flex items-center space-x-2 sm:space-x-3">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTransactionClick(transaction);
                              }}
                              className="p-1 sm:p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg sm:rounded-xl transition-all duration-200"
                              title="View Details"
                            >
                              <Eye size={14} className="sm:w-[18px] sm:h-[18px]" />
                            </button>
                            
                            <div className="text-right">
                              <div className={`text-base sm:text-xl font-bold ${getAmountColor(transaction)}`}>
                                {getAmountPrefix(transaction)}
                                $
                                {transaction.displayAmount || "0.00"}
                              </div>
                              
                              {/* Actual Balance Display - Only for deposits */}
                              {transaction.type === "deposit" && transaction.actualBalance !== undefined && (
                                <div className="text-xs sm:text-sm text-gray-500 mt-1">
                                  Actual: ${transaction.actualBalance || "0.00"}
                                </div>
                              )}
                              
                              <div className="text-xs text-gray-400 mt-1">
                                {new Date(transaction.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>

        {/* Modern Pagination - Only show if not filtering */}
        {!hasActiveFilters() && (
          <div className="flex justify-between items-center bg-white border border-gray-200 rounded-lg sm:rounded-xl shadow-lg p-4 sm:p-6">
            <Button
              onClick={() => handlePageChange(-1)}
              disabled={currentPage === 1}
              variant="outline"
              icon={ChevronLeft}
              className="shadow-sm"
            >
              <span className="hidden sm:inline">Previous</span>
              <span className="sm:hidden">Prev</span>
            </Button>
            
            <div className="text-gray-700 font-semibold bg-gray-100 px-4 sm:px-6 py-2 sm:py-3 rounded-lg sm:rounded-xl text-sm sm:text-base">
              Page {currentPage}
            </div>
            
            <Button
              onClick={() => handlePageChange(1)}
              disabled={!hasNextPage}
              variant="primary"
              className="shadow-sm"
            >
              Next
            </Button>
          </div>
        )}
      </div>

      {/* Modern Modal */}
      {showDetailsModal && selectedTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-2 sm:p-4">
          <div className="bg-white rounded-lg sm:rounded-2xl shadow-2xl max-w-4xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 sm:p-8">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-lg sm:text-2xl font-bold">Transaction Details</h2>
                  <p className="text-blue-100 mt-1 sm:mt-2 text-sm sm:text-base">
                    {selectedTransaction.type === "deposit" ? "Deposit" : 
                     selectedTransaction.type === "payout" ? "Withdrawal" : "Refund"} Transaction
                  </p>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="text-white hover:bg-blue-700 rounded-lg sm:rounded-xl p-2 sm:p-3 transition-colors"
                >
                  <XCircle className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-4 sm:p-6 overflow-y-auto max-h-[calc(95vh-100px)] sm:max-h-[calc(90vh-120px)]">
              <div className="space-y-4 sm:space-y-6">
                {/* Amount Information - Only show comparison for deposits */}
                {selectedTransaction.type === "deposit" ? (
                  <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Amount Information</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                      <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                        <div className="text-lg sm:text-xl font-bold text-blue-600">
                          ${selectedTransaction.amount || "0.00"}
                        </div>
                        <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                          Expected Amount
                        </div>
                      </div>
                      <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                        <div className="text-lg sm:text-xl font-bold text-green-600">
                          ${selectedTransaction.actualBalance || "0.00"}
                        </div>
                        <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                          Actual Balance
                        </div>
                      </div>
                      <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                        <div className={`text-xs sm:text-sm font-medium px-2 py-1 rounded border ${getPaymentStatusColor(selectedTransaction.paymentStatus)}`}>
                          {selectedTransaction.paymentStatus}
                        </div>
                        <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                          Payment Status
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Simple amount display for payouts and refunds */
                  <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Amount Information</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                      <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                        <div className="text-lg sm:text-2xl font-bold text-blue-600">
                          ${selectedTransaction.amount || "0.00"}
                        </div>
                        <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                          {selectedTransaction.type === "payout" ? "Payout Amount" : "Refund Amount"}
                        </div>
                      </div>
                      {selectedTransaction.netAmount !== undefined && (
                        <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                          <div className="text-lg sm:text-xl font-bold text-green-600">
                            ${selectedTransaction.netAmount || "0.00"}
                          </div>
                          <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                            Net Amount
                          </div>
                        </div>
                      )}
                      {selectedTransaction.fee !== undefined && (
                        <div className="text-center p-2 sm:p-3 bg-white rounded-lg border border-gray-200">
                          <div className="text-lg sm:text-xl font-bold text-red-600">
                            ${selectedTransaction.fee || "0.00"}
                          </div>
                          <div className="text-xs sm:text-sm font-medium text-gray-600 mt-1">
                            Fee
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Basic Information */}
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Basic Information</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div className="space-y-1">
                      <label className="block text-xs sm:text-sm font-medium text-gray-700">
                        Transaction ID
                      </label>
                      <p className="text-xs sm:text-sm font-mono bg-gray-100 p-2 rounded-lg break-all">
                        {selectedTransaction.transactionId || selectedTransaction.id || "N/A"}
                      </p>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="block text-xs sm:text-sm font-medium text-gray-700">
                        Currency
                      </label>
                      <p className="text-xs sm:text-sm font-mono bg-gray-100 p-2 rounded-lg">
                        {selectedTransaction.currencyType || "N/A"}
                      </p>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="block text-xs sm:text-sm font-medium text-gray-700">
                        Status
                      </label>
                      <span
                        className={`inline-block px-2 py-1 text-xs sm:text-sm font-medium rounded border ${getStatusColor(
                          selectedTransaction.status,
                          selectedTransaction.paymentStatus
                        )}`}
                      >
                        {selectedTransaction.status?.toUpperCase()}
                      </span>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="block text-xs sm:text-sm font-medium text-gray-700">
                        Wallet Address
                      </label>
                      <p className="text-xs sm:text-sm font-mono bg-gray-100 p-2 rounded-lg break-all">
                        {selectedTransaction.walletAddress || selectedTransaction.clientWallet || "N/A"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Client Information */}
                {selectedTransaction.clientId && (
                  <div>
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Client Information</h3>
                    <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                        <div>
                          <span className="font-medium text-gray-700 text-xs sm:text-sm">Email:</span>
                          <span className="ml-2 text-gray-600 text-xs sm:text-sm">
                            {selectedTransaction.clientId.email}
                          </span>
                        </div>
                        {selectedTransaction.clientId.name && (
                          <div>
                            <span className="font-medium text-gray-700 text-xs sm:text-sm">Name:</span>
                            <span className="ml-2 text-gray-600 text-xs sm:text-sm">
                              {selectedTransaction.clientId.name}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Timestamps */}
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Timeline</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div className="space-y-1">
                      <label className="block text-xs sm:text-sm font-medium text-gray-700">
                        Created At
                      </label>
                      <p className="text-xs sm:text-sm bg-gray-100 p-2 rounded-lg">
                        {new Date(selectedTransaction.createdAt).toLocaleString()}
                      </p>
                    </div>
                    
                    {selectedTransaction.updatedAt && (
                      <div className="space-y-1">
                        <label className="block text-xs sm:text-sm font-medium text-gray-700">
                          Updated At
                        </label>
                        <p className="text-xs sm:text-sm bg-gray-100 p-2 rounded-lg">
                          {new Date(selectedTransaction.updatedAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                    
                    {selectedTransaction.processedAt && (
                      <div className="space-y-1">
                        <label className="block text-xs sm:text-sm font-medium text-gray-700">
                          Processed At
                        </label>
                        <p className="text-xs sm:text-sm bg-gray-100 p-2 rounded-lg">
                          {new Date(selectedTransaction.processedAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                    
                    {selectedTransaction.confirmedAt && (
                      <div className="space-y-1">
                        <label className="block text-xs sm:text-sm font-medium text-gray-700">
                          Confirmed At
                        </label>
                        <p className="text-xs sm:text-sm bg-gray-100 p-2 rounded-lg">
                          {new Date(selectedTransaction.confirmedAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Transaction Hash */}
                {(selectedTransaction.transactionHash ||
                  selectedTransaction.blockchainTxHash ||
                  selectedTransaction.adminTransferData?.transactionHash) &&
                  (() => {
                    const hash =
                      selectedTransaction.transactionHash ||
                      selectedTransaction.blockchainTxHash ||
                      selectedTransaction.adminTransferData?.transactionHash;

                    let explorerUrl = "";
                    if (selectedTransaction.currencyType === "USDT-TRC20") {
                      explorerUrl = `https://nile.tronscan.org/#/transaction/${hash}`;
                    } else if (selectedTransaction.currencyType === "USDT-ERC20") {
                      explorerUrl = `https://sepolia.etherscan.io/tx/${hash}`;
                    } else {
                      explorerUrl = `#`;
                    }

                    return (
                      <div>
                        <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Blockchain</h3>
                        <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                          <div className="space-y-2 sm:space-y-3">
                            <div>
                              <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                                Transaction Hash
                              </label>
                              <p className="text-xs sm:text-sm font-mono bg-white p-2 sm:p-3 rounded-lg border break-all">
                                <a
                                  href={explorerUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:text-blue-800 transition-colors"
                                >
                                  {hash}
                                </a>
                              </p>
                            </div>
                            
                            <Button
                              onClick={() => window.open(explorerUrl, "_blank")}
                              variant="primary"
                              className="w-full"
                            >
                              View on Blockchain Explorer
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                {/* Admin Notes */}
                {selectedTransaction.adminNotes && (
                  <div>
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Admin Notes</h3>
                    <div className="bg-yellow-50 rounded-lg p-3 sm:p-4 border border-yellow-200">
                      <p className="text-gray-700 text-xs sm:text-sm">{selectedTransaction.adminNotes}</p>
                    </div>
                  </div>
                )}

                {/* Blockchain Information */}
                {selectedTransaction.currencyType !== "USDT-TRC20" &&
                  (selectedTransaction.blockchainData ||
                    selectedTransaction.adminTransferData?.details) && (
                    <div>
                      <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">
                        Blockchain Information
                      </h3>
                      <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              Block Number
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg">
                              {selectedTransaction.blockchainData?.blockNumber ||
                                selectedTransaction.adminTransferData?.details?.blockNumber ||
                                "N/A"}
                            </p>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              Gas Used
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg">
                              {selectedTransaction.blockchainData?.gasUsed ||
                                selectedTransaction.adminTransferData?.details?.gasUsed ||
                                "N/A"}
                            </p>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              Network
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg">
                              {selectedTransaction.blockchainData?.network ||
                                selectedTransaction.currencyType ||
                                "N/A"}
                            </p>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              From Address
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg font-mono break-all">
                              {selectedTransaction.blockchainData?.from ||
                                selectedTransaction.adminTransferData?.details?.from ||
                                "N/A"}
                            </p>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              To Address
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg font-mono break-all">
                              {selectedTransaction.blockchainData?.to ||
                                selectedTransaction.adminTransferData?.details?.to ||
                                "N/A"}
                            </p>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="block text-xs sm:text-sm font-medium text-gray-700">
                              Blockchain Status
                            </label>
                            <p className="text-xs sm:text-sm bg-white p-2 rounded-lg">
                              {selectedTransaction.blockchainData?.status?.toString() ||
                                selectedTransaction.adminTransferData?.details?.status?.toString() ||
                                "N/A"}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-gray-50 px-4 sm:px-8 py-3 sm:py-6 flex justify-end border-t border-gray-200">
              <Button
                onClick={() => setShowDetailsModal(false)}
                variant="outline"
                className="shadow-sm"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AllTransactions;