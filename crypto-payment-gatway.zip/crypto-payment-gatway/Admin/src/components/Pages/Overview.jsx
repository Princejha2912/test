import React, { useState, useEffect } from "react";
import {
  CreditCard,
  DollarSign,
  Shield,
  Activity,
  Users,
  Eye,
  UserPlus,
  Coins,
  CheckCircle,
  XCircle,
  User,
  TrendingDown,
} from "lucide-react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { useNavigate } from "react-router-dom";
import CopyButton from "../Button/Copy";

// Move Modal component outside to prevent re-creation on every render
const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] min-h-screen p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-slate-800">{title}</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <XCircle className="w-6 h-6" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

const Overview = () => {
  const [merchants, setMerchants] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [totalMerchants, setTotalMerchants] = useState(0);
  const [activeMerchants, setActiveMerchants] = useState(0);
  const [todayTransactions, setTodayTransactions] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalDeposit, setTotalDeposit] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [selectedMerchantId, setSelectedMerchantId] = useState("");
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const [withdrawalsToday, setWithdrawalsToday] = useState(0);



  // const API_BASE_URL = "http://localhost:5000/api/v1";
  const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';
  // Dynamic stats based on actual data
  const stats = [
    {
      title: "Total Merchants",
      value: totalMerchants.toLocaleString(),
      trend: "up",
      icon: <Users className="w-6 h-6" />,
      color: "from-blue-500 to-indigo-500",
    },
    // {
    //     title: 'Active Merchants',
    //     value: activeMerchants.toLocaleString(),
    //     trend: 'up',
    //     icon: <Shield className="w-6 h-6" />,
    //     color: 'from-purple-500 to-violet-500'
    // },
    {
      title: "Transactions Today",
      value: `$${todayTransactions.toLocaleString()}`,
      trend: "up",
      icon: <Activity className="w-6 h-6" />,
      color: "from-green-500 to-emerald-500",
    },
    {
      title: "Total Deposit",
      value: `$${totalDeposit.toLocaleString()}`,
      trend: "up",
      icon: <Coins className="w-6 h-6" />,
      color: "from-orange-500 to-amber-500",
    },
    {
      title: "Revenue",
      value: `$${totalRevenue.toLocaleString()}`,
      trend: "up",
      icon: <DollarSign className="w-6 h-6" />,
      color: "from-orange-500 to-amber-500",
    },
    {
      title: "Payouts",
      value: `$${totalExpenses.toLocaleString()}`,
      trend: "down",
      icon: <TrendingDown className="w-6 h-6" />,
      color: "from-red-500 to-rose-500",
    },
  ];

  useEffect(() => {
    fetchAllMerchants();
    fetchLatestMerchants();
    fetchDashboardData();
  }, []);

  const fetchAllMerchants = async () => {
    try {
      // Fetch all merchants without pagination limit
      const response = await fetch(`${API_BASE_URL}/merchant?limit=10000`, {
        credentials: "include",
      });
      const data = await response.json();

      if (data.data) {
        const allMerchants = data.data;
        setTotalMerchants(allMerchants.length);

        // Count only approved merchants
        const approvedMerchants = allMerchants.filter(
          (merchant) => merchant.approved === "approved"
        );
        setActiveMerchants(approvedMerchants.length);
      }
    } catch (err) {
      console.error("Failed to fetch all merchants:", err);
    }
  };

  const fetchLatestMerchants = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/merchant?page=1&limit=10`, {
        credentials: "include",
      });
      const data = await response.json();
      // Sort merchants by creation date (newest first)
      const sortedMerchants = (data.data || []).sort((a, b) => {
        const dateA = new Date(a.createdAt || 0);
        const dateB = new Date(b.createdAt || 0);
        return dateB - dateA;
      });
      setMerchants(sortedMerchants);
    } catch (err) {
      console.error("Failed to fetch merchants:", err);
    }
  };

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/admin`, {
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        const dashboardData = data.data;

        // Set revenue and expenses
        setTotalRevenue(dashboardData.revenue || 0);
        setTotalExpenses(dashboardData.expenses || 0);
        setTotalDeposit(
          dashboardData.totalDeposite && dashboardData.totalDeposite.length > 0
            ? dashboardData.totalDeposite[0].total
            : 0
        );

        // Calculate today's transactions (deposits + withdrawals)
        const depositsToday = dashboardData.transactionsToday?.deposits || 0;
        const withdrawalsTodayVal =
          dashboardData.transactionsToday?.withdrawals || 0;
        setTodayTransactions(depositsToday + withdrawalsTodayVal);
        setWithdrawalsToday(withdrawalsTodayVal);

        const recentDeposits = (
          dashboardData.recentTransactions?.deposits || []
        ).map((tx, index) => ({
          ...tx,
          type: "deposit",
          _id: tx._id || `deposit_${tx.wallet}_${tx.amount}_${index}`,
        }));
        const recentWithdrawals = (
          dashboardData.recentTransactions?.withdrawals || []
        ).map((tx, index) => ({
          ...tx,
          type: "withdrawal",
          _id: tx._id || `withdrawal_${tx.wallet}_${tx.amount}_${index}`,
        }));

        // Combine and sort by creation date (newest first)
        const allTransactions = [...recentDeposits, ...recentWithdrawals];
        const sortedTransactions = allTransactions.sort((a, b) => {
          const dateA = new Date(a.createdAt || 0);
          const dateB = new Date(b.createdAt || 0);
          return dateB - dateA;
        });

        setTransactions(sortedTransactions); // Show only 5 most recent
      }
    } catch (err) {
      console.error("Failed to fetch dashboard data:", err);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
      case "approved":
      case "confirmed":
        return "bg-green-100 text-green-700 border-green-200";
      case "pending":
      case "processing":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "failed":
      case "blocked":
      case "cancelled":
      case "rejected":
        return "bg-red-100 text-red-700 border-red-200";
      case "initiated":
        return "bg-purple-100 text-purple-700 border-purple-200";
      case "expired":
        return "bg-orange-100 text-orange-700 border-orange-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  // New function to get withdrawal amount styling
  const getWithdrawalAmountStyle = (status) => {
    switch (status) {
      case "pending":
      case "processing":
        return "text-orange-600 font-bold";
      case "failed":
      case "blocked":
      case "cancelled":
      case "rejected":
        return "text-red-600 font-bold";
      case "completed":
      case "approved":
      case "confirmed":
        return "text-slate-800 font-bold";
      default:
        return "text-slate-800 font-bold";
    }
  };

  // New function to format withdrawal amount with minus sign for completed
  const formatWithdrawalAmount = (amount, status) => {
    const formattedAmount = `$${amount || "0.00"}`;
    if (status === "completed" || status === "approved" || status === "confirmed") {
      return `-${formattedAmount}`;
    }
    return formattedAmount;
  };

  const getTransactionIcon = (type) => {
    if (type === "deposit") {
      return (
        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
          <DollarSign className="w-5 h-5 text-blue-500" />
        </div>
      );
    } else {
      return (
        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
          <CreditCard className="w-5 h-5 text-blue-500" />
        </div>
      );
    }
  };

  const Button = ({
    onClick,
    children,
    variant = "primary",
    disabled = false,
    icon: Icon,
    className = "",
  }) => {
    const baseClasses =
      "flex items-center justify-center space-x-1 sm:space-x-2 px-3 py-2 sm:px-6 sm:py-3 rounded-lg font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 text-sm sm:text-base";
    const variants = {
      primary:
        "bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg",
      secondary:
        "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300 shadow-sm",
      outline:
        "border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 shadow-sm hover:shadow-md",
    };

    return (
      <button
        onClick={onClick}
        disabled={disabled}
        className={`${baseClasses} ${variants[variant]} ${className}`}
      >
        {Icon && <Icon className="w-3 h-3 sm:w-4 sm:h-4" />}
        <span>{children}</span>
      </button>
    );
  };


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setError("");
  };

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction);
    setShowDetailsModal(true);
  };

  return (
    <div className="space-y-8">
      {/* Alerts */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
          <div className="flex items-center space-x-2">
            <XCircle className="w-5 h-5 text-blue-500" />
            <span className="text-red-700 font-medium">{error}</span>
          </div>
        </div>
      )}
      {message && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-blue-500" />
            <span className="text-green-700 font-medium">{message}</span>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="relative group p-6 bg-white/70 backdrop-blur-lg rounded-2xl border border-slate-200/50 hover:bg-white/90 transition-all duration-300 shadow-sm hover:shadow-md"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl bg-blue-500 shadow-lg`}>
                <div className="text-white">{stat.icon}</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-slate-800">
                  {stat.value}
                </div>
              </div>
            </div>
            <h3 className="text-slate-600 font-medium text-md">{stat.title}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Transactions */}
        <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-slate-200/50 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-800">
              Recent Transactions
            </h2>
            <button
              onClick={() => navigate("/all-transactions")}
              className="text-blue-500 hover:text-blue-600 transition-colors duration-300"
            >
              <Eye className="w-5 h-5" />
            </button>
          </div>
          <div className="space-y-4">
            {transactions.filter((t) => t.status === "confirmed").length ===
            0 ? (
              <div className="text-center py-8">
                <CreditCard className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">
                  No recent confirmed transactions
                </p>
              </div>
            ) : (
              transactions
                .filter((t) => t.status === "confirmed")
                .map((transaction) => (
                  <div
                    key={transaction._id}
                    onClick={() => handleTransactionClick(transaction)}
                    className="flex items-center justify-between p-4 bg-slate-100/50 rounded-xl border border-slate-200/50 hover:bg-slate-100/70 transition-all duration-300 cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      {getTransactionIcon(transaction.type)}
                      <div>
                        <div className="text-slate-800 font-medium">
                          {transaction.clientId?.email || "Unknown User"}
                        </div>
                        <div className="text-slate-500 text-sm">
                          {transaction.type === "deposit"
                            ? "Deposit"
                            : "Payout"}
                        </div>
                        <div className="text-slate-400 text-xs">
                          {transaction.walletAddress || transaction.clientWallet
                            ? `${(
                                transaction.walletAddress ||
                                transaction.clientWallet
                              ).substring(0, 8)}...`
                            : "N/A"}
                          <CopyButton
                            value={
                              transaction.walletAddress ||
                              transaction.clientWallet
                            }
                          />
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-slate-800 font-bold">
                        ${transaction.amount || "0.00"}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-1 rounded-lg text-xs font-medium border ${getStatusColor(
                            transaction.status
                          )}`}
                        >
                          {transaction.status.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>

        {/* All Withdrawals */}
        <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-slate-200/50 p-6 shadow-sm flex flex-col">
          <h2 className="text-xl font-bold text-slate-800 mb-4">
            All Withdrawals
          </h2>
          <div className="space-y-4">
            {transactions.filter((t) => t.type === "withdrawal").slice(0, 10)
              .length === 0 ? (
              <div className="text-center py-8">
                <CreditCard className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No withdrawals found</p>
              </div>
            ) : (
              transactions
                .filter((t) => t.type === "withdrawal")
                .slice(0, 10)
                .map((transaction) => (
                  <div
                    key={transaction._id}
                    onClick={() => handleTransactionClick(transaction)}
                    className="flex items-center justify-between p-4 bg-slate-100/50 rounded-xl border border-slate-200/50 hover:bg-slate-100/70 transition-all duration-300 cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      {getTransactionIcon(transaction.type)}
                      <div>
                        <div className="text-slate-800 font-medium">
                          {transaction.clientId?.email || "Unknown User"}
                        </div>
                        <div className="text-slate-500 text-sm">Payout</div>
                        <div className="text-slate-400 text-xs">
                          {transaction.walletAddress || transaction.clientWallet
                            ? `${(
                                transaction.walletAddress ||
                                transaction.clientWallet
                              ).substring(0, 8)}...`
                            : "N/A"}
                          <CopyButton
                            value={
                              transaction.walletAddress ||
                              transaction.clientWallet
                            }
                          />
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={getWithdrawalAmountStyle(transaction.status)}>
                        {formatWithdrawalAmount(transaction.amount, transaction.status)}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-1 rounded-lg text-xs font-medium border ${getStatusColor(
                            transaction.status
                          )}`}
                        >
                          {transaction.status.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      </div>
      {showDetailsModal && selectedTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Transaction Details</h2>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            <div className="space-y-6">
              {/* Basic info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Transaction ID
                  </label>
                  <p className="text-sm font-mono">
                    {selectedTransaction.transactionId ||
                      selectedTransaction._id}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Amount
                  </label>
                  <p className="text-sm">{selectedTransaction.amount}</p>
                </div>
                {selectedTransaction.netAmount !== undefined && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Net Amount
                    </label>
                    <p className="text-sm">{selectedTransaction.netAmount}</p>
                  </div>
                )}
                {selectedTransaction.fee !== undefined && selectedTransaction.type !== "deposit" && (
  <div>
    <label className="block text-sm font-medium text-gray-700">
      Fee
    </label>
    <p className="text-sm">{selectedTransaction.fee}</p>
  </div>
)}

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Currency
                  </label>
                  <p className="text-sm">{selectedTransaction.currencyType}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Status
                  </label>
                  <span
                    className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                      selectedTransaction.status
                    )}`}
                  >
                    {selectedTransaction.status}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Wallet
                  </label>
                  <p className="text-sm font-mono break-all">
                    {selectedTransaction.walletAddress ||
                      selectedTransaction.clientWallet}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Created At
                  </label>
                  <p className="text-sm">
                    {new Date(selectedTransaction.createdAt).toLocaleString()}
                  </p>
                </div>
                {selectedTransaction.updatedAt && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Updated At
                    </label>
                    <p className="text-sm">
                      {new Date(selectedTransaction.updatedAt).toLocaleString()}
                    </p>
                  </div>
                )}
                {selectedTransaction.processedAt && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Processed At
                    </label>
                    <p className="text-sm">
                      {new Date(
                        selectedTransaction.processedAt
                      ).toLocaleString()}
                    </p>
                  </div>
                )}
                {selectedTransaction.confirmedAt && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Confirmed At
                    </label>
                    <p className="text-sm">
                      {new Date(
                        selectedTransaction.confirmedAt
                      ).toLocaleString()}
                    </p>
                  </div>
                )}
              </div>

              {/* Client Info */}
              {selectedTransaction.clientId && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Merchant Information
                  </label>
                  <div className="p-3 bg-gray-50 rounded">
                    <p className="text-sm">
                      <strong>Email:</strong>{" "}
                      {selectedTransaction.clientId.email}
                    </p>
                    {selectedTransaction.clientId.name && (
                      <p className="text-sm">
                        <strong>Name:</strong>{" "}
                        {selectedTransaction.clientId.name}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Transaction Hash */}
              {(selectedTransaction.transactionHash ||
                  selectedTransaction.blockchainTxHash ||
                  selectedTransaction.adminTransferData?.transactionHash) &&
                  (() => {
                    const hash =
                      selectedTransaction.transactionHash ||
                      selectedTransaction.blockchainTxHash ||
                      selectedTransaction.adminTransferData?.transactionHash;

                    let explorerUrl = "";
                    if (selectedTransaction.currencyType === "USDT-TRC20") {
                      explorerUrl = `https://nile.tronscan.org/#/transaction/${hash}`;
                    } else if (selectedTransaction.currencyType === "USDT-ERC20") {
                      explorerUrl = `https://sepolia.etherscan.io/tx/${hash}`;
                    } else {
                      explorerUrl = `#`;
                    }

                    return (
                      <div>
                        <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Blockchain</h3>
                        <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                          <div className="space-y-2 sm:space-y-3">
                            <div>
                              <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-2">
                                Transaction Hash
                              </label>
                              <p className="text-xs sm:text-sm font-mono bg-white p-2 sm:p-3 rounded-lg border break-all">
                                <a
                                  href={explorerUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:text-blue-800 transition-colors"
                                >
                                  {hash}
                                </a>
                              </p>
                            </div>
                            
                            <Button
                              onClick={() => window.open(explorerUrl, "_blank")}
                              variant="primary"
                              className="w-full"
                            >
                              View on Blockchain Explorer
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

              {/* Admin Notes */}
              {selectedTransaction.adminNotes && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Admin Notes
                  </label>
                  <p className="text-sm">{selectedTransaction.adminNotes}</p>
                </div>
              )}

              {/* Blockchain Info (for withdrawal blockchainData or deposit adminTransferData.details) */}
              {(selectedTransaction.blockchainData ||
                selectedTransaction.adminTransferData?.details) && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blockchain Information
                  </label>
                  <div className="p-3 bg-gray-50 rounded">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <p className="text-sm">
                        <strong>Block Number:</strong>{" "}
                        {selectedTransaction.blockchainData?.blockNumber ||
                          selectedTransaction.adminTransferData?.details
                            ?.blockNumber ||
                          "N/A"}
                      </p>
                      <p className="text-sm">
                        <strong>Gas Used:</strong>{" "}
                        {selectedTransaction.blockchainData?.gasUsed ||
                          selectedTransaction.adminTransferData?.details
                            ?.gasUsed ||
                          "N/A"}
                      </p>
                      <p className="text-sm">
                        <strong>Network:</strong>{" "}
                        {selectedTransaction.blockchainData?.network ||
                          selectedTransaction.currencyType}
                      </p>
                      <p className="text-sm">
                        <strong>From:</strong>{" "}
                        {selectedTransaction.blockchainData?.from ||
                          selectedTransaction.adminTransferData?.details
                            ?.from ||
                          "N/A"}
                      </p>
                      <p className="text-sm">
                        <strong>To:</strong>{" "}
                        {selectedTransaction.blockchainData?.to ||
                          selectedTransaction.adminTransferData?.details?.to ||
                          "N/A"}
                      </p>
                      <p className="text-sm">
                        <strong>Blockchain Status:</strong>{" "}
                        {selectedTransaction.blockchainData?.status?.toString() ||
                          selectedTransaction.adminTransferData?.details?.status?.toString() ||
                          "N/A"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Overview;