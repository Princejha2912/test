// components/Transactions.tsx
import React from "react";
import { TrendingUp, Activity } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Transactions = () => {
  const navigate = useNavigate();
  return (
    <div className="p-6 bg-green-50 rounded-xl border border-green-200/50">
      <div className="flex items-center justify-center space-x-3 mb-4">
        <Activity className="w-8 h-8 text-blue-500" />
        <h3 className="text-xl font-bold text-slate-800">
          Transaction Management
        </h3>
      </div>
      <p className="text-slate-600 mb-4 text-center">
        Monitor all platform transactions in real-time
      </p>
      <button
        onClick={() => navigate("/transactions")}
        className="w-full py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-all duration-300 shadow-lg hover:shadow-blue-500/25"
      >
        Transaction Management
      </button>
    </div>
  );
};

export default Transactions;
