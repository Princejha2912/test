import React, { useState, useEffect } from "react";
import {
  Trash2,
  Edit,
  Plus,
  X,
  Save,
  Eye,
  CheckCircle,
  ChevronLeft,
  Activity,
} from "lucide-react";

const API_BASE_URL = "https://backend.payglobal.co.in/api/v1";
// const API_BASE_URL = 'http://localhost:5000/api/v1';

const TransactionManagement = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [limit] = useState(10);
  const [statusFilter, setStatusFilter] = useState("all");
  const [processingTransactions, setProcessingTransactions] = useState(
    new Set()
  );

  // Mock navigate function for demo purposes
  const navigate = (path) => {
    console.log("Navigate to:", path);
  };

  // Fetch all transactions
  const fetchTransactions = async (page = 1, status = "all") => {
    try {
      setLoading(true);

      // Build query parameters
      let queryParams = `page=${page}&limit=${limit}`;
      if (status !== "all") {
        queryParams += `&status=${status}`;
      }

      const response = await fetch(
        `${API_BASE_URL}/withdrawal?${queryParams}`,
        {
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log("API Response:", data);

      if (data.success) {
        // Updated to match your API response structure
        const transactionsData = data.data || [];
        setTransactions(
          Array.isArray(transactionsData) ? transactionsData : []
        );

        // Updated pagination access
        if (data.pagination) {
          setTotalPages(data.pagination.totalPages);
        }
      } else {
        throw new Error("Failed to fetch transactions");
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to fetch transactions"
      );
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Approve or Reject a transaction
  const handleApprovalOrRejection = async (transaction, action) => {
    const actionText = action === "approve" ? "approve" : "reject";
    const confirmMessage = `Are you sure you want to ${actionText} this transaction?`;

    if (!window.confirm(confirmMessage)) {
      return;
    }

    const transactionId = transaction._id;

    // Add transaction to processing set
    setProcessingTransactions((prev) => new Set(prev).add(transactionId));

    try {
      const withdrawalId = transaction._id;

      // Set default admin notes based on action
      const adminNotes =
        action === "approve"
          ? "Transaction approved by admin"
          : "Transaction rejected by admin";

      const response = await fetch(
        `${API_BASE_URL}/withdrawal/${withdrawalId}`,
        {
          method: "PATCH",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ action, adminNotes }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || `HTTP error! status: ${response.status}`
        );
      }

      // Success message
      const successMessage =
        action === "approve"
          ? "Transaction approved successfully!"
          : "Transaction rejected successfully!";

      alert(successMessage);

      await fetchTransactions(currentPage, statusFilter);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to process transaction"
      );
    } finally {
      // Remove transaction from processing set
      setProcessingTransactions((prev) => {
        const newSet = new Set(prev);
        newSet.delete(transactionId);
        return newSet;
      });
    }
  };

  useEffect(() => {
    fetchTransactions(currentPage, statusFilter);
  }, [currentPage, statusFilter]);

  // Handle page change
  const handlePageChange = (page) => setCurrentPage(page);

  const handleStatusFilterChange = (status) => {
    setStatusFilter(status);
    setCurrentPage(1); // Reset to page 1 on filter change
  };

  // View transaction details
  const viewTransactionDetails = (transaction) => {
    setSelectedTransaction(transaction);
    setShowDetailsModal(true);
  };

  // Format transaction hash for display
  const formatTransactionHash = (hash) => {
    if (!hash) return "N/A";
    return `${hash.substring(0, 8)}...${hash.substring(hash.length - 8)}`;
  };

  // Get status color
  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "processing":
        return "bg-blue-100 text-blue-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "cancelled":
        return "bg-gray-100 text-gray-800";
      case "initiated":
        return "bg-purple-100 text-purple-800";
      case "expired":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const handleTabBack = () => {
    // if (tabHistory.length > 0) {
    //     const previousTab = tabHistory[tabHistory.length - 1];
    //     setTabHistory((prev) => prev.slice(0, prev.length - 1));
    //     setActiveTab(previousTab);
    // } else {
    window.history.back(); // Browser back
    // }
  };
  useEffect(() => {
    fetchTransactions();
  }, []);

  return (
    <div className="p-8">
      <div className="mb-4">
        <button
          onClick={handleTabBack}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-blue-50 transition-all"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Payout Request</h1>
          <p className="text-slate-600 mt-1">
            Monitor all platform transactions in real-time
          </p>
        </div>
        <div className="flex items-center gap-4">
          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-gray-700">
              Filter by Status:
            </label>
            <select
              value={statusFilter}
              onChange={(e) => handleStatusFilterChange(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="completed">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {/* Transaction Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Available Balance
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Requested
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Net Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Currency
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Merchant
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-6 py-4 text-center text-gray-500"
                  >
                    Loading...
                  </td>
                </tr>
              ) : transactions.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-6 py-4 text-center text-gray-500"
                  >
                    No transactions found
                  </td>
                </tr>
              ) : (
                transactions.map((transaction) => {
                  const isProcessing = processingTransactions.has(
                    transaction._id
                  );

                  return (
                    <tr key={transaction._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">
                        {transaction._id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {transaction.clientId?.totalAmt?.toFixed(3) || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {transaction.amount || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {transaction.netAmount?.toFixed(3) || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {transaction.currencyType}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                            transaction.status
                          )}`}
                        >
                          {transaction.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {transaction.clientId?.name || "N/A"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex gap-2">
                          <button
                            onClick={() => viewTransactionDetails(transaction)}
                            className="text-blue-600 hover:text-blue-900 p-1 rounded"
                            title="View Details"
                          >
                            <Eye size={16} />
                          </button>

                          {/* Hide Approve/Reject if status is completed or rejected */}
                          {!["completed", "rejected"].includes(
                            transaction.status?.toLowerCase()
                          ) && (
                            <>
                              <button
                                onClick={() =>
                                  handleApprovalOrRejection(
                                    transaction,
                                    "approve"
                                  )
                                }
                                disabled={isProcessing}
                                className={`p-1 rounded ${
                                  isProcessing
                                    ? "text-gray-400 cursor-not-allowed"
                                    : "text-green-600 hover:text-green-900"
                                }`}
                                title="Approve"
                              >
                                {isProcessing ? (
                                  <div className="w-4 h-4 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin"></div>
                                ) : (
                                  <CheckCircle size={16} />
                                )}
                              </button>
                              <button
                                onClick={() =>
                                  handleApprovalOrRejection(
                                    transaction,
                                    "reject"
                                  )
                                }
                                disabled={isProcessing}
                                className={`p-1 rounded ${
                                  isProcessing
                                    ? "text-gray-400 cursor-not-allowed"
                                    : "text-red-600 hover:text-red-900"
                                }`}
                                title="Reject"
                              >
                                {isProcessing ? (
                                  <div className="w-4 h-4 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin"></div>
                                ) : (
                                  <X size={16} />
                                )}
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-700">
              Page {currentPage} of {totalPages}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Transaction Details Modal */}
      {showDetailsModal && selectedTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] min-h-screen">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Transaction Details</h2>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </button>
            </div>
            <div className="space-y-6">
              {/* Basic Transaction Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Transaction ID
                  </label>
                  <p className="text-sm text-gray-900 font-mono">
                    {selectedTransaction._id}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Amount
                  </label>
                  <p className="text-sm text-gray-900">
                    {selectedTransaction.amount || "N/A"}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Net Amount
                  </label>
                  <p className="text-sm text-gray-900">
                    {selectedTransaction.netAmount || "N/A"}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Fee
                  </label>
                  <p className="text-sm text-gray-900">
                    {selectedTransaction.fee || "N/A"}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Currency
                  </label>
                  <p className="text-sm text-gray-900">
                    {selectedTransaction.currencyType}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Status
                  </label>
                  <span
                    className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                      selectedTransaction.status
                    )}`}
                  >
                    {selectedTransaction.status}
                  </span>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Client Wallet
                  </label>
                  <p className="text-sm text-gray-900 font-mono break-all">
                    {selectedTransaction.clientWallet}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Created At
                  </label>
                  <p className="text-sm text-gray-900">
                    {new Date(selectedTransaction.createdAt).toLocaleString()}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Updated At
                  </label>
                  <p className="text-sm text-gray-900">
                    {new Date(selectedTransaction.updatedAt).toLocaleString()}
                  </p>
                </div>
                {selectedTransaction.processedAt && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Processed At
                    </label>
                    <p className="text-sm text-gray-900">
                      {new Date(
                        selectedTransaction.processedAt
                      ).toLocaleString()}
                    </p>
                  </div>
                )}
              </div>

              {/* Client Information */}
              {selectedTransaction.clientId && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                  Merchant Information
                  </label>
                  <div className="p-3 bg-gray-50 rounded">
                    <p className="text-sm">
                      <strong>Name:</strong> {selectedTransaction.clientId.name}
                    </p>
                    <p className="text-sm">
                      <strong>Email:</strong>{" "}
                      {selectedTransaction.clientId.email}
                    </p>
                  </div>
                </div>
              )}

              {/* Transaction Hash */}
              {selectedTransaction.transactionHash && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Transaction Hash
                  </label>
                  <p className="text-sm text-gray-900 font-mono break-all">
                    {selectedTransaction.transactionHash}
                  </p>
                </div>
              )}

              {/* Admin Notes */}
              {selectedTransaction.adminNotes && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Admin Notes
                  </label>
                  <p className="text-sm text-gray-900">
                    {selectedTransaction.adminNotes}
                  </p>
                </div>
              )}

              {/* Blockchain Data */}
              {selectedTransaction.blockchainData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blockchain Information
                  </label>
                  <div className="p-3 bg-gray-50 rounded">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <p className="text-sm">
                        <strong>Block Number:</strong>{" "}
                        {selectedTransaction.blockchainData.blockNumber}
                      </p>
                      <p className="text-sm">
                        <strong>Gas Used:</strong>{" "}
                        {selectedTransaction.blockchainData.gasUsed}
                      </p>
                      <p className="text-sm">
                        <strong>Network:</strong>{" "}
                        {selectedTransaction.blockchainData.network}
                      </p>
                      <p className="text-sm">
                        <strong>From:</strong>{" "}
                        {selectedTransaction.blockchainData.from}
                      </p>
                      <p className="text-sm">
                        <strong>To:</strong>{" "}
                        {selectedTransaction.blockchainData.to}
                      </p>
                      <p className="text-sm">
                        <strong>Status:</strong>{" "}
                        {selectedTransaction.blockchainData.status
                          ? "Success"
                          : "Failed"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionManagement;
