// src/components/NotificationBell.jsx
import React, { useState, useRef, useEffect } from 'react';
import { Bell, X } from 'lucide-react';

const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';
  // const API_BASE_URL = 'http://localhost:5000/api/v1';


const NotificationBell = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const [notifErr, setNotifErr] = useState('');
  const [notifPage, setNotifPage] = useState(1);
  const [notifStats, setNotifStats] = useState({ unreadCount: 0 });
  const [notifDetail, setNotifDetail] = useState(null);

  // Fetch Notifications
  const fetchNotifications = async (page = 1) => {
    setNotifLoading(true);
    setNotifErr('');
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const res = await fetch(`${API_BASE_URL}/notifications?page=${page}&limit=10`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      const data = await res.json();
      if (data.success) {
        setNotifications(data.data);
        setNotifPage(page);
      } else setNotifErr('Failed to load notifications');
    } catch (err) {
      setNotifErr('Error loading notifications');
    } finally {
      setNotifLoading(false);
    }
  };

  // Fetch Unread Stats
  const fetchNotificationStats = async () => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const res = await fetch(`${API_BASE_URL}/notifications/stats`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      const data = await res.json();
      if (data.success) setNotifStats(data.data);
    } catch {}
  };

  // Mark All as Read
  const markAllAsRead = async () => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      await fetch(`${API_BASE_URL}/notifications/read-all`, {
        method: 'PATCH',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      fetchNotifications();
      fetchNotificationStats();
    } catch {}
  };

  // Mark One as Read
  const markOneAsRead = async (notificationId) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      await fetch(`${API_BASE_URL}/notifications/${notificationId}/read`, {
        method: 'PATCH',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      fetchNotifications();
      fetchNotificationStats();
    } catch {}
  };

  // Open/close logic
  const handleNotifBellClick = () => {
    setShowNotifications((v) => !v);
    fetchNotifications();
    fetchNotificationStats();
  };

  // Show Notification Detail
  const handleNotifDetail = async (notif) => {
    setNotifDetail(null);
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      const res = await fetch(`${API_BASE_URL}/notifications/${notif._id}`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      const data = await res.json();
      if (data.success) {
        setNotifDetail(data.data);
        if (!notif.isRead) markOneAsRead(notif._id);
      }
    } catch {
      setNotifDetail({ title: 'Error', message: 'Failed to fetch details.' });
    }
  };

  // Delete Notification
  const deleteNotification = async (notificationId) => {
    try {
      const token = localStorage.getItem('token') || sessionStorage.getItem('token');
      await fetch(`${API_BASE_URL}/notifications/${notificationId}`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
        },
      });
      fetchNotifications();
      fetchNotificationStats();
    } catch {}
  };

  // Dropdown close on click-outside
  const notifRef = useRef();
  useEffect(() => {
    if (!showNotifications) return;
    const handler = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showNotifications]);

  return (
    <>
      <div className="relative ml-3" ref={notifRef}>
        <button
          className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-white shadow-md hover:bg-slate-100 transition"
          onClick={handleNotifBellClick}
        >
          <Bell className="w-6 h-6 text-blue-600" />
          {notifStats.unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full text-xs px-1.5 py-0.5">{notifStats.unreadCount}</span>
          )}
        </button>
        {/* DROPDOWN */}
        {showNotifications && (
          <div className="absolute right-0 mt-2 w-96 bg-white border border-slate-200 rounded-lg shadow-lg z-50 overflow-hidden">
            <div className="flex items-center justify-between p-3 border-b">
              <span className="font-semibold text-slate-700">Notifications</span>
              <button className="text-xs text-blue-600 hover:underline" onClick={markAllAsRead}>
                Mark all as read
              </button>
            </div>
            <div className="max-h-80 overflow-y-auto">
              {notifLoading ? (
                <div className="p-4 text-center text-slate-500">Loading...</div>
              ) : notifErr ? (
                <div className="p-4 text-center text-red-500">{notifErr}</div>
              ) : notifications.length === 0 ? (
                <div className="p-4 text-center text-slate-400">No notifications</div>
              ) : (
                notifications.map((notif) => (
                  <div
                    key={notif._id}
                    className={`flex items-start gap-3 p-3 border-b last:border-none cursor-pointer hover:bg-blue-50 transition ${notif.isRead ? '' : 'bg-blue-50/40'}`}
                    onClick={() => handleNotifDetail(notif)}
                  >
                    <div className="flex-shrink-0 mt-1">
                      <Bell className="w-4 h-4 text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <div className={`font-medium text-slate-700 ${notif.isRead ? '' : 'font-bold'}`}>{notif.title || 'New Notification'}</div>
                      <div className="text-xs text-slate-500">{notif.body || notif.message}</div>
                      <div className="text-xs text-slate-400 mt-1">{new Date(notif.createdAt).toLocaleString()}</div>
                    </div>
                    <button
                      className="ml-2 text-red-400 hover:text-red-600"
                      onClick={(e) => { e.stopPropagation(); deleteNotification(notif.id); }}
                      title="Delete"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal for notification detail */}
      {notifDetail && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-[9999]">
          <div className="bg-white rounded-xl max-w-lg w-full shadow-lg p-8 relative">
            <button className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
              onClick={() => setNotifDetail(null)}
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold mb-2">{notifDetail.title || 'Notification'}</h3>
            <p className="text-slate-700 mb-4">{notifDetail.body || notifDetail.message}</p>
            <div className="text-xs text-slate-400">{notifDetail.createdAt ? new Date(notifDetail.createdAt).toLocaleString() : ''}</div>
          </div>
        </div>
      )}
    </>
  );
};

export default NotificationBell;
