import React from "react";
import { Navigate } from "react-router-dom";

const isAuthenticated = () => {
  const userId = localStorage.getItem("userId");
  const userRole = localStorage.getItem("userRole");
  const expiry = localStorage.getItem("token_expiry");

  if (!userId || !userRole || !expiry) {
    return false;
  }

  // check expiry
  if (Date.now() > parseInt(expiry, 10)) {
    // session expired
    localStorage.clear(); // clear all session data
    return false;
  }

  // check role
  return userRole === "admin";
};

const AuthGuard = ({ children }) => {
  if (!isAuthenticated()) {
    return <Navigate to="/" replace />;
  }
  return children;
};

export default AuthGuard;
