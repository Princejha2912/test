const express = require('express')
const app = express();

const bodyParser = require("body-parser");
const config = require('./config/config')


const morgan = require('morgan');
const cors = require('cors');

app.use(cors());
/** Swagger **/
const swaggerUi = require("swagger-ui-express");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerDefinition = {
  info: {
      title: "TRON",
      version: "1.0.0",
      description: "Swagger API Docs",
  },
  host: `${global.gConfig.swaggerURL}`,
  basePath: "/",
};
const options = {
  swaggerDefinition: swaggerDefinition,
  apis: ["./routes/*.js"],
};
const swaggerSpec = swaggerJSDoc(options);
app.get("/swagger.json", (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.send(swaggerSpec);
});
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use(bodyParser.urlencoded({ extended: true, limit: "50mb" }));
app.use(bodyParser.json({ limit: "50mb" }));
app.use(morgan('dev'))


app.use('/trx', require('./routes/trxRoutes'));
app.use('/trc20', require('./routes/trxRoutes'));


app.listen(global.gConfig.node_port, function () {
  console.log("Server is listening on", global.gConfig.node_port)
})
