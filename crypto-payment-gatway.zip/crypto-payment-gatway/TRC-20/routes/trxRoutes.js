const router = require('express').Router();
const trxController = require('../controllers/trx');
const trc20Controller = require('../controllers/trc20');

/**
 * @swagger
 * /trx/generateMnemonic:
 *   get:
 *     tags:
 *       - TRX-COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Mnemonic key generated successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
router.get('/generateMnemonic', trxController.generateMnemonic)

/**
 * @swagger
 * /trx/generateTronWallet:
 *   get:
 *     tags:
 *       - TRX-COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: mnemonic
 *         description: 
 *         in: query
 *         required: true
 *       - name: count
 *         description: 
 *         in: query
 *         required: false
 *     responses:
 *       200:
 *         description: Wallet generated successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
router.get('/generateTronWallet', trxController.generateTronWallet);

/**
* @swagger
* /trx/accountTRXBalance:
*   get:
*     tags:
*       - TRX-COIN  
*     description: Creating Docs
*     produces:
*       - application/json
*     parameters:
*       - name: address
*         description: 
*         in: query
*         required: true
*     responses:
*       200:
*         description: Balance fetched successfully
*       404:
*         description: Data not found
*       500:
*         description: Internal Server Error
*/
router.get('/accountTRXBalance', trxController.accountTRXBalance);


/**
* @swagger
* /trx/withdraw:
*   post:
*     tags:
*       - TRX-COIN  
*     description: Creating Docs
*     produces:
*       - application/json
*     parameters:
*       - name: senderAddress
*         description: 
*         in: formData
*         required: true
*       - name: privateKey
*         description: 
*         in: formData
*         required: true
*       - name: recieverAddress
*         description: 
*         in: formData
*         required: true
*       - name: amount
*         description: 
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Withdraw successful
*       404:
*         description: Data not found
*       500:
*         description: Internal Server Error
*/
router.post('/withdraw', trxController.withdraw);



/**
* @swagger
* /trx/trxTransfer:
*   post:
*     tags:
*       - TRX-COIN  
*     description: Creating Docs
*     produces:
*       - application/json
*     parameters:
*       - name: privateKey
*         description: 
*         in: formData
*         required: true
*       - name: senderAddress
*         description: 
*         in: formData
*         required: true
*       - name: recieverAddress
*         description: 
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Success
*       404:
*         description: Data not found
*       500:
*         description: Internal Server Error
*/
router.post('/trxTransfer', trxController.trxTransfer);

/**
* @swagger
* /trx/tronBlockConfirmations:
*   get:
*     tags:
*       - TRX-COIN  
*     description: Creating Docs
*     produces:
*       - application/json
*     parameters:
*       - name: txHash
*         description: 
*         in: query
*         required: true
*     responses:
*       200:
*         description: block confimations fetched successfully.
*       404:
*         description: Data not found
*       500:
*         description: Internal Server Error
*/
router.get('/tronBlockConfirmations', trxController.tronBlockConfirmations);

/**
* @swagger
* /trx/transactionHistory:
*   get:
*     tags:
*       - TRX-COIN  
*     description: Creating Docs
*     produces:
*       - application/json
*     parameters:
*       - name: address
*         description: 
*         in: query
*         required: true
*     responses:
*       200:
*         description: History fetched successfully
*       404:
*         description: Data not found
*       500:
*         description: Internal Server Error
*/
router.get('/transactionHistory', trxController.transactionHistory);

/**
* @swagger
* /trc20/depositTrc20:
*   post:
*     tags:
*       - TRC20-TOKEN
*     description: Check for Social existence and give the access Token 
*     produces:
*       - application/json
*     parameters:
*       - name: senderAddress
*         description: 
*         in: formData
*         required: true
*       - name: senderPrivateKey 
*         description: 
*         in: formData
*         required: true
*       - name: receiverAddress
*         description: 
*         in: formData
*         required: true
*       - name: token
*         description: 
*         in: formData
*         required: true
*       - name: contract 
*         description: 
*         in: formData
*         required: true
*     responses:
*       200:
*         description: amount transfer Successfully
*       404:
*         description: Not found
*/
router.post('/depositTrc20', trc20Controller.depositTrc20);

/**
 * @swagger
 * /trc20/withdrawTRC20:
 *   post:
 *     tags:
 *       - TRC20-TOKEN
 *     description: Check for Social existence and give the access Token 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: senderAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: senderPrivateKey 
 *         description: 
 *         in: formData
 *         required: true
 *       - name: receiverAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: token
 *         description: 
 *         in: formData
 *         required: true
 *       - name: TRCcontractAddress
 *         description: 
 *         in: query
 *         required: true
 *     responses:
 *       200:
 *         description: amount transfer Successfully
 *       404:
 *         description: Not found
 */
router.post('/withdrawTRC20', trc20Controller.withdraw);

/**
* @swagger
* /trc20/getTrc20Balance:
*   get:
*     tags:
*       - TRC20-TOKEN
*     description: Check for Social existence and give the access Token 
*     produces:
*       - application/json
*     parameters:
*       - name: address
*         description: address
*         in: query
*         required: true
*       - name: TRCcontractAddress
*         description: TRCcontractAddress
*         in: query
*         required: true
*     responses:
*       200:
*         description: Balance fetched successfully!
*       400:
*         description: Invalid
*/
router.get('/getTrc20Balance', trc20Controller.getTrc20Balance);

module.exports = router;

