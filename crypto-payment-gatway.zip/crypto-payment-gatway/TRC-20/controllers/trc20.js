const { hdkey } = require("ethereumjs-wallet");
const bip39 = require("bip39");
const { BIP32Factory } = require("bip32");
const bitcoin = require("bitcoinjs-lib");
const Web3 = require("web3");
const ecc = require('tiny-secp256k1')
const bip32 = BIP32Factory(ecc);
const TronWeb = require("tronweb");
require('dotenv').config();
const Constant = require('../Helper/constant');

const ethers = require('ethers');
const HttpProvider = TronWeb.providers.HttpProvider; //This provider is optional, you can just use a url for the nodes instead

// const fullNode = new HttpProvider("https://api.shasta.trongrid.io"); // 


const fullNode = new HttpProvider("https://nile.trongrid.io"); // Full node http endpoint
const solidityNode = new HttpProvider("https://nile.trongrid.io"); // Solidity node http endpoint
const eventServer = new HttpProvider("https://nile.trongrid.io"); //solidity node http endpoint

// const fullNode = new HttpProvider("https://api.trongrid.io"); //Full node http endpoint
// const solidityNode = new HttpProvider("https://api.trongrid.io"); // Solidity node http endpoint
// const eventServer = new HttpProvider("https://api.trongrid.io"); //solidity node http endpoint


const tronWeb = new TronWeb(fullNode, solidityNode, eventServer);

const adminAddress = process.env.AdminAddress;
const adminPrivateKey = process.env.AdminPrivateKey;

const transferGasFeeFromAdminToUser = async (adminAddress, adminPrivateKey, recieverAddress, amount) => {
    try {
        const address = await tronWeb.address.fromPrivateKey(adminPrivateKey);
        if (address != adminAddress) {
            return { Status: "Error", Message: `Invalid adminAddress` };
        } else {
            const tronWeb = new TronWeb(
                fullNode,
                solidityNode,
                eventServer,
                adminPrivateKey
            );
            const trxAmount = amount * 1000000;
            const tradeobj = await tronWeb.transactionBuilder.sendTrx(
                recieverAddress,
                trxAmount
            );
            const signedtxn = await tronWeb.trx.sign(tradeobj);
            const result = await tronWeb.trx.sendRawTransaction(signedtxn);
            return { responseCode: 200, resposenMessage: 'Withdraw transaction success.', responseResult: result };
        }
    } catch (error) {
        console.log({ responseCode: 501, resposenMessage: 'Something went wrong!!!', responseResult: `${error}` });
    }
}

const tokenTransferUserToUser = async (recieverAddress, value, privateKey, TRCcontractAddress) => {
    if (recieverAddress || value || privateKey) {
    }
    try {
        const tronWeb = new TronWeb(
            fullNode,
            solidityNode,
            eventServer,
            privateKey
        );
        let instance = await tronWeb.contract(Constant.abi, TRCcontractAddress);
        let result = value;
        const balance = Number(result.toString()) * 1000000;
        let txhash = await instance["transfer"](recieverAddress, balance.toString()).send();
        return { responseCode: 200, txHash: txhash };
    }
    catch (error) {
        console.log("🚀 ~ tokenTransferUserToUser ~ error:", error)

    }
}

const depositTrc20 = async (req, res) => {
    try {
        const tranferTRX = 5;
        // Transfer gas fee from admin to user
        const result1 = await transferGasFeeFromAdminToUser(adminAddress, adminPrivateKey, req.body.senderAddress, tranferTRX);
        console.log("🚀 ~ depositTrc20 ~ result1:", result1);
        if (result1 && result1.responseCode === 200) {
            // Transfer tokens from user to receiver
            const result2 = await tokenTransferUserToUser(
                req.body.receiverAddress,
                req.body.token,
                req.body.senderPrivateKey,
                req.body.contract,
                req.body.TRCcontractAddress
            );
            
            console.log("🚀 ~ depositTrc20 ~ result2:", result2);

            if (result2 && result2.responseCode === 200) {
                return res.status(200).send({
                    responseCode: 200,
                    responseMessage: 'Success',
                    responseResult: result2
                });
            } else {
                return res.status(500).send({
                    responseCode: 500,
                    
                    responseMessage: 'Token transfer failed',
                    responseResult: result2
                });
            }
        } else {
            return res.status(500).send({
                responseCode: 500,
                responseMessage: 'Gas fee transfer failed',
                responseResult: result1
            });
        }
    } catch (error) {
        console.error("Error in depositTrc20:", error);

        if (error.response) {
            // Handle specific error response (if the error is from a network request)
            return res.status(error.response.status).send({
                responseCode: error.response.status,
                responseMessage: error.response.statusText,
                responseResult: error.message
            });
        } else if (error.request) {
            // Handle errors where the request was made but no response was received
            return res.status(408).send({
                responseCode: 408,
                responseMessage: 'Request Timeout',
                responseResult: error.message
            });
        } else {
            // General error handler for unexpected issues
            return res.status(500).send({
                responseCode: 500,
                responseMessage: 'Internal Server Error',
                responseResult: error.message
            });
        }
    }
};

const withdraw = async (req, res) => {
    try {
        const tronWeb = new TronWeb({
            fullHost: process.env.TRON_NODE,
            privateKey: process.env.ADMIN_PRIVATE_KEY,
        });

        let instance = await tronWeb.contract(Constant.abi, req.query.TRCcontractAddress);
        let result = req.body.token;
        const balance = Number(result.toString()) * 1000000;
        let txhash = await instance["transfer"](req.body.receiverAddress, balance.toString()).send();
        return res.send({ responseCode: 200, txHash: txhash });
    }
    catch (error) {
        return res.send({ responseCode: 501, error: error });
    }
}

const getTrc20Balance = async (req, res) => {
    if (!req.query.address) {
        return res.status(404).json({ message: `invalid Details` });
    }
    try {
        const tronWeb = new TronWeb({
            fullHost: process.env.TRON_NODE,
            privateKey: process.env.ADMIN_PRIVATE_KEY,
        });

        let instance = await tronWeb.contract(Constant.abi, req.query.TRCcontractAddress);
        let result = (await instance["balanceOf"](req.query.address).call());
        const decimals = await instance.methods.decimals().call()

        result = ethers.utils.formatUnits(result, decimals)
        return res.send({ status: 200, result: (result.toString()) })
    }
    catch (e) {
        console.error('\n\n\ balanceOf api| error', e);
        return res.send({ status: 404, message: "failed to fetch balanceOf." })
    }
}


module.exports = { depositTrc20, withdraw, getTrc20Balance }
