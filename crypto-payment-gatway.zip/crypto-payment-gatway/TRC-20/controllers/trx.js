const { hdkey } = require("ethereumjs-wallet");
const bip39 = require("bip39");
const { BIP32Factory } = require("bip32");
const axios = require('axios')
const bitcoin = require("bitcoinjs-lib");
const Web3 = require("web3");
const ecc = require('tiny-secp256k1')
const bip32 = BIP32Factory(ecc);
const TronWeb = require("tronweb");

const HttpProvider = TronWeb.providers.HttpProvider; //This provider is optional, you can just use a url for the nodes instead

// const fullNode = new HttpProvider("https://api.shasta.trongrid.io"); //Full node http endpoint
// const solidityNode = new HttpProvider("https://api.shasta.trongrid.io"); // Solidity node http endpoint
// const eventServer = new HttpProvider("https://api.shasta.trongrid.io"); //solidity node http endpoint
// const rpc = "https://api.shasta.trongrid.io"; //rpc

const fullNode = new HttpProvider("https://nile.trongrid.io"); //Full node http endpoint
const solidityNode = new HttpProvider("https://nile.trongrid.io"); // Solidity node http endpoint
const eventServer = new HttpProvider("https://nile.trongrid.io"); //solidity node http endpoint
const rpc = "https://nile.trongrid.io"; //rpc

// const fullNode = new HttpProvider("https://api.trongrid.io"); //Full node http endpoint
// const solidityNode = new HttpProvider("https://api.trongrid.io"); // Solidity node http endpoint
// const eventServer = new HttpProvider("https://api.trongrid.io"); //solidity node http endpoint
// const rpc = "https://api.trongrid.io"; //rpc

const tronWeb = new TronWeb(fullNode, solidityNode, eventServer);

const tronWebConfirmation = new TronWeb({
  fullHost: fullNode,
});

const generateMnemonic = (req, res) => {
  try {
    let mnemonic = bip39.generateMnemonic();
    res.send({ responseCode: 200, responseMessage: "Generated.", responseResult: mnemonic });
  } catch (error) {
    res.send({ responseCode: 501, responseMessage: "Something went wrong!!!", responseResult: error.message });
  }
}

const generateTronWallet = async (req, res) => {
  try {
    const seednew = await bip39.mnemonicToSeed(req.query.mnemonic);
    const node = await bip32.fromSeed(seednew);
    let countvalue = req.query.count ? req.query.count : 0;
    const child = await node.derivePath(`m/44'/195'/0'/0/${countvalue}`);
    const privateKey = await child.privateKey.toString("hex");
    const address = await tronWeb.address.fromPrivateKey(privateKey);
    let totalwallet = [];
    let importWallet = [];
    totalwallet.push({
      address: address,
      privateKey: privateKey,
      balance: 0,
    });
    let Body = {};
    if (countvalue > 0) {
      Body = {
        count:
          totalwallet && totalwallet.length
            ? parseInt(totalwallet.length) + parseInt(countvalue)
            : parseInt(countvalue),
        name: "TRX",
        totalwallet: totalwallet,
        importWallet: importWallet,
      };
    } else {
      Body = {
        count: 1,
        name: "TRX",
        totalwallet: totalwallet,
        importWallet: importWallet,
      };
    }
    return res.send({ responseCode: 200, resposenMessage: 'Wallet generated successfully.', responseResult: Body });
  } catch (error) {
    console.log({ responseCode: 501, resposenMessage: 'Something went wrong!!!', responseResult: `${error}` });
  }
}

const accountTRXBalance = async (req, res) => {
  try {
    const balance = await tronWeb.trx.getBalance(req.query.address);
    if (balance != 0) {
      let Balance = balance / 1000000;
      return res.send({ responseCode: 200, resposenMessage: 'Balance fetched successfully.', responseResult: Number(Balance) });
    } else {
      return res.send({ responseCode: 200, resposenMessage: 'Balance fetched successfully.', responseResult: Number(balance) });
    }
  } catch (error) {
    return res.send({ responseCode: 501, resposenMessage: 'Something went wrong!!!', responseResult: `${error}` });
  }
};

const withdraw = async (req, res) => {
  try {
    const address = await tronWeb.address.fromPrivateKey(req.body.privateKey);
    if (address != req.body.senderAddress) {
      return { Status: "Error", Message: `Invalid senderAddress` };
    } else {
      const tronWeb = new TronWeb(
        fullNode,
        solidityNode,
        eventServer,
        req.body.privateKey
      );
      const trxAmount = req.body.amount * 1000000;
      //Creates an unsigned TRX transfer transaction
      const tradeobj = await tronWeb.transactionBuilder.sendTrx(
        req.body.recieverAddress,
        trxAmount
      );
      const signedtxn = await tronWeb.trx.sign(tradeobj);
      const result = await tronWeb.trx.sendRawTransaction(signedtxn);
      return res.send({ responseCode: 200, resposenMessage: 'Withdraw transaction success.', responseResult: result });
    }
  } catch (error) {
    return res.send({ responseCode: 501, resposenMessage: 'Something went wrong!!!', responseResult: `${error}` });
  }
};

const trxTransfer = async (req, res) => {
  try {
    // Initialize tronWeb first
    const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, req.body.privateKey);
    const address = await tronWeb.address.fromPrivateKey(req.body.privateKey);
    if (address !== req.body.senderAddress) {
      return res.status(404).json({ Status: "Error", Message: `Invalid senderAddress` });
    }
    // Fetch chain parameters for gas fee calculation
    const chainParams = await tronWeb.trx.getChainParameters();
    const trxEnergyFee = chainParams.find(param => param.key === "getEnergyFee").value; // Energy cost per TRX
    const trxBandwidthFee = chainParams.find(param => param.key === "getTransactionFee").value; // Bandwidth cost per byte (usually 0.1 TRX/byte)
    // You can now use these parameters to estimate the cost
    const energyUsage = 10000;  // Example value, can be adjusted depending on actual usage
    const transactionSize = 250;  // Approximate transaction size in bytes (can vary)
    // Calculate the gas fee (estimated)
    const estimatedFee = (trxEnergyFee * energyUsage) + (trxBandwidthFee * transactionSize);
    // Fetch sender balance
    let totalAmount = await tronWeb.trx.getBalance(req.body.senderAddress);
    // Subtract the estimated fee from the total amount
    const amountToSend = totalAmount - estimatedFee;
    if (amountToSend <= 0) {
      return res.status(400).json({ Status: "Error", Message: "Insufficient balance to cover the transaction fees." });
    }
    // Proceed with the transaction
    const tradeobj = await tronWeb.transactionBuilder.sendTrx(req.body.recieverAddress, amountToSend);
    const signedtxn = await tronWeb.trx.sign(tradeobj);
    const result = await tronWeb.trx.sendRawTransaction(signedtxn);
    return res.send({ responseCode: 200, resposenMessage: 'Transfer transaction success.', responseResult: result });
  } catch (error) {
    return res.send({ responseCode: 501, resposenMessage: 'Something went wrong!!!', responseResult: `${error}` });
  }
};

const tronBlockConfirmations = async (req, res) => {
  const txHash = req.query.txHash;
  try {
    const transactionInfo = await tronWebConfirmation.trx.getTransactionInfo(txHash);
    if (transactionInfo) {
      const blockNumber = transactionInfo.blockNumber;
      if (blockNumber !== undefined) {
        const currentBlock = await tronWebConfirmation.trx.getBlock(tronWebConfirmation.fromDecimal(blockNumber));
        const confirmations = currentBlock ? currentBlock.block_header.raw_data.number - blockNumber + 1 : 0;
        res.status(200).json({
          responseCode: 200, responseMessage: "block confirmations fetched successfully.",
          confirmations,
          blockNumber,
        });
      } else {
        res.status(404).json({ error: 'Transaction not found' });
      }
    } else {
      res.status(404).json({ error: 'Transaction not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}

const transactionHistory = async (req, res) => {
  const address = req.query.address;
  try {
    const tronGridApiEndpoint = `${rpc}/v1/accounts/${address}/transactions`;
    const response = await axios.get(tronGridApiEndpoint);
    if (!response.data || !response.data.data) {
      throw new Error('Invalid response format');
    }
    const transactions = response.data.data.map((transaction) => {
      const amount = transaction.contractData ? transaction.contractData.amount || 0 : 0;
      let from = null;
      let to = null;
      // Checking different types of transactions and extracting 'from' and 'to' addresses
      if (transaction.from && transaction.to) {
        // Normal transaction
        from = transaction.from;
        to = transaction.to;
      } else if (transaction.raw_data && transaction.raw_data.contract && transaction.raw_data.contract.length > 0) {
        // Handling various contract types
        const contract = transaction.raw_data.contract[0];
        if (contract.parameter && contract.parameter.value) {
          if (contract.type === 'TransferContract') {
            from = contract.parameter.value.owner_address || null;
            to = contract.parameter.value.to_address || null;
          } else if (contract.type === 'TriggerSmartContract') {
            from = contract.parameter.value.owner_address || null;
            
            to = contract.parameter.value.contract_address || null;
          }
          // Add more conditions for other contract types if needed
        }
      }
      return {
        from: from,
        to: to,
        amount: amount,
        timestamp: transaction.timestamp,
        txID: transaction.txID,
      };
    });
    return res.send({ responseCode: 200, responseMessage: "Success.", responseResult: transactions });
  } catch (error) {
    return res.send({ responseCode: 500, responseMessage: "Something went wrong.", responseResult: error });
  }
};

module.exports = { generateMnemonic, generateTronWallet, accountTRXBalance, withdraw, trxTransfer, tronBlockConfirmations, transactionHistory }





