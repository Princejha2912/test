const router = require('express').Router();
const ERC20Controller = require('../controllers/erc20Controller');
const transferTokenController = require('../controllers/transferTokenUserToUser');


/**
* @swagger
* /erc20/generateMnemonic:
*   get:
*     tags:
*       - ERC20-TOKEN
*     description: Check for Social existence and give the access Token 
*     produces:
*       - application/json
*     responses:
*       200:
*         description: mnemonic generate Succeessfully
*       400:
*         description: Not found
*/
router.get('/generateMnemonic', ERC20Controller.generateMnemonic);


/**
* @swagger
* /erc20/generateAddress:
*   get:
*     tags:
*       - ERC20-TOKEN
*     description: Check for Social existence and give the access Token 
*     produces:
*       - application/json
*     parameters:
*       - name: mnemonic
*         description: 
*         in: query
*         required: true
*       - name: count
*         description: 
*         in: query
*         required: false
*     responses:
*       200:
*         description: account generate Successfully
*       400:
*         description: Not found
*/
router.get('/generateAddress', ERC20Controller.generateAddress);

/**
* @swagger
* /erc20/getBalance:
*   get:
*     tags:
*       - ERC20-TOKEN
*     description: Check for Social existence and give the access Token 
*     produces:
*       - application/json
*     parameters:
*       - name: address
*         description: address
*         in: query
*         required: true
*       - name: contract
*         description: contract
*         in: query
*         required: true
*     responses:
*       200:
*         description: account balance fetch Successfully
*       400:
*         description: Not found
*/
router.get('/getBalance', ERC20Controller.getBalance);


/**
 * @swagger
 * /erc20/withdraw:
 *   post:
 *     tags:
 *       - ERC20-TOKEN
 *     description: Check for Social existence and give the access Token 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: privateKey 
 *         description: 
 *         in: formData
 *         required: true
 *       - name: recieverAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: amountToSend 
 *         description: 
 *         in: formData
 *         required: true
 *       - name: contract 
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: amount transfer Successfully
 *       400:
 *         description: Not found
 */
router.post('/withdraw', ERC20Controller.withdraw);



/**
 * @swagger
 * /erc20/transfer:
 *   post:
 *     tags:
 *       - ERC20-TOKEN
 *     description: Check for Social existence and give the access Token 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: senderAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: privateKey 
 *         description: 
 *         in: formData
 *         required: true
 *       - name: recieverAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: contract 
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: amount transfer Successfully
 *       400:
 *         description: Not found
 */
router.post('/transfer', ERC20Controller.transfer);


/**
 * @swagger
 * /erc20/deposit:
 *   post:
 *     tags:
 *       - ERC20-TOKEN
 *     description: Check for Social existence and give the access Token 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: senderAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: senderPrivateKey 
 *         description: 
 *         in: formData
 *         required: true
 *       - name: receiverAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: token
 *         description: 
 *         in: formData
 *         required: true
 *       - name: contract 
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: amount transfer Successfully
 *       404:
 *         description: Not found
 */
 router.post('/deposit', transferTokenController.deposit);

module.exports =router;