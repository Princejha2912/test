const express = require('express');
const app = express();
const port = process.env.PORT || 3030;
const bodyParser = require('body-parser');
const cors = require('cors');
var morgan = require("morgan")
app.use(cors());
app.use(morgan('dev'))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");



// Routes Handling

var swaggerDefinition = {
  info: {
    title: "ERC20",
    version: "2.0.0",
    description: "eth-coins",
  },
  // host: `localhost:${port}`,
  host: `https://erc.payglobal.co.in:${port}`, // PG

  basePath: "/",
};

var options = {
  swaggerDefinition: swaggerDefinition,
  apis: ["./route/*.js"]

};

var swaggerSpec = swaggerJSDoc(options);

app.get("/swagger.json", function (req, res) {
  res.setHeader("Content-Type", "application/json");
  res.send(swaggerSpec);
});

// initialize swagger-jsdoc
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));



app.use('/erc20', require('./route/erc20Route')); //importing route



// routes(app); //register the route
app.use(function (req, res) {
  res.status(404).send({ resource: req.originalUrl + ' not found' })
});
app.listen(port);
console.log('RESTful API server started on: ' + port);

