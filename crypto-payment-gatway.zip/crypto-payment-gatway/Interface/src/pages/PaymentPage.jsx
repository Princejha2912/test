
import React from "react";
import QRCodeGenerator from "../components/QRCodeGenerator";

const PaymentPage = () => {
  return (
    <div>
      <QRCodeGenerator />
    </div>
  );
};

export default PaymentPage;
