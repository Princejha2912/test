const Withdrawal = require('../models/withdrawal');
const Deposit = require('../models/depositeAmt.js');
const User = require('../models/user');
const logger = require('../logger/logger.js');

  exports.getMerchantDashboard = async (req, res, next) => {
    try {
      const merchantId = req.user._id;

      // Extract pagination info from query params
      const depositPage = parseInt(req.query.depositPage) || 1;
      const withdrawalPage = parseInt(req.query.withdrawalPage) || 1;
      const limit = parseInt(req.query.limit) || 10;

      const skipDeposits = (depositPage - 1) * limit;
      const skipWithdrawals = (withdrawalPage - 1) * limit;

      const startOfToday = new Date(new Date().setHours(0, 0, 0, 0));
      const startOfWeek = new Date();
      startOfWeek.setDate(startOfWeek.getDate() - 7);
      const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);

      const [
        todayDepositsAgg,
        todayWithdrawalsAgg,
        recentDeposits,
        recentWithdrawals,
        weeklyEarningsDeposits,
        weeklyEarningsWithdrawals,
        monthlyEarningsDeposits,
        monthlyEarningsWithdrawals,
        user
      ] = await Promise.all([
        Deposit.aggregate([
          { $match: { clientId: merchantId,status: 'confirmed', createdAt: { $gte: startOfToday } } },
          { $group: { _id: null, total: { $sum: '$actualBalance' }, count: { $sum: 1 } } }
        ]),
        Withdrawal.aggregate([
          { $match: { clientId: merchantId, status: 'completed',createdAt: { $gte: startOfToday } } },
          { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
        ]),
        Deposit.find({
          clientId: merchantId,
          status: { $in: ['initiated', 'confirmed', 'failed', 'expired', 'pending', 'api_failed'] }
        })
        .select('-walletSecretKey') // 🚫 exclude the field
          .sort({ createdAt: -1 })
          .skip(skipDeposits)
          .limit(limit),
        Withdrawal.find({
          clientId: merchantId,
          status: { $in: ['pending', 'rejected', 'completed', 'failed'] }
        })
          .sort({ createdAt: -1 })
          .skip(skipWithdrawals)
          .limit(limit),
        Deposit.aggregate([
          { $match: { clientId: merchantId, status: 'confirmed', createdAt: { $gte: startOfWeek } } },
          { $group: { _id: null, total: { $sum: '$actualBalance' } } }
        ]),
        Withdrawal.aggregate([
          { $match: { clientId: merchantId, status: 'completed', createdAt: { $gte: startOfWeek } } },
          { $group: { _id: null, total: { $sum: '$amount' } } }
        ]),
        Deposit.aggregate([
          { $match: { clientId: merchantId, status: 'confirmed', createdAt: { $gte: startOfMonth } } },
          { $group: { _id: null, total: { $sum: '$actualBalance' } } }
        ]),
        Withdrawal.aggregate([
          { $match: { clientId: merchantId, status: 'completed', createdAt: { $gte: startOfMonth } } },
          { $group: { _id: null, total: { $sum: '$amount' } } }
        ]),
        User.findById(merchantId).select('totalAmt pendingAmt feeAmt')
      ]);

      const todayDeposits = todayDepositsAgg[0] || { total: 0, count: 0 };
      const todayWithdrawals = todayWithdrawalsAgg[0] || { total: 0, count: 0 };

      const totalTransactions = todayDeposits.count + todayWithdrawals.count;
      const todayTotalVolume = todayDeposits.total + todayWithdrawals.total;
      const avgTransaction = totalTransactions
        ? (todayTotalVolume / totalTransactions).toFixed(2)
        : 0;
      const successRate =
        totalTransactions > 0
          ? `${((todayDeposits.count / totalTransactions) * 100).toFixed(2)}%`
          : '0%';

      res.status(200).json({
        success: true,
        data: {
          todayVolume: todayTotalVolume,
          successRate,
          avgTransaction,
          realTimeBalance: user.totalAmt,
          availableBalance: user.totalAmt - user.pendingAmt,
          pendingBalance: user.pendingAmt,
          earningsOverview: {
            thisWeek: (weeklyEarningsDeposits[0]?.total || 0) + (weeklyEarningsWithdrawals[0]?.total || 0),
            thisMonth: (monthlyEarningsDeposits[0]?.total || 0) + (monthlyEarningsWithdrawals[0]?.total || 0)
          },
          recentTransactions: {
            deposits: recentDeposits,
            withdrawals: recentWithdrawals
          },
          user
        },
        error: null
      });
    } catch (err) {
      logger.error('Merchant dashboard error:', err.message);
      next(err);
    }
  };



exports.getAdminDashboard = async (req, res, next) => {
  try {
    const startOfToday = new Date(new Date().setHours(0, 0, 0, 0));

    const depositPage = parseInt(req.query.depositPage) || 1;
    const withdrawalPage = parseInt(req.query.withdrawalPage) || 1;
    const limit = parseInt(req.query.limit) || 5;

    const skipDeposits = (depositPage - 1) * limit;
    const skipWithdrawals = (withdrawalPage - 1) * limit;

    const [
      totalDeposite,
      todayDeposits,
      todayWithdrawals,
      totalFeeApplied,     
      totalWithdrawn,
      recentDeposits,
      recentWithdrawals
    ] = await Promise.all([
       Deposit.aggregate([
        { $match: { status: 'confirmed'} },
        { $group: { _id: null, total: { $sum: '$actualBalance' } } }
      ]),

      // Total deposit amount for today
      Deposit.aggregate([
        { $match: { status: 'confirmed', createdAt: { $gte: startOfToday } } },
        { $group: { _id: null, total: { $sum: '$actualBalance' } } }
      ]),

      // Total withdrawal amount for today
      Withdrawal.aggregate([
        { $match: { status: 'completed', createdAt: { $gte: startOfToday } } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),

      // ✅ Revenue: Total fee applied in all completed withdrawals
      Withdrawal.aggregate([
        { $match: { status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$fee' } } }
      ]),

      // Total amount withdrawn (expenses)
      Withdrawal.aggregate([
        { $match: { status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),

      // Recent deposits
      Deposit.find({ status: { $in: ['initiated', 'confirmed', 'failed', 'expired','pending','api_failed'] } })
        .select('-walletSecretKey') // 🚫 exclude the field
        .populate('clientId', 'email walletAddress')
        .sort({ createdAt: -1 })
        .skip(skipDeposits)
        .limit(limit),

      // Recent withdrawals
      Withdrawal.find({ status: { $in: ['pending', 'rejected', 'completed', 'failed'] } })
        .populate('clientId', 'email walletAddress')
        .sort({ createdAt: -1 })
        .skip(skipWithdrawals)
        .limit(limit)
    ]);

    res.json({
      success: true,
      data: {
        totalDeposite ,
        transactionsToday: {
          deposits: todayDeposits[0]?.total || 0,
          withdrawals: todayWithdrawals[0]?.total || 0
        },
        revenue: totalFeeApplied[0]?.total || 0, // ✅ Platform earnings from withdrawal fees
        expenses: totalWithdrawn[0]?.total || 0, // 💸 Total funds withdrawn by merchants
        recentTransactions: {
          deposits: recentDeposits,
          withdrawals: recentWithdrawals
        }
      }
    });
  } catch (err) {
    console.error('Dashboard error:', err.message);
    next(err);
  }
};


