const Refund = require('../models/refundForm.js');
const Withdrawal = require('../models/withdrawal.js');
const { widthdrawalHandlerRefund } = require('./widthdrawalController.js');

exports.createRefund = async (req, res) => {
  try {
    const { walletAddress, message, subject, amount, currencyType  } = req.body;

    if ( !walletAddress) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a wallet address to proceed with the refund.',
      });
    }

    const refundWithdrawal = new Withdrawal({
      clientId: req.user._id,
      clientWallet: walletAddress,
      status: 'pending',
      type: 'refund',
      amount: amount,
      currencyType
    });
    await refundWithdrawal.save();

    const refund = new Refund({
      withdrawalId: refundWithdrawal._id,
      message: `Withdrawal message: ${message}`,
      subject: subject || 'Refund Request',
      walletAddress,
      submittedBy: req.user?._id || req.body.clientId,
    });

    await refund.save();

    return res.status(201).json({
      success: true,
      message: 'Refund submitted successfully.',
      data: refund,
    });
  } catch (error) {
    console.error('Create refund error:', error);
    return res.status(500).json({
      success: false,
      message: "Refund process could not be completed—server encountered an error."
    });
  }
};

exports.getRefundById = async (req, res) => {
  try {
    const refund = await Refund.findById(req.params.id)
      .populate('submittedBy', 'email')
      .populate('withdrawalId');

    if (!refund) {
      return res.status(404).json({ success: false, message: 'Refund  not found' });
    }

    res.status(200).json({ success: true, data: refund });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};


exports.updateRefundByMerchant = async (req, res) => {
  try {
    const user = req.user;
    const { adminNotes, action, status } = req.body;
    const { id } = req.params;

    if (user.role !== 'merchant') {
      return res.status(403).json({ success: false, message: 'Only merchants can perform this action' });
    }

    const refund = await Refund.findById(id)
      .populate('submittedBy', 'email name')
      .populate('withdrawalId');

    if (!refund) {
      return res.status(404).json({ success: false, message: 'Refund not found' });
    }

    if (!status) {
      return res.status(400).json({ success: false, message: 'Refund status must be provided' });
    }

    if (refund.status === 'resolved') {
      return res.status(400).json({ success: false, message: 'Refund already processed' });
    }

    const walletAddress = refund.withdrawalId?.clientWallet;
    const withdrawalId = refund.withdrawalId?._id;

    if (!walletAddress) {
      return res.status(400).json({ success: false, message: 'Wallet address not found for refund' });
    }

    if (!action) {
      return res.status(400).json({ success: false, message: 'Action is required to approve the refund' });
    }
// ✅ Ensure only 'refund' type withdrawals are processed
if (refund.withdrawalId.type !== 'refund') {
  return res.status(400).json({
    success: false,
    message: 'Only withdrawals of type "refund" can be processed'
  });
}

    try {
      const refundWithdrawal = await widthdrawalHandlerRefund(
        withdrawalId,
        action,
        adminNotes,
        user
      );

      refund.refundDetails = {
        txHash: refundWithdrawal.txHash,
        refundedAt: new Date(),
        refundedAmount: refundWithdrawal.amount,
      };

      refund.status = status;
      refund.resolvedAt = new Date();

    } catch (err) {
      refund.resolvedAt = new Date();
      refund.status = 'pending';
      await refund.save();

      return res.status(500).json({
        success: false,
        message: 'Refund failed during processing.',
        error: err.message,
      });
    }

    if (adminNotes) {
      refund.adminNotes = adminNotes;
    }

    await refund.save();

    return res.status(200).json({
      success: true,
      message: 'Refund updated by merchant',
      data: refund,
    });
  } catch (error) {
    console.error('Merchant refund update error:', error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};




exports.deleteRefund = async (req, res) => {
  try {
    const deleted = await Refund.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Refund not found' });
    }

    res.status(200).json({ success: true, message: 'Refund deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};



exports.updateRefundByAdmin = async (req, res) => {
  try {
    const user = req.user;
    const { adminNotes, action, status } = req.body;
    const refundId = req.params.id;

    if (user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Only admins can perform this action' });
    }

    const refund = await Refund.findById(refundId)
      .populate('submittedBy', 'email name')
      .populate('withdrawalId');

    if (!refund) {
      return res.status(404).json({ success: false, message: 'refund not found' });
    }
    if(!status){
       return res.status(400).json({ success: false, message: 'Refund cant be process' });
    }

    if (refund.status === 'resolved') {
      return res.status(400).json({ success: false, message: 'refund already resolved by admin' });
    }

    if (status) {
      if (refund.status !== 'approved by merchant') {
        return res.status(400).json({
          success: false,
          message: 'refund must be approved by merchant before admin can take action'
        });
      }

      if (status === 'resolved') {
        refund.resolvedAt = new Date();

        const walletAddress = refund.withdrawalId?.clientWallet;
        const widthdrawalId = refund.withdrawalId._id;

        if (!walletAddress) {
          return res.status(400).json({ success: false, message: 'Wallet address not found for refund' });
        }

        try {
          if(!action){
            return res.status(400).json({ success: false, message: `provide action ${action} to approve the refund` }); 
          }
          const refundWithdrawal = await widthdrawalHandlerRefund(
            widthdrawalId,
            action,
            adminNotes,
            user,
          );

          
          refund.refundDetails = {
            txHash: refundWithdrawal.txHash,
            refundedAt: new Date(),
            refundedAmount: refundWithdrawal.amount,
          };
          refund.status=status;
        } catch (err) {
          refund.resolvedAt = new Date();
          refund.status = 'approved by merchant';
          await refund.save();
          return res.status(500).json({
            success: false,
            message: 'Refund failed during processing.',
            error: err.message,
          });
        }
      }
    }

    if (adminNotes) {
      refund.adminNotes = adminNotes;
    }

    await refund.save();

    return res.status(200).json({
      success: true,
      message: 'refund updated by admin',
      data: refund,
    });
  } catch (error) {
    console.error('Admin refund update error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};



exports.getAllRefundsMerchant = async (req, res) => {
  try {
    const { page = 1, limit = 10, status, testUserId } = req.query;
    const skip = (page - 1) * limit;

    const submittedBy = testUserId || req.user._id;

    const filter = { submittedBy };
    if (status) filter.status = status;

    const [refunds, total] = await Promise.all([
      Refund.find(filter)
        .populate('submittedBy', 'email')
        .populate('withdrawalId')
        .skip(skip)
        .limit(Number(limit))
        .sort({ createdAt: -1 }),

      Refund.countDocuments(filter)
    ]);

    res.status(200).json({
      success: true,
      data: refunds,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Merchant refund fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
};


exports.getAllRefunds = async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const skip = (page - 1) * limit;

    const filter = {};
    if (status) filter.status = status;

    const [refunds, total] = await Promise.all([
      Refund.find(filter)
        .populate('submittedBy', 'email')
        .populate('withdrawalId')
        .skip(skip)
        .limit(Number(limit))
        .sort({ createdAt: -1 }),

      Refund.countDocuments(filter)
    ]);

    res.status(200).json({
      success: true,
      data: refunds,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Admin refund fetch error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
};
