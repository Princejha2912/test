// controllers/transactionController.js
const Transaction = require('../models/depositeAmt.js');
const User = require('../models/user.js');
const Withdrawal = require('../models/withdrawal.js')
const logger = require('../logger/logger.js');
const blockchainService = require('../services/blockchainService.js');
const jwt = require('jsonwebtoken');
const { getSocketInstance } = require('../socketJs/socketInstance');
const { v4: uuidv4 } = require('uuid');


function emitUpdate(transactionId, payload) {
  const io = getSocketInstance();
  if (!io) {
    return;
  }
  io.to(transactionId).emit(`transaction-update-${transactionId}`, payload);
}

async function monitorTransaction(transactionId, walletAddress, amount, currencyType, clientId, callBackUrl, expiresAt) {
  let lessAmountEmitted = false;

  emitUpdate(transactionId, {
    status: '⏳ Waiting for wallet deposite confirmation...',
    message: '⏳ Waiting for wallet balance confirmation...'
  });

  const transaction = await Transaction.findOne({ transactionId });
  if (!transaction) return;

  if (transaction.status === "confirmed" || transaction.status === "expired") {
    emitUpdate(transactionId, {
      status: 'This transaction has already been processed.',
      message: '✅ This transaction has already been processed.'
    });
    return;
  }

  const merchant = await User.findById(clientId);
  if (!merchant) return;

  const adminWallet = currencyType === 'USDT-TRC20'
    ? process.env.ADMIN_WALLET_ADDRESS_TRC20
    : process.env.ADMIN_WALLET_ADDRESS;

  let result = null;

  const expiresAtTime = new Date(expiresAt).getTime();

  while (Date.now() < expiresAtTime) {
    if (currencyType === 'USDT-TRC20') {
      result = await blockchainService.checkTRC20Balance(
        transaction.walletAddress,
        amount,
        process.env.USDT_TRC20_CONTRACT
      );
    } else if (currencyType === 'USDT-ERC20') {
      result = await blockchainService.verifyTransaction(
        transaction.walletAddress,
        amount,
        currencyType
      );
    }

    if (!result.success) {
      await new Promise(res => setTimeout(res, 5000));
      continue;
    }

    if (!result.confirmed) {
      if (!lessAmountEmitted) {
        emitUpdate(transactionId, {
          status: '⚠️ Please deposit to continue.',
          message: '⚠️ Please deposit to continue.'
        });
        lessAmountEmitted = true;
      }
      await new Promise(res => setTimeout(res, 5000));
      continue;
    }

    // ✅ confirmed
    break;
  }

  if (!result || !result.confirmed) {
    transaction.status = 'expired';
    transaction.verificationData = {
      verifiedAt: new Date(),
      failureReason: 'Transaction expired before confirmation'
    };
    await transaction.save();

    emitUpdate(transactionId, {
      status: 'expired',
      message: '⌛ Transaction expired. Please initiate again.'
    });

    return;
  }

  // ✅ Transaction confirmed, continue rest of logic
  transaction.status = 'amount present on wallet';
  transaction.amount = amount;
  transaction.confirmedAt = new Date();
  transaction.verificationData = {
    ...result,
    verifiedAt: new Date(),
    responseMessage: result.message
  };

  const MAX_RETRIES = 3;
  let attempt = 0;
  let transfer;
  let success = false;

  while (attempt < MAX_RETRIES && !success) {
    attempt++;
    try {
      if (currencyType === 'USDT-TRC20') {
        transfer = await blockchainService.executeDepositTransferTRC20(
          transaction.walletAddress,
          transaction.walletSecretKey,
          adminWallet,
          result.actualBalance,
          process.env.USDT_TRC20_CONTRACT
        );

        const isTransferSuccess = transfer?.success === true ||
          (transfer?.response?.success === true && transfer?.response?.transaction);

        if (isTransferSuccess) {
          success = true;
          break;
        }

      } else {
        transfer = await blockchainService.executeDepositTransfer(
          transaction.walletAddress,
          transaction.walletSecretKey,
          adminWallet,
          result.actualBalance,
          process.env.USDT_ERC20_CONTRACT
        );

        if (transfer.success) {
          success = true;
          break;
        }
      }
    } catch (err) {
      console.error(`❌ Error on admin transfer attempt ${attempt}:`, err);
    }

    if (!success) {
      await new Promise(res => setTimeout(res, 3000));
    }
  }

  transaction.adminTransferData = {
    ...transfer,
    transferredAt: new Date(),
    transferredAmount: result.actualBalance,
    adminWallet: currencyType === 'USDT-ERC20' ? adminWallet : process.env.ADMIN_WALLET_ADDRESS,
    success: transfer?.success ?? false
  };

  if (success) {
    transaction.blockchainTxHash = currencyType === 'USDT-TRC20'
      ? transfer.response?.transaction
      : transfer.transactionHash;

    transaction.status = 'confirmed';
    transaction.actualBalance = result.actualBalance;

    await User.findByIdAndUpdate(merchant._id, {
      $inc: { totalAmt: result.actualBalance }
    });
  } else {
    transaction.status = 'amount present on wallet';
  }

  await transaction.save();

  emitUpdate(transactionId, {
    status: transaction.status,
    message: success
      ? '✅ Deposit confirmed and transferred to admin'
      : '⚠️ Deposit confirmed, admin transfer pending',
    confirmedAt: transaction.confirmedAt
  });
}





module.exports.createTransaction = async (req, res, next) => {
  try {
    const merchant = req.merchant;
    const currencyType = req.query.currencyType;
    const amount = req.query.amount
    const callBackUrl = req?.query?.callbackUrl


    if (!amount) return res.status(400).json({ success: false, message: 'Amount is required' });

    const transactionId = uuidv4();


    let walletData
    walletData = await blockchainService.generateWalletAddress(currencyType);
    if (!walletData.success) {
      return res.status(500).json({ success: false, error: 'Wallet generation failed' });
    }

    // get merchant details
    const merchantData = await User.findById(merchant._id);

    const walletAddress = walletData.walletAddress;
    const walletSecret = walletData.privateKey;
    const fee = (amount * merchantData.feeAmt) / 100

    const transaction = new Transaction({
      clientId: merchant._id,
      transactionId,
      walletAddress,
      amount,
      fee,
      netAmount: amount - fee,
      walletSecretKey: walletSecret,
      currencyType,
      status: 'initiated',

    });

    await transaction.save();



    const token = jwt.sign(
      {
        transactionId,
        walletAddress,
        currencyType,
        amount,
        clientId: merchant._id,
        transaction: transaction._id,
        ...(callBackUrl && { callBackUrl }),


      },
      process.env.JWT_SECRET,
      { expiresIn: '30m' }
    );

    // const paymentUrl = `https://crypto.node.rival.finance/api/v1/transaction/start/${token}`;
    const paymentUrl = `http://localhost:5000/api/v1/transaction/start/${token}`;



    return res.status(200).json({
      success: true,
      message: "Payment link generated successfully",
      url: paymentUrl
    });
  } catch (err) {
    console.error("Create Transaction Error:", err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
};

exports.startTransactionFromToken = async (req, res) => {
  try {
    const token = req.params.token;
    if (!token) return res.status(400).send('Missing token');

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const transaction = await Transaction.findOne({ transactionId: decoded.transactionId });
    if (!transaction) return res.status(404).send('Transaction not found');

    // Set or use existing expiration time
    let expiresAt = transaction.expiresAt;
    if (!expiresAt) {
      expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
      transaction.expiresAt = expiresAt;
      await transaction.save(); // ✅ Save it!
    }

    // ✅ Start monitoring for confirmations (only once)
    monitorTransaction(
      transaction.transactionId,
      transaction.walletAddress,
      transaction.netAmount,
      transaction.currencyType,
      transaction.clientId.toString(),
      decoded.callBackUrl,
      expiresAt
    );

    // ✅ Render the payment page
    return res.render('payment', {
      transactionId: transaction.transactionId,
      walletAddress: transaction.walletAddress,
      currencyType: transaction.currencyType,
      amount: transaction.amount,
      clientId: transaction.clientId,
      expiresAt: Math.floor(new Date(expiresAt).getTime() / 1000), // ⏰ Pass as UNIX timestamp
      transaction: transaction._id,
      callBackUrl: decoded.callBackUrl || ''
    });

  } catch (err) {
    console.error('Invalid or expired token:', err.message);
    return res.status(400).send('Invalid or expired payment link');
  }
};









// 3. GET MERCHANT TRANSACTIONS (Merchant sees their own transactions)
exports.getMerchantTransactions = async (req, res, next) => {
  try {
    const merchant = req.merchant;
    const {
      page = 1,
      limit = 10,
      status,
      currencyType,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      dateFrom,
      dateTo
    } = req.query;

    // Build filter object
    const filter = { clientId: merchant._id };

    if (status) {
      filter.status = status;
    }

    if (currencyType) {
      filter.currencyType = currencyType;
    }

    // Date range filter
    if (dateFrom || dateTo) {
      filter.createdAt = {};
      if (dateFrom) {
        filter.createdAt.$gte = new Date(dateFrom);
      }
      if (dateTo) {
        filter.createdAt.$lte = new Date(dateTo);
      }
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Get transactions with pagination
    const transactions = await Transaction.find(filter)
      .select('-walletSecretKey') // 🚫 exclude the field
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit))
      .select('-walletSecretKey') // Exclude sensitive data
      .lean();

    // Get total count for pagination
    const totalTransactions = await Transaction.countDocuments(filter);
    const totalPages = Math.ceil(totalTransactions / parseInt(limit));

    // Calculate summary statistics
    const summary = await Transaction.aggregate([
      { $match: { clientId: merchant._id } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' }
        }
      }
    ]);

    logger.info(`Merchant ${merchant.email} retrieved ${transactions.length} transactions (page ${page})`);

    res.status(200).json({
      success: true,
      message: 'Merchant transactions retrieved successfully',
      data: {
        transactions,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalTransactions,
          limit: parseInt(limit),
          hasNextPage: parseInt(page) < totalPages,
          hasPrevPage: parseInt(page) > 1
        },
        summary: summary.reduce((acc, item) => {
          acc[item._id] = {
            count: item.count,
            totalAmount: item.totalAmount
          };
          return acc;
        }, {}),
        filters: {
          status,
          currencyType,
          sortBy,
          sortOrder,
          dateFrom,
          dateTo
        }
      }
    });

  } catch (err) {
    logger.error(`Get merchant transactions failed: ${err.message}`);
    next(err);
  }
};

// 4. GET ALL TRANSACTIONS (ADMIN) - Sorted by created date
exports.getAllTransactions = async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 10,
      status,
      currencyType,
      merchantEmail,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      dateFrom,
      dateTo
    } = req.query;

    // Build filter object
    const filter = {};

    if (status) {
      filter.status = status;
    }

    if (currencyType) {
      filter.currencyType = currencyType;
    }

    // Date range filter
    if (dateFrom || dateTo) {
      filter.createdAt = {};
      if (dateFrom) {
        filter.createdAt.$gte = new Date(dateFrom);
      }
      if (dateTo) {
        filter.createdAt.$lte = new Date(dateTo);
      }
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Build aggregation pipeline
    let pipeline = [
      {
        $lookup: {
          from: 'users',
          localField: 'clientId',
          foreignField: '_id',
          as: 'merchant'
        }
      },
      {
        $unwind: '$merchant'
      }
    ];

    // Add merchant email filter if provided
    if (merchantEmail) {
      pipeline.push({
        $match: {
          'merchant.email': { $regex: merchantEmail, $options: 'i' }
        }
      });
    }

    // Add other filters
    if (Object.keys(filter).length > 0) {
      pipeline.push({ $match: filter });
    }

    // Add sorting, pagination, and field selection
    pipeline.push(
      { $sort: sortOptions },
      { $skip: skip },
      { $limit: parseInt(limit) },
      {
        $project: {
          transactionId: 1,
          amount: 1,
          currencyType: 1,
          status: 1,
          walletAddress: 1,
          createdAt: 1,
          confirmedAt: 1,
          expiresAt: 1,
          'merchant._id': 1,
          'merchant.name': 1,
          'merchant.email': 1,
          'merchant.companyName': 1,
          verificationData: {
            actualBalance: 1,
            expectedAmount: 1,
            network: 1,
            verifiedAt: 1,
            failureReason: 1
          },
          adminTransferData: {
            success: 1,
            transactionHash: 1,
            transferredAmount: 1,
            transferredAt: 1
          }
        }
      }
    );

    // Execute aggregation
    const transactions = await Transaction.aggregate(pipeline);

    // Get total count
    let countPipeline = [
      {
        $lookup: {
          from: 'users',
          localField: 'clientId',
          foreignField: '_id',
          as: 'merchant'
        }
      },
      {
        $unwind: '$merchant'
      }
    ];

    if (merchantEmail) {
      countPipeline.push({
        $match: {
          'merchant.email': { $regex: merchantEmail, $options: 'i' }
        }
      });
    }

    if (Object.keys(filter).length > 0) {
      countPipeline.push({ $match: filter });
    }

    countPipeline.push({ $count: 'total' });

    const countResult = await Transaction.aggregate(countPipeline);
    const totalTransactions = countResult.length > 0 ? countResult[0].total : 0;
    const totalPages = Math.ceil(totalTransactions / parseInt(limit));

    // Get summary statistics
    const summary = await Transaction.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' }
        }
      }
    ]);

    logger.info(`Admin retrieved ${transactions.length} transactions (page ${page}) sorted by ${sortBy} ${sortOrder}`);

    res.status(200).json({
      success: true,
      message: 'All transactions retrieved successfully',
      data: {
        transactions,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalTransactions,
          limit: parseInt(limit),
          hasNextPage: parseInt(page) < totalPages,
          hasPrevPage: parseInt(page) > 1
        },
        summary: summary.reduce((acc, item) => {
          acc[item._id] = {
            count: item.count,
            totalAmount: item.totalAmount
          };
          return acc;
        }, {}),
        filters: {
          status,
          currencyType,
          merchantEmail,
          sortBy,
          sortOrder,
          dateFrom,
          dateTo
        }
      }
    });

  } catch (err) {
    logger.error(`Get all transactions failed: ${err.message}`);
    next(err);
  }
};





exports.getAdminMerchantTransactions = async (req, res, next) => {
  try {


    const { merchantId } = req.params;
    const {
      pageDeposits = 1,
      pageWithdrawals = 1,
      limit = 10,
    } = req.query;

    const merchant = await User.findById(merchantId);
    if (!merchant) {
      return res.status(404).json({
        success: false,
        message: 'Merchant not found',
      });
    }

    const depositFilter = { clientId: merchantId };
    const withdrawalFilter = { clientId: merchantId };

    const [deposits, totalDeposits, withdrawals, totalWithdrawals] = await Promise.all([
      Transaction.find(depositFilter)
        .skip((pageDeposits - 1) * limit)
        .limit(Number(limit))
        .select('-walletSecretKey')
        .lean(),
      Transaction.countDocuments(depositFilter),

      Withdrawal.find(withdrawalFilter)
        .skip((pageWithdrawals - 1) * limit)
        .limit(Number(limit))
        .lean(),
      Withdrawal.countDocuments(withdrawalFilter),
    ]);

    res.status(200).json({
      success: true,
      data: {
        deposits,
        withdrawals,
        pagination: {
          deposits: {
            currentPage: Number(pageDeposits),
            totalItems: totalDeposits,
            totalPages: Math.ceil(totalDeposits / limit),
          },
          withdrawals: {
            currentPage: Number(pageWithdrawals),
            totalItems: totalWithdrawals,
            totalPages: Math.ceil(totalWithdrawals / limit),
          },
        },
      },
    });
  } catch (err) {
    next(err);
  }
};





