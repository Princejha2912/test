const User = require('../models/user.js');
const logger = require('../logger/logger.js');
const { sendEmail } = require('../util/nodeMailer.js');
const { generateCredentials } = require('../util/generateApiKeySecret.js');
const { generateMerchantApprovalEmail } = require('../util/generateMerchantApprovalEmail.js');
const NotificationService = require('../services/notificationService.js');
const blockchainService = require('../services/blockchainService.js');

exports.approveMerchant = async (req, res, next) => {
    try {

        const user = await User.findById(req.params.userId);
       const { feeAmt } = req.body;
      
      
       if (!feeAmt) {
      return res.status(400).json({ success: false, message: 'Invalid Fee ID' });
       }

        if (!user || user.role !== 'merchant') {
        return res.status(404).json({
            success: false,
            message: 'Merchant not found',
            error: 'Invalid merchant user ID',
        });
        }

        // If already approved
        if (user.approved === 'approved') {
        return res.status(400).json({
            success: false,
            message: 'Merchant already approved',
            error: 'Already approved',
        });
        }

        // Generate and save credentials
        const tempPassword = user.tempPassword;
        if (!user?.apiKey || !user?.apiSecret) {
            const { apiKey, apiSecret } = generateCredentials();
            user.apiKey = apiKey;
            user.apiSecret = apiSecret;
          
        }

        // Generate wallet for merchant if not exists
        let walletData = null;
        if (!user.walletAddress) {
            try {
                logger.info(`Generating wallet for merchant: ${user.email}`);
                walletData = await blockchainService.generateWalletAddress('USDT-ERC20');

                if (walletData.success) {
                    user.walletAddress = walletData.walletAddress;
                    user.walletPrivateKey = walletData.privateKey; // Store securely
                    user.walletNetwork = walletData.network;
                    user.walletGeneratedAt = new Date();

                    logger.info(`Wallet generated for merchant ${user.email}: ${walletData.walletAddress} (Count: ${walletData.count})`);
                } else {
                    logger.error(`Failed to generate wallet for merchant ${user.email}: ${walletData.error}`);
                    // Continue with approval even if wallet generation fails
                }
            } catch (walletError) {
                logger.error(`Wallet generation error for merchant ${user.email}: ${walletError.message}`);
                // Continue with approval even if wallet generation fails
            }
        }

        user.approved = 'approved';
        user.tempPassword = ""; // Save for email only (not hashed)
        user.feeAmt =feeAmt;
        await user.save();


       const html = generateMerchantApprovalEmail({
           name: user.name,
           email: user.email,
           password: tempPassword,
           apiKey: user.apiKey,
           apiSecret: user.apiSecret,
           walletAddress: user.walletAddress || 'Wallet generation failed',
  walletNetwork: user.walletNetwork || 'N/A',
  walletGenerated: walletData?.success || false,
  walletGeneratedAt: user.walletGeneratedAt || null,
  feeType: 'Percentage',
  feeValue: feeAmt
});
        await sendEmail({
        to: user.email,
        subject: 'Your Merchant Account Has Been Approved',
        html,
        });

        // Create notification for the merchant
        try {
            await NotificationService.createMerchantNotification(
                user._id,
                'merchant_approved'
            );
            logger.info(`Approval notification created for merchant: ${user.email}`);
        } catch (notificationError) {
            logger.error(`Failed to create approval notification: ${notificationError.message}`);
        }

        logger.info(`Merchant approved and email sent to: ${user.email}`);

        res.status(200).json({
            success: true,
            message: 'Merchant approved, credentials and wallet generated',
            data: {
                userId: user._id,
                name: user.name,
                email: user.email,
                approved: user.approved,
                apiKey: user.apiKey,
                walletAddress: user.walletAddress,
                walletNetwork: user.walletNetwork,
                walletGenerated: walletData?.success || false,
                walletGeneratedAt: user.walletGeneratedAt
            },
            error: null,
        });
    } catch (err) {
        logger.error(`Merchant approval failed: ${err.message}`);
        next(err);
    }
};

exports.blockMerchant = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.userId);

    if (!user || user.role !== 'merchant') {
      return res.status(404).json({
        success: false,
        message: 'Merchant not found',
        error: 'Invalid merchant user ID',
      });
    }

    // If already rejected
    if (user.approved === 'block') {
      return res.status(400).json({
        success: false,
        message: 'Merchant already blocked',
        error: 'Already blocked',
      });
    }

    // If already approved, maybe prevent rejection or allow? Here we allow rejection.
    user.approved = 'block';
    await user.save();

    // Optional: Send email notification about rejection
    const html = `<p>Dear ${user.name},</p>
      <p>Your merchant application has been blocked. Please contact support for more information.</p>`;

    await sendEmail({
      to: user.email,
      subject: 'Merchant Application blocked',
      html,
    });

    // Create notification for the merchant
    try {
      await NotificationService.createMerchantNotification(
        user._id,
        'merchant_blocked'
      );
      logger.info(`Block notification created for merchant: ${user.email}`);
    } catch (notificationError) {
      logger.error(`Failed to create block notification: ${notificationError.message}`);
    }

    logger.info(`Merchant blocked and notification sent to: ${user.email}`);

    res.status(200).json({
      success: true,
      message: 'Merchant blocked and notification sent via email',
      data: {
        userId: user._id,
        name: user.name,
        email: user.email,
        approved: user.approved
      },
      error: null,
    });
  } catch (err) {
    logger.error(`Merchant rejection failed: ${err.message}`);
    next(err);
  }
};
