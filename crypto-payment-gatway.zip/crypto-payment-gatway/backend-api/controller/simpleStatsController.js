const SimpleStatsService = require('../services/simpleStatsService');
const logger = require('../logger/logger');

/**
 * Get merchant's own statistics
 */
exports.getMyStats = async (req, res, next) => {
  try {
    const merchantId = req.user._id;

    const stats = await SimpleStatsService.getMerchantStatsWithRates(merchantId);

    res.status(200).json({
      success: true,
      data: stats,
      error: null
    });

  } catch (error) {
    logger.error(`Get my stats error: ${error.message}`);
    next(error);
  }
};

/**
 * Admin: Get platform statistics
 */
exports.getPlatformStats = async (req, res, next) => {
  try {
    const stats = await SimpleStatsService.getPlatformStatsWithRates();

    res.status(200).json({
      success: true,
      data: stats,
      error: null
    });

  } catch (error) {
    logger.error(`Get platform stats error: ${error.message}`);
    next(error);
  }
};

/**
 * Admin: Get all merchant statistics
 */
exports.getAllMerchantStats = async (req, res, next) => {
  try {
    const stats = await SimpleStatsService.getAllMerchantStats();

    res.status(200).json({
      success: true,
      data: stats,
      error: null
    });

  } catch (error) {
    logger.error(`Get all merchant stats error: ${error.message}`);
    next(error);
  }
};

/**
 * Admin: Get specific merchant statistics
 */
exports.getSpecificMerchantStats = async (req, res, next) => {
  try {
    const { merchantId } = req.params;

    const stats = await SimpleStatsService.getMerchantStatsWithRates(merchantId);

    if (!stats) {
      return res.status(404).json({
        success: false,
        message: 'Merchant statistics not found',
        error: 'No statistics available for this merchant'
      });
    }

    res.status(200).json({
      success: true,
      data: stats,
      error: null
    });

  } catch (error) {
    logger.error(`Get specific merchant stats error: ${error.message}`);
    next(error);
  }
};
