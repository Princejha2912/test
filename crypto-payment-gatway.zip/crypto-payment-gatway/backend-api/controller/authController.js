const User = require('../models/user.js');
const { generateToken }= require('../util/generateToken.js');
const {generateResetTemplate } =  require('../util/generateResetTemplate.js')
const logger = require('../logger/logger.js');
const { error } = require('winston');
const crypto = require('crypto');
const {sendEmail} = require('../util/nodeMailer.js');
const NotificationService = require('../services/notificationService.js');

// Register - Enhanced with additional merchant fields
exports.register = async (req, res, next) => {
  try {
    const {
      name,
      email,
      password,
      confirmPassword,
      country,
      phoneNo,
      companyName,
      licenceNo,
    } = req.body;

    logger.info(`Attempting to register user: ${email}`);

    // Validation for password confirmation
    if (password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'Passwords do not match',
        error: 'Password confirmation failed'
      });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      logger.warn(`Registration failed: User with email ${email} already exists.`);
      return res.status(400).json({
        success: false,
        message: 'User already exists',
        error: 'User already exists'
      });
    }

    const user = new User({
      name,
      email,
      password,
      country,
      phoneNo,
      companyName,
      licenceNo,
      role: 'merchant',
      approved: 'pending',
      tempPassword: password,
    });

    await user.save();
    logger.info(`New ${user.role} registered: ${email}`);

    if (user.role !== 'merchant') {
      // generateToken(user, res);
      logger.info(`Token generated for user: ${email}`);
    } else {
      logger.info(`Merchant account pending approval: ${email}`);
    }

    return res.status(201).json({
      success: true,
      message: user.role === 'merchant'
        ? 'Merchant account created. Awaiting admin approval.'
        : 'User registered successfully.',
      error: null
    });
  } catch (err) {
    logger.error(`Registration error: ${err.message}`);
    next(err);
  }
};


// Login - Enhanced with OTP functionality
exports.login = async (req, res, next) => {
  try {
    const { email, password, otp } = req.body;
    logger.info(`Login attempt by: ${email}`);

    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password))) {
      logger.warn(`Login failed for ${email}: Invalid credentials`);
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
        error: 'Invalid credentials'
      });
    }

    if (user.role === 'merchant' && user.approved !== 'approved') {
      logger.warn(`Login blocked for ${email}: Merchant not approved`);
      return res.status(403).json({
        success: false,
        message: 'Account not approved yet',
        error: 'Account not approved yet'
      });
    }

    // If OTP is not provided, send OTP
    if (!otp) {
      // Generate OTP for login
      const loginOtp = user.generateOTP();
      await user.save();

      // Send login OTP
      try {
        await sendEmail({
          to: email,
          subject: 'Login OTP - Crypto Payment Gateway',
          html: `
            <div style="font-family: Arial, sans-serif; padding: 20px;">
              <h2>Login Verification</h2>
              <p>Hello ${user.name},</p>
              <p>Someone is trying to login to your account. If this is you, use the OTP below:</p>
              <div style="background-color: #f5f5f5; padding: 20px; text-align: center; margin: 20px 0;">
                <h1 style="color: #007bff; font-size: 32px; margin: 0;">${loginOtp}</h1>
                
                <p style="margin: 10px 0 0 0; color: #666;">This OTP will expire in 10 minutes</p>
              </div>
              <p>If you didn't try to login, please ignore this email and consider changing your password.</p>
              <hr>
              <small>Crypto Payment Gateway Team</small>
            </div>
          `
        });
        logger.info(`Login OTP sent to: ${email}`);
      } catch (emailError) {
        logger.error(`Failed to send login OTP: ${emailError.message}`);
      }

      return res.status(200).json({
        success: true,
        message: 'OTP sent to your email. Please verify to complete login.',
        data: {
          userId: user._id,
          email: user.email,
          requiresOTP: true
        },
        error: null
      });
    }

    // If OTP is provided, verify it
    if (!user.verifyOTP(otp)) {
      logger.warn(`Login OTP verification failed for ${email}: Invalid OTP`);
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP',
        error: 'OTP verification failed'
      });
    }

    // Clear OTP and complete login
    user.clearOTP();
    await user.save();

    generateToken(user, res);
    logger.info(`Login successful for: ${email}`);

    res.status(200).json({
      success: true,
      message: 'Logged in successfully',
      data: {
        user: {
          id: user._id,
          name: user.name,
          role:user.role
        
        }
      },
      error: null
    });
  } catch (err) {
    logger.error(`Login error for ${req.body.email}: ${err.message}`);
    next(err);
  }
};

// Logout
exports.logout = (req, res) => {
  const token = req.cookies?.token;
  if (token) {
    logger.info('User logged out');
  } else {
    logger.info('Logout attempt without token');
  }

  res.clearCookie('token', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
  });

  res.status(200).json({
    success: true,
    message: 'Logged out successfully',
    error: null
  });
};

// change password
exports.changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);

    if (!user) {
      logger.warn(`Change password failed: User not found`);
      return res.status(404).json({
        success: false,
        message: 'User not found',
        error: 'User not found'
      });
    }

    const isMatch = await user.matchPassword(currentPassword);
    if (!isMatch) {
      logger.warn(`Change password failed for ${user.email}: Incorrect current password`);
      return res.status(400).json({
        success: false,
        message: 'Incorrect current password',
        error: 'Incorrect current password'
      });
    }

    user.password = newPassword; // Will be hashed in pre-save middleware
    await user.save();

    logger.info(`Password changed successfully for user: ${user.email}`);

    return res.status(200).json({
      success: true,
      message: 'Password changed successfully',
      error: null
    });
  } catch (err) {
    logger.error(`Change password error: ${err.message}`);
    next(err);
  }
};

//forgetPassword
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No user found with this email',
        error: 'User not found'
      });
    }

    // Generate token
    const token = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    // Set reset fields
    user.resetPasswordToken = hashedToken;
    user.resetPasswordExpires = Date.now() + 15 * 60 * 1000; // 15 minutes
    await user.save({ validateBeforeSave: false });

    // Email link
    const resetUrl = `${process.env.CLIENT_URL}/reset-password/${token}`;
    const html = generateResetTemplate(user.name, resetUrl);

    await sendEmail({
      to: user.email,
      subject: 'Password Reset Instructions',
      html
    });

    res.json({
      success: true,
      message: 'Password reset email sent',
      error: null
    });
  } catch (err) {
    next(err);
  }
};

// Reset Password
exports.resetPassword = async (req, res, next) => {
  try {
    const { token } = req.params;
    const { password } = req.body;

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired token',
        error: 'Invalid token'
      });
    }

    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.json({
      success: true,
      message: 'Password reset successful',
      error: null
    });
  } catch (err) {
    next(err);
  }
};

