const Withdrawal = require('../models/withdrawal');
const Fee = require('../models/FeeSetting');
const User = require('../models/user');
const NotificationService = require('../services/notificationService');
const AdminNotificationService = require('../services/adminNotification');
const SimpleStatsService = require('../services/simpleStatsService');
const blockchainService = require('../services/blockchainService');
const logger = require('../logger/logger');

exports.initiateWithdrawal = async (req, res, next) => {
  try {
    const merchant = req.user;
    const { amount, merchantWallet, currencyType } = req.body;

    // Step 1: Calculate available balance
    const availableBalance = merchant.totalAmt - (merchant.pendingAmt || 0);
    if (amount > availableBalance) {
      return res.status(400).json({
        success: false,
        message: `Insufficient balance. Available: ${availableBalance} USDT, Requested: ${amount} USDT`,
        error: 'Insufficient funds'
      });
    }
    if (amount <= 1) {
      return res.status(400).json({
        success: false,
        message: `Minimum deposit amount is greater than 1 USDT. You tried to deposit ${amount} USDT.`,
        error: 'Insufficient deposit amount'
      });

    }
    // Step 2: Update merchant's pendingAmt in DB
    const user = await User.findByIdAndUpdate(
      merchant._id,
      { $inc: { pendingAmt: amount } }
    );

    // const fee = (amount * user.feeAmt) / 100;
    const fee = 0;

    // Step 3: Create withdrawal request
    const withdrawal = new Withdrawal({
      clientId: merchant._id,
      amount,
      clientWallet: merchantWallet,
      status: 'pending',
      currencyType,
      fee,
      netAmount: amount - fee
    });

    await withdrawal.save();
    await withdrawal.populate('clientId', 'name email');

    // Step 4: Notify admin
    try {
      await AdminNotificationService.notifyWithdrawalRequest(withdrawal, merchant);
      await NotificationService.sendAdminAlert(
        'New Withdrawal Request',
        `Merchant ${merchant.name} has requested a withdrawal of ${amount} USDT`,
        {
          merchantId: merchant._id,
          merchantName: merchant.name,
          merchantEmail: merchant.email,
          amount,
          clientWallet: merchantWallet,
          withdrawalId: withdrawal._id
        }
      );
    } catch (notificationError) {
      console.error('Failed to send withdrawal notification:', notificationError.message);
    }

    // Step 5: Respond
    res.status(201).json({
      success: true,
      message: 'Withdrawal request submitted successfully. Awaiting admin approval.',
      data: {
        withdrawal: {
          id: withdrawal._id,
          amount: withdrawal.amount,
          currencyType: withdrawal.currencyType,
          status: withdrawal.status,
          clientWallet: merchantWallet,
          createdAt: withdrawal.createdAt,
          estimatedProcessingTime: '24-48 hours'
        }
      },
      error: null
    });

  } catch (err) {
    next(err);
  }
};

exports.handleWithdrawalStatus = async (req, res, next) => {
  try {
    const { withdrawalId } = req.params;
    const { action, adminNotes } = req.body;
    const admin = req.user;

    const withdrawal = await Withdrawal.findById(withdrawalId).populate('clientId');
    if (!withdrawal) {
      return res.status(404).json({ success: false, message: 'Withdrawal not found' });
    }
    if (withdrawal.type === 'refund') {
      return res.status(404).json({ success: false, message: 'Withdrawal refund cant be approve ' });
    }

    if (withdrawal.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: `Withdrawal already ${withdrawal.status}`,
      });
    }

    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid action (must be approve or reject)',
      });
    }

    // 🛑 Rejection Flow
    if (action === 'reject') {
      withdrawal.status = 'rejected';
      withdrawal.adminNotes = adminNotes || 'Rejected by admin';
      withdrawal.processedAt = new Date();
      withdrawal.processedBy = admin._id;

      await withdrawal.save();

      // refund merchant's pending amount
      const clientId = withdrawal.clientId;
      await User.findByIdAndUpdate(
        clientId._id,
        { $inc: { pendingAmt: -withdrawal.amount } }
      );


      return res.status(200).json({
        success: true,
        message: 'Withdrawal rejected',
        data: { withdrawal },
      });
    }


    // if(transaction.amount <=1){
    //    return res.status(400).json({
    //    message: 'withdrawal amount should be greater than 1',
    //     error: `Fee: ${fee}, Withdrawal: ${withdrawal.amount}`,
    //    })
    // }

    // ✅ Approval Flow
    const merchant = withdrawal.clientId;
    let fee = 0;
    let feeDetails = null;

    if (withdrawal.amount <= 100) {
      fee = 1;
      feeDetails = {
        feeType: 'percentage_from_user_model',
        feePercentage: 1,
        calculatedFee: -1,
      };
    } else {
      if (merchant?.feeAmt && merchant.feeAmt > 0) {
        fee = (withdrawal.amount * merchant.feeAmt) / 100;
        feeDetails = {
          feeType: 'percentage_from_user_model',
          feePercentage: merchant.feeAmt,
          calculatedFee: fee,
        };
      }
    }


    fee = 0;
    feeDetails = null;
    const netAmount = withdrawal.amount - fee;

    if (netAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Fee is greater than or equal to withdrawal amount',
        error: `Fee: ${fee}, Withdrawal: ${withdrawal.amount}`,
      });
    }

    if (merchant.totalAmt < withdrawal.amount) {
      return res.status(400).json({
        success: false,
        message: 'Insufficient merchant balance',
      });
    }

    let blockchainResult;
    try {
      if (withdrawal.currencyType === 'USDT-TRC20') {
        blockchainResult = await blockchainService.executeTRC20Withdrawal(
          process.env.ADMIN_WALLET_ADDRESS_TRC20,
          process.env.ADMIN_WALLET_PRIVATE_KEY_TRC20,
          withdrawal.clientWallet,
          netAmount,
          process.env.USDT_TRC20_CONTRACT
        );
      }

      if (withdrawal.currencyType === 'USDT-ERC20') {
        blockchainResult = await blockchainService.executeAdminWithdrawal(
          withdrawal.clientWallet,
          netAmount,
          withdrawal.currencyType
        );
      }


    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Blockchain execution failed',
        error: err.message,
      });
    }

    // Set common fields
    withdrawal.fee = fee;
    withdrawal.netAmount = netAmount;
    withdrawal.adminNotes = adminNotes || 'Approved by admin';
    withdrawal.processedAt = new Date();
    withdrawal.processedBy = admin._id;

    if (blockchainResult?.success) {
      merchant.totalAmt -= withdrawal.amount;
      merchant.pendingAmt = Math.max(0, (merchant.pendingAmt || 0) - withdrawal.amount);
      await merchant.save();

      withdrawal.status = 'completed';
      withdrawal.transactionHash = blockchainResult.transactionHash;
      if (withdrawal.currencyType === 'USDT-ERC20') {
        withdrawal.blockchainData = {
          transactionHash: blockchainResult.transactionHash,
          blockHash: blockchainResult.blockHash,
          blockNumber: blockchainResult.blockNumber,
          gasUsed: blockchainResult.gasUsed,
          effectiveGasPrice: blockchainResult.effectiveGasPrice,
          from: blockchainResult.from,
          to: blockchainResult.to,
          status: blockchainResult.status,
          logs: blockchainResult.logs,
          contractAddress: blockchainResult.contractAddress,
          network: blockchainResult.currencyType,
          executedAt: new Date(),
          blockchainDetails: blockchainResult.blockchainDetails,
        };
      }
      if (withdrawal.currencyType === 'USDT-TRC20') {
        withdrawal.blockchainData = {
          transactionHash: blockchainResult.transactionHash,
          senderAddress: blockchainResult.senderAddress,
          receiverAddress: blockchainResult.receiverAddress,
          contractAddress: blockchainResult.contractAddress,
          network: blockchainResult.network,
          responseMessage: blockchainResult.responseMessage,
          executedAt: new Date(),
          responseCode: blockchainResult.data?.responseCode,
          rawTxHash: blockchainResult.data?.txHash,
        };
      }

    } else {
      withdrawal.status = 'failed';
      withdrawal.blockchainData = {
        error: blockchainResult?.error || 'Blockchain transfer failed',
        network: withdrawal.currencyType || 'USDT-ERC20',
        failedAt: new Date(),
      };
    }

    await withdrawal.save();

    // 📊 Stats
    try {
      await SimpleStatsService.recordWithdrawal(
        merchant._id,
        withdrawal.amount,
        withdrawal.status === 'completed',
        withdrawal.fee
      );
    } catch (err) {
      console.error('📉 Stats logging failed:', err.message);
    }

    // 🔔 Notification
    try {
      await NotificationService.createWithdrawalNotification(
        merchant._id,
        withdrawal.status === 'completed' ? 'withdrawal_approved' : 'withdrawal_failed',
        withdrawal._id.toString(),
        withdrawal.amount
      );
    } catch (err) {
      console.error('🔕 Notification failed:', err.message);
    }

    return res.status(200).json({
      success: true,
      message:
        withdrawal.status === 'completed'
          ? 'Withdrawal successful'
          : 'Withdrawal approval failed at blockchain level',
      data: {
        withdrawal: {
          id: withdrawal._id,
          amount: withdrawal.amount,
          fee: withdrawal.fee,
          netAmount: withdrawal.netAmount,
          status: withdrawal.status,
          adminNotes: withdrawal.adminNotes,
          processedAt: withdrawal.processedAt,
          processedBy: admin.name,
          feeDetails,
          transactionHash: withdrawal.transactionHash || null,
          blockchainData: withdrawal.blockchainData || null,
        },
      },
    });
  } catch (error) {
    console.error('❌ handleWithdrawalStatus Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message,
    });
  }
};

exports.widthdrawalHandlerRefund = async (withdrawalId, action, adminNotes, admin) => {
  try {
    const withdrawal = await Withdrawal.findById(withdrawalId).populate('clientId');
    if (!withdrawal) {
      return { success: false, message: 'Withdrawal not found' };
    }



    if (!['approve', 'reject'].includes(action)) {
      return {
        success: false,
        message: 'Invalid action (must be approve or reject)',
      };
    }

    // 🛑 Rejection Flow
    if (action === 'reject') {
      withdrawal.status = 'rejected';
      withdrawal.adminNotes = adminNotes || 'Rejected by admin';
      withdrawal.processedAt = new Date();
      withdrawal.processedBy = admin._id;
      await withdrawal.save();

      return {
        success: true,
        message: 'Withdrawal rejected',
        data: { withdrawal },
      };
    }

    // ✅ Approval Flow
    const merchant = withdrawal.clientId;
    let fee = 0;
    let feeDetails = null;

    if (merchant?.feeAmt && merchant.feeAmt > 0) {
      fee = (withdrawal.amount * merchant.feeAmt) / 100;
      feeDetails = {
        feeType: 'percentage_from_user_model',
        feePercentage: merchant.feeAmt,
        calculatedFee: fee,
      };
    }

    const netAmount = withdrawal.amount - fee;

    if (netAmount <= 0) {
      return {
        success: false,
        message: 'Fee is greater than or equal to withdrawal amount',
        error: `Fee: ${fee}, Withdrawal: ${withdrawal.amount}`,
      };
    }

    if (merchant.totalAmt < withdrawal.amount) {
      return {

        success: false,
        message: 'Insufficient merchant balance',
      };
    }

    let blockchainResult;
    try {

      if (withdrawal.currencyType === 'USDT-TRC20') {
        blockchainResult = await blockchainService.executeTRC20Withdrawal(
          process.env.ADMIN_WALLET_ADDRESS_TRC20,
          process.env.ADMIN_WALLET_PRIVATE_KEY_TRC20,
          withdrawal.clientWallet,
          netAmount,
          process.env.USDT_TRC20_CONTRACT
        );
      } else {
        blockchainResult = await blockchainService.executeAdminWithdrawal(
          withdrawal.clientWallet,
          netAmount,
          withdrawal.currencyType
        );
      }
    } catch (err) {
      console.error('Blockchain Error:', err.message);
      return {
        success: false,
        message: 'Blockchain execution failed',
        error: err.message,
      };
    }

    // Finalize withdrawal data
    withdrawal.fee = fee;
    withdrawal.netAmount = netAmount;
    withdrawal.adminNotes = adminNotes || 'Approved by admin';
    withdrawal.processedAt = new Date();
    withdrawal.processedBy = admin._id;

    if (blockchainResult?.success) {
      merchant.totalAmt -= withdrawal.amount;
      merchant.pendingAmt = Math.max(0, (merchant.pendingAmt || 0) - withdrawal.amount);
      await merchant.save();

      withdrawal.status = 'completed';
      withdrawal.transactionHash = blockchainResult.transactionHash;

      withdrawal.blockchainData =
        withdrawal.currencyType === 'USDT-TRC20'
          ? {
            transactionHash: blockchainResult.transactionHash,
            senderAddress: blockchainResult.senderAddress,
            receiverAddress: blockchainResult.receiverAddress,
            contractAddress: blockchainResult.contractAddress,
            network: blockchainResult.network,
            responseMessage: blockchainResult.responseMessage,
            executedAt: new Date(),
            responseCode: blockchainResult.data?.responseCode,
            rawTxHash: blockchainResult.data?.txHash,
          }
          : {
            transactionHash: blockchainResult.transactionHash,
            blockHash: blockchainResult.blockHash,
            blockNumber: blockchainResult.blockNumber,
            gasUsed: blockchainResult.gasUsed,
            effectiveGasPrice: blockchainResult.effectiveGasPrice,
            from: blockchainResult.from,
            to: blockchainResult.to,
            status: blockchainResult.status,
            logs: blockchainResult.logs,
            contractAddress: blockchainResult.contractAddress,
            network: blockchainResult.currencyType,
            executedAt: new Date(),
            blockchainDetails: blockchainResult.blockchainDetails,
          };
    } else {
      withdrawal.status = 'failed';
      withdrawal.blockchainData = {
        error: blockchainResult?.error || 'Blockchain transfer failed',
        network: withdrawal.currencyType || 'USDT-ERC20',
        failedAt: new Date(),
      };
    }

    await withdrawal.save();

    try {
      await SimpleStatsService.recordWithdrawal(
        merchant._id,
        withdrawal.amount,
        withdrawal.status === 'completed',
        withdrawal.fee
      );
    } catch (err) {
      console.error('📉 Stats logging failed:', err.message);
    }

    try {
      await NotificationService.createWithdrawalNotification(
        merchant._id,
        withdrawal.status === 'completed' ? 'withdrawal_approved' : 'withdrawal_failed',
        withdrawal._id.toString(),
        withdrawal.amount
      );
    } catch (err) {
      console.error('🔕 Notification failed:', err.message);
    }

    return {
      success: true,
      message:
        withdrawal.status === 'completed'
          ? 'Withdrawal successful'
          : 'Withdrawal approval failed at blockchain level',
      data: {
        withdrawal: {
          id: withdrawal._id,
          amount: withdrawal.amount,
          fee: withdrawal.fee,
          netAmount: withdrawal.netAmount,
          status: withdrawal.status,
          adminNotes: withdrawal.adminNotes,
          processedAt: withdrawal.processedAt,
          processedBy: admin.name,
          feeDetails,
          transactionHash: withdrawal.transactionHash || null,
          blockchainData: withdrawal.blockchainData || null,
        },
      },
    };
  } catch (error) {
    console.error('❌ widthdrawalHandlerRefund Error:', error);
    return {
      success: false,
      message: 'Internal server error',
      error: error.message,
    };
  }
};




exports.getAllWithdrawals = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, status, search, fromDate, toDate } = req.query;

    const filter = {};
    if (status) {
      filter.status = status;
    }
    if (fromDate && toDate) {
      filter.createdAt = {
        $gte: new Date(fromDate),
        $lte: new Date(toDate)
      };
    } else if (fromDate) {
      filter.createdAt = {
        $gte: new Date(fromDate)
      };
    } else if (toDate) {
      filter.createdAt = {
        $lte: new Date(toDate)
      };
    }

    if (search) {
      const regex = new RegExp(search, 'i'); // Case-insensitive search
      filter.$or = [
        { 'clientId.name': regex },
        { 'clientId.email': regex },
        { 'clientId.companyName': regex },
        { status: regex },
      ];
    }

    const withdrawals = await Withdrawal.find(filter)
      .populate('clientId', 'name email companyName pendingAmt totalAmt') // Populate merchant info using clientId
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Withdrawal.countDocuments(filter);

    res.status(200).json({
      success: true,
      data: withdrawals,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    next(err);
  }
};

// GET withdrawals for specific merchant with pagination
exports.getMerchantWithdrawals = async (req, res, next) => {
  try {
    const { merchantId } = req.params;
    const { page = 1, limit = 10, status, fromDate, toDate } = req.query;

    const merchantExists = await User.findOne({ _id: merchantId, role: 'merchant' });
    if (!merchantExists) {
      return res.status(404).json({ success: false, message: 'Merchant not found' });
    }

    const filter = { clientId: merchantId };
    if (status) {
      filter.status = status;
    }
    if (fromDate && toDate) {
      filter.createdAt = {
        $gte: new Date(fromDate),
        $lte: new Date(toDate)
      };
    } else if (fromDate) {
      filter.createdAt = {
        $gte: new Date(fromDate)
      };
    }
    else if (toDate) {
      filter.createdAt = {
        $lte: new Date(toDate)
      };
    }


    const withdrawals = await Withdrawal.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Withdrawal.countDocuments(filter);

    res.status(200).json({
      success: true,
      data: withdrawals,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    next(err);
  }
};

// GET merchant's own withdrawals with pagination
exports.getMyWithdrawals = async (req, res, next) => {
  try {
    const merchant = req.user;
    const { page = 1, limit = 10, status, fromDate, toDate } = req.query;

    const filter = { clientId: merchant._id };
    if (status) {
      filter.status = status;
    }

    if (fromDate && toDate) {
      filter.createdAt = {
        $gte: new Date(fromDate),
        $lte: new Date(toDate)
      };
    }
    else if (fromDate) {
      filter.createdAt = {
        $gte: new Date(fromDate)
      };
    }
    else if (toDate) {
      filter.createdAt = {
        $lte: new Date(toDate)
      };
    }


    const withdrawals = await Withdrawal.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await Withdrawal.countDocuments(filter);

    res.status(200).json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / limit),
      data: withdrawals,
      error: null
    });
  } catch (err) {
    next(err);
  }
};

