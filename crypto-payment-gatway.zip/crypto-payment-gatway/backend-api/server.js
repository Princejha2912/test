// server.js
const http = require('http');
const {app} = require('./app');
const { initSocketServer } = require('./socketJs/initSocketServer');


const server = http.createServer(app);
initSocketServer(server); // ✅ this sets socket instance

server.listen(`${process.env.BACKENDPORTNO}`, () => {
  // console.log(`✅ http://localhost:5000`);
    console.log(`✅ https://backend.payglobal.co.in`);

});
