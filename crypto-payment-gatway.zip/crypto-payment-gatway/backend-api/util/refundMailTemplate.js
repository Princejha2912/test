module.exports = function generateComplainUpdateEmail({
  name,
  complainId,
  status,
  updatedBy,
  remarks = '',
  createdAt,
  updatedAt
}) {
  return {
    subject: `Complaint Update - ${status.toUpperCase()}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee;">
        <h2 style="color: #333;">Complaint Update Notification</h2>
        <p>Dear <strong>${name}</strong>,</p>

        <p>Your complaint with the ID <strong>${complainId}</strong> has been updated.</p>

        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Status</td>
            <td style="padding: 8px; border: 1px solid #ddd;"><strong>${status.toUpperCase()}</strong></td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Updated By</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${updatedBy}</td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Created At</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${new Date(createdAt).toLocaleString()}</td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Last Updated</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${new Date(updatedAt).toLocaleString()}</td>
          </tr>
          ${
            remarks
              ? `
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Remarks</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${remarks}</td>
          </tr>`
              : ''
          }
        </table>

        <p>If you have further questions or concerns, feel free to reach out to our support team.</p>

        <p>Best regards,<br/>Support Team</p>
      </div>
    `,
  };
};
