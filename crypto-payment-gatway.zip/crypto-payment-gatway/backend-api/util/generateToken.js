const jwt = require('jsonwebtoken');


exports.generateToken = (user, res) => {
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET||"asdadd123987", {
    expiresIn: '7d',
  });

 res.cookie('token', token, {
  httpOnly: true,
  secure: false,           // localhost is not HTTPS
  sameSite: 'lax',         // allow cross-origin from localhost
  maxAge: 7 * 24 * 60 * 60 * 1000
});
};





