// utils/sendCallback.js
const axios = require('axios');

module.exports= async ({ url, status, transactionId, walletAddress, amount, currencyType, message }) => {
  if (!url) {
    return;
  }

  try {
    const response = await axios.post(
      url,
      {
        success: status === 'confirmed',
        status,
        message,
        data: {
          transactionId,
          walletAddress,
          amount,
          currencyType,
        },
      },
      {
        timeout: 8000, // 8 seconds timeout
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

  } catch (error) {
    console.error(`❌ Callback failed to ${url}`);

    if (error.response) {
      console.error('Response Data:', error.response.data);
    } else if (error.request) {
      console.error('No response received:', error.request);
    } else {
      console.error('Error Message:', error.message);
    }
  }
};
