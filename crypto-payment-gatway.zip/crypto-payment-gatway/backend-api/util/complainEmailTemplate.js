module.exports.generateComplainUpdateEmail = function ({
  name,
  email,
  complainId,
  status,
  adminNotes,
  resolvedAt,
  submittedAt,
  transactionId
}) {
  return `
  <div style="font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;">
    <div style="background-color: #007bff; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;">
      <h2 style="margin: 0;">📬 Complaint Status Updated</h2>
    </div>

    <div style="padding: 20px; border: 1px solid #dee2e6; border-top: none; border-radius: 0 0 5px 5px;">
      <p>Dear <strong>${name}</strong>,</p>

      <p>Your complaint with ID <code style="background-color: #e9ecef; padding: 2px 6px; border-radius: 3px;">${complainId}</code> regarding transaction <code style="background-color: #e9ecef; padding: 2px 6px; border-radius: 3px;">${transactionId}</code> has been updated.</p>

      <h3>📝 Complaint Details</h3>
      <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px;">
        <ul style="padding-left: 20px; margin: 0;">
          <li><strong>Status:</strong> ${status.toUpperCase()}</li>
          <li><strong>Submitted At:</strong> ${new Date(submittedAt).toLocaleString()}</li>
          ${resolvedAt ? `<li><strong>Resolved At:</strong> ${new Date(resolvedAt).toLocaleString()}</li>` : ''}
        </ul>
      </div>

      ${
        adminNotes
          ? `
        <h3>📌 Admin Notes</h3>
        <div style="background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; border-radius: 5px;">
          <p style="margin: 0; color: #856404;">${adminNotes}</p>
        </div>`
          : ''
      }

      ${
        status === 'resolved'
          ? `<p style="color: #28a745;"><strong>✅ Your issue has been marked as resolved.</strong></p>`
          : status === 'rejected'
          ? `<p style="color: #dc3545;"><strong>❌ Your complaint was rejected. Please review admin notes for explanation.</strong></p>`
          : `<p style="color: #ffc107;"><strong>⏳ Your complaint is still under review.</strong></p>`
      }

      <div style="margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid #dee2e6;">
        <p style="color: #6c757d;">Need further assistance? Please reply to this email or contact our support team.</p>
        <p style="margin: 0;"><strong>Secure Crypto Gateway Team</strong></p>
      </div>
    </div>
  </div>
  `;
};
