module.exports.getTransactionMessage = function (status) {
  switch (status) {
    case 'success': return 'Transaction confirmed successfully';
    case 'failed': return 'Transaction failed during confirmation';
    case 'expired': return 'Transaction expired';
    case 'api_failed': return 'Blockchain API failed during confirmation';
    case 'pending': return 'Transaction is being processed';
    default: return 'Unknown transaction status';
  }
};
