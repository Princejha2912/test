const axios = require('axios');
const logger = require('../logger/logger');
const WalletCounter = require('../models/walletCounter');

class BlockchainService {
  constructor() {
    // Blockchain API configuration
    this.erc20ApiUrl = process.env.ERC20_API_URL || 'http://localhost:3030';
    this.trc20ApiUrl = process.env.TRC20_API_URL || 'http://localhost:3002';
    this.mnemonic = process.env.BLOCKCHAIN_MNEMONIC;
    this.mnemonicTRC20 = process.env.BLOCKCHAIN_MNEMONIC_TRC20;

    // Initialize database counters on startup
    this.initializeCounters();
  }

  /**
   * Initialize wallet counters in database
   */
  async initializeCounters() {
    try {
      await WalletCounter.initializeCounters();
      logger.info('Wallet counters initialized successfully');
    } catch (error) {
      logger.error(`Failed to initialize wallet counters: ${error.message}`);
    }
  }

  /**
   * Reset wallet counters to start from 1
   */
  async resetCountersToOne() {
    try {
      await WalletCounter.resetCount('ERC20', 1); // Reset to 1, first wallet will have count 1
      await WalletCounter.resetCount('TRC20', 1);
      logger.info('Wallet counters reset to start from 1');
    } catch (error) {
      logger.error(`Failed to reset wallet counters: ${error.message}`);
    }
  }

  /**
   * Generate unique count value from database for wallet generation
   * @param {string} network - Network type (ERC20 or TRC20)
   * @returns {Promise<number>} Unique count value from database
   */
  async generateUniqueCount(network) {
    try {
      const uniqueCount = await WalletCounter.getNextCount(network);
      logger.info(`Generated unique count for ${network}: ${uniqueCount}`);
      return uniqueCount;
    } catch (error) {
      logger.error(`Failed to generate unique count for ${network}: ${error.message}`);
   
    }
  }

  /**
   * Generate ERC20 (Ethereum) wallet address
   * @param {number} count - Unique count value for address generation (optional)
   * @returns {Promise<Object>} Generated wallet data
   */
  async generateERC20Address(count = null) {
    try {
      // Use unique count from database if not provided
      const uniqueCount = count || await this.generateUniqueCount('ERC20');
      logger.info(`Generating ERC20 address with database count: ${uniqueCount}`);

      const response = await axios.get(`${this.erc20ApiUrl}/erc20/generateAddress`, {
        params: {
          mnemonic: this.mnemonic,
          count: uniqueCount
        },
        headers: {
          'accept': 'application/json'
        },
        timeout: 10000
      });

      // Handle your API response format
      if (response.data && response.data.responseCode === 200 && response.data.responseResult) {
        const result = response.data.responseResult;
        logger.info(`Successfully generated ERC20 address: ${result.address}`);

        return {
          success: true,
          addresses: [{
            address: result.address,
            privateKey: result.privateKey,
            index: uniqueCount
          }],
          network: 'ERC20',
          data: response.data,
          count: uniqueCount
        };
      } else {
        throw new Error(`ERC20 API error: ${response.data?.responseMessage || 'Invalid response format'}`);
      }

    } catch (error) {
      logger.error(`ERC20 address generation failed: ${error.message}`);
      
      // Fallback to dummy address if API fails
      // const fallbackAddress = `0x${require('crypto').randomBytes(20).toString('hex')}`;
      logger.warn(`Using fallback ERC20 address: ${fallbackAddress}`);
      
      return {
        success: false,
        network: 'ERC20',
        fallback: true,
        error: error.message
      };
    }
  }

  /**
   * Generate TRC20 (TRON) wallet address
   * @param {number} count - Unique count value for address generation (optional)
   * @returns {Promise<Object>} Generated wallet data
   */
  async generateTRC20Address(count = null) {
    try {
      // Use unique count from database if not provided
      const uniqueCount = count || await this.generateUniqueCount('TRC20');

      logger.info(`Generating TRC20 address with database count: ${uniqueCount}`);

      // If you have a TRC20 API endpoint, use it here
      const response = await axios.get(`${this.trc20ApiUrl}/trx/generateTronWallet`, {
        params: {
          mnemonic: this.mnemonicTRC20,
          count: uniqueCount
        },
        headers: {
          'accept': 'application/json'
        },
        timeout: 10000
      });

      // Handle TRC20 API response (similar format expected)
      if (response.data && response.data.responseCode === 200 && response.data.responseResult) {
        const result = response.data.responseResult;
        logger.info(`Successfully generated TRC20 address: ${result.address}`);

        return {
          success: true,
          addresses: [{
            address: response.data.responseResult.totalwallet[0].address,
            privateKey: response.data.responseResult.totalwallet[0].privateKey,
          }],
          network: 'TRC20',
          data: response.data,
          count: uniqueCount
        };
      } else {
        throw new Error(`TRC20 API error: ${response.data?.responseMessage || 'Invalid response format'}`);
      }

    } catch (error) {
      logger.error(`TRC20 address generation failed: ${error.message}`);

     

      return {
        success: false,
        addresses: [{
          address: fallbackAddress,
          privateKey: null,
          index: uniqueCount
        }],
        network: 'TRC20',
        fallback: true,
        error: error.message,
        count: uniqueCount
      };
    }
  }

  /**
   * Generate wallet address based on currency type
   * @param {string} currencyType - USDT-ERC20 or USDT-TRC20
   * @param {number} count - Unique count value for address generation (optional)
   * @returns {Promise<Object>} Generated wallet data
   */
  async generateWalletAddress(currencyType, count = null) {
    // Determine network type
    const network = currencyType.split('-')[1]; // ERC20 or TRC20

    // Generate unique count from database if not provided
    let uniqueCount;

    try {
      uniqueCount = count || await this.generateUniqueCount(network);
      logger.info(`Generating wallet for currency: ${currencyType} with database count: ${uniqueCount}`);

      let result;

      switch (currencyType) {
        case 'USDT-ERC20':
          result = await this.generateERC20Address(uniqueCount);
          break;

        case 'USDT-TRC20':
          result = await this.generateTRC20Address(uniqueCount);
          break;

        default:
          throw new Error(`Unsupported currency type: ${currencyType}`);
      }
      // Return the first address for single address generation
      if (result.addresses && result.addresses.length > 0) {
        return {
          success: result.success,
          walletAddress: result.addresses[0].address,
          privateKey: result.addresses[0].privateKey,
          network: result.network,
          fallback: result.fallback || false,
          error: result.error || null,
          count: result.count || uniqueCount,
          index: result.addresses[0].index
        };
      } else {
        throw new Error('No addresses generated');
      }

    } catch (error) {
      logger.error(`Wallet generation failed: ${error.message}`)
      return {
        success: false,
        walletAddress: fallbackAddress,
        privateKey: null,
        network: currencyType.split('-')[1],
        fallback: true,
        error: error.message,
        count: uniqueCount,
        index: uniqueCount
      };
    }
  }

  /**
   * Check ERC20 token balance for a wallet address
   * @param {string} walletAddress - Wallet address to check
   * @param {string} contractAddress - ERC20 contract address (USDT contract)
   * @returns {Promise<Object>} Balance check result
   */
  async checkERC20Balance(walletAddress, contractAddress,amount) {
    try {
      logger.info(`Checking ERC20 balance for address: ${walletAddress}, contract: ${contractAddress}`);

      const response = await axios.get(`${this.erc20ApiUrl}/erc20/getBalance`, {
        params: {
          address: walletAddress,
          contract: contractAddress
        },
        headers: {
          'accept': 'application/json'
        },
        timeout: 10000
      });

      // Handle your API response format
      if (response.data && response.data.responseCode === 200 && response.data.responseResult) {
        const result = response.data.responseResult;
        const balance = parseFloat(result.balance) || 0;


        logger.info(`ERC20 balance retrieved: ${balance} for address ${walletAddress} (Raw: ${result.balance})`);

        return {
          success: true,
          balance: balance,
          rawBalance: result.balance,
          walletAddress: walletAddress,
          contractAddress: contractAddress,
          network: 'ERC20',
          responseMessage: response.data.responseMessage,
          data: response.data
        };
      } else {
        throw new Error(`ERC20 balance API error: ${response.data?.responseMessage || 'Invalid response format'}`);
      }

    } catch (error) {
      logger.error(`ERC20 balance check failed: ${error.message}`);

      return {
        success: false,
        balance: 0,
        walletAddress: walletAddress,
        contractAddress: contractAddress,
        network: 'ERC20',
        error: error.message
      };
    }
  }

  /**
   * Check TRC20 token balance for a wallet address
   * @param {string} walletAddress - Wallet address to check
   * @param {string} contractAddress - TRC20 contract address (USDT contract)
   * @returns {Promise<Object>} Balance check result
   */
  async checkTRC20Balance(walletAddress, expectedAmount,contractAddress) {
    try {
      logger.info(`Checking TRC20 balance for address: ${walletAddress}, contract: ${contractAddress}`);

      // If you have a TRC20 balance API endpoint, use it here
     const response = await axios.get(
  `${this.trc20ApiUrl}/trc20/getTrc20Balance?address=${walletAddress}&TRCcontractAddress=${contractAddress}`,
  {
    headers: {
      'accept': 'application/json'
    },
    timeout: 10000
  }
);

      // Handle TRC20 API response (same format as ERC20)
     if (response.data && response.data.status === 200) {
  const balance = parseFloat(response.data?.result) || 0;
  const actualBalance = balance;
   const confirmed = actualBalance >0;

  let message = '';
  if (actualBalance < expectedAmount) {
    message = `⚠️ Received amount (${actualBalance}) is less than expected (${expectedAmount})`;
  } else if (actualBalance > expectedAmount) {
    message = `ℹ️ Received amount (${actualBalance}) is more than expected (${expectedAmount})`;
  } else {
    message = `✅ Exact amount received (${actualBalance})`;
  }

  logger.info(`TRC20 balance retrieved: ${balance} for address ${walletAddress} (Raw: ${response.data?.result})`);

  return {
    success: true,
    actualBalance: balance,
    confirmed,
    rawBalance: response.data.result,
    walletAddress: walletAddress,
    contractAddress: contractAddress,
    network: 'TRC20',
    message,
  };
} else {
  throw new Error(`TRC20 balance API error: ${response.data || 'Invalid response format'}`);
}

    } catch (error) {
      logger.error(`TRC20 balance check failed: ${error.message}`);

      return {
        success: false,
        balance: 0,
        walletAddress: walletAddress,
        contractAddress: contractAddress,
        network: 'TRC20',
        error: error.message
      };
    }
  }

  /**
   * Verify transaction on blockchain by checking balance
   * @param {string} walletAddress - Wallet address to check
   * @param {number} expectedAmount - Expected deposit amount
   * @param {string} currencyType - Currency type (USDT-ERC20 or USDT-TRC20)
   * @returns {Promise<Object>} Transaction verification result
   */
  async verifyTransaction(walletAddress, expectedAmount, currencyType) {
    try {
      
      logger.info(`Verifying transaction: ${walletAddress}, Expected Amount: ${expectedAmount}, Currency: ${currencyType}`);

      // Get contract address based on currency type
      const contractAddresses = {
        'USDT-ERC20': process.env.USDT_ERC20_CONTRACT , // USDT on Ethereum
        'USDT-TRC20': process.env.USDT_TRC20_CONTRACT  // USDT on TRON
      };

      const contractAddress = contractAddresses[currencyType];
      if (!contractAddress) {
        throw new Error(`No contract address configured for ${currencyType}`);
      }

      let balanceResult;

      // Check balance based on currency type

      // Ensure we only call the correct API
      if (currencyType === 'USDT-ERC20') {
        balanceResult = await this.checkERC20Balance(walletAddress, contractAddress,expectedAmount);
      } else if (currencyType === 'USDT-TRC20') {
        balanceResult = await this.checkTRC20Balance(walletAddress, contractAddress,expectedAmount);
      } else {
        throw new Error(`Unsupported currency type: ${currencyType}`);
      }

      if (!balanceResult.success) {
        return {
          success: false,
          confirmed: false,
          walletAddress,
          expectedAmount,
          actualBalance: 0,
          currencyType,
          error: balanceResult.error
        };
      }

      const actualBalance = balanceResult.balance;
      const isConfirmed = actualBalance > 0;
     
      let message = '';
      if (actualBalance < expectedAmount) {
            message = `⚠️ Received amount (${actualBalance}) is less than expected (${expectedAmount})`;
      } else if (actualBalance > expectedAmount) {
           message = `ℹ️ Received amount (${actualBalance}) is more than expected (${expectedAmount})`;
      } else {
          message = `✅ Exact amount received (${actualBalance})`;
      }

      logger.info(`Balance verification: Expected ${expectedAmount}, Actual ${actualBalance} (Raw: ${balanceResult.rawBalance}), Confirmed: ${isConfirmed}`);

      return {
        success: true,
        confirmed: isConfirmed,
        walletAddress,
        expectedAmount,
        actualBalance,
        rawBalance: balanceResult.rawBalance,
        currencyType,
        contractAddress,
        network: balanceResult.network,
        responseMessage: balanceResult.responseMessage,
        balanceCheckData: balanceResult.data,
        sufficientBalance: isConfirmed,
        message
      };

    } catch (error) {
      logger.error(`Transaction verification failed: ${error.message}`);
      return {
        success: false,
        confirmed: false,
        walletAddress,
        expectedAmount,
        actualBalance: 0,
        currencyType,
        error: error.message
      };
    }
  }

  /**
   * Get network fee estimation
   * @param {string} currencyType - Currency type
   * @returns {Promise<Object>} Fee estimation
   */
  async getNetworkFee(currencyType) {
    try {
      // Placeholder for actual fee estimation
      const fees = {
        'USDT-ERC20': { slow: 10, standard: 20, fast: 50 },
        'USDT-TRC20': { slow: 1, standard: 2, fast: 5 }
      };
      
      return {
        success: true,
        fees: fees[currencyType] || fees['USDT-TRC20'],
        currency: currencyType
      };
      
    } catch (error) {
      logger.error(`Fee estimation failed: ${error.message}`);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Execute ERC20 token withdrawal
   * @param {string} privateKey - Private key of the source wallet
   * @param {string} receiverAddress - Destination wallet address
   * @param {number} amountToSend - Amount of tokens to send
   * @param {string} contractAddress - ERC20 contract address
   * @returns {Promise<Object>} Withdrawal result
   */
  async executeERC20Withdrawal(privateKey, receiverAddress, amountToSend, contractAddress) {
    try {
      logger.info(`Executing ERC20 withdrawal: ${amountToSend} tokens to ${receiverAddress}`);

      const response = await axios.post(`${this.erc20ApiUrl}/erc20/withdraw`,
        new URLSearchParams({
          privateKey: privateKey,
          recieverAddress: receiverAddress,
          amountToSend: amountToSend.toString(),
          contract: contractAddress
        }),
        {
          headers: {
            'accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          timeout: 30000 // 30 second timeout for blockchain transactions
        }
      );


      // Handle your API response format
      if (response.data && response.data.responseCode === 200 && response.data.responseResult) {
        const result = response.data.responseResult;
        logger.info(`ERC20 withdrawal successful: ${result.transactionHash || 'Transaction completed'}`);

        return {
          success: true,
          transactionHash: result.transactionHash,
          amount: amountToSend,
          receiverAddress: receiverAddress,
          contractAddress: contractAddress,
          network: 'ERC20',
          responseMessage: response.data.responseMessage,
          data: response.data
        };
      } else {
        throw new Error(`ERC20 withdrawal API error: ${response.data?.responseMessage || 'Invalid response format'}`);
      }

    } catch (error) {
      logger.error(`ERC20 withdrawal failed: ${error.message}`);

      return {
        success: false,
        amount: amountToSend,
        receiverAddress: receiverAddress,
        contractAddress: contractAddress,
        network: 'ERC20',
        error: error.message
      };
    }
  }

  /**
   * Execute TRC20 token withdrawal
   * @param {string} privateKey - Private key of the source wallet
   * @param {string} receiverAddress - Destination wallet address
   * @param {number} amountToSend - Amount of tokens to send
   * @param {string} contractAddress - TRC20 contract address
   * @returns {Promise<Object>} Withdrawal result
   */
   async executeTRC20Withdrawal(senderAddress, privateKey, receiverAddress, amountToSend, contractAddress) {
  try {
    logger.info(`Executing TRC20 withdrawal: ${amountToSend} tokens from ${senderAddress} to ${receiverAddress}`);

    const url = `${this.trc20ApiUrl}/trc20/withdrawTRC20?TRCcontractAddress=${contractAddress}`;

    const payload = new URLSearchParams({
      senderAddress: senderAddress,
      senderPrivateKey: privateKey,
      receiverAddress: receiverAddress,
      token: amountToSend.toString()
    });

    const response = await axios.post(url, payload, {
      headers: {
        'accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      timeout: 30000
    });

    if (response.data && response.data.responseCode === 200) {
      const result = response.data;
      logger.info(`✅ TRC20 withdrawal successful: ${result.transaction || result.transactionHash}`);

      return {
        success: true,
        transactionHash: result.txHash ,
        amount: amountToSend,
        senderAddress,
        receiverAddress,
        contractAddress,
        network: 'TRC20',
        responseMessage: "withdrawal in UST-TRC20 completed",
        data: response.data
      };
    } else {
      throw new Error(`TRC20 withdrawal API error: ${response.data?.responseMessage || 'Invalid response'}`);
    }

  } catch (error) {
    logger.error(`❌ TRC20 withdrawal failed: ${error.message}`);

    return {
      success: false,
      amount: amountToSend,
      senderAddress,
      receiverAddress,
      contractAddress,
      network: 'TRC20',
      error: error.message
    };
  }
}


  /**
   * Execute withdrawal based on currency type
   * @param {string} privateKey - Private key of the source wallet
   * @param {string} receiverAddress - Destination wallet address
   * @param {number} amountToSend - Amount of tokens to send
   * @param {string} currencyType - Currency type (USDT-ERC20 or USDT-TRC20)
   * @returns {Promise<Object>} Withdrawal result
   */
  async executeWithdrawal(privateKey, receiverAddress, amountToSend, currencyType) {
    try {
      // Get contract address based on currency type
      const contractAddresses = {
        'USDT-ERC20': process.env.USDT_ERC20_CONTRACT || '0xdAC17F958D2ee523a2206206994597C13D831ec7',
        'USDT-TRC20': process.env.USDT_TRC20_CONTRACT || 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'
      };

      const contractAddress = contractAddresses[currencyType];
      if (!contractAddress) {
        throw new Error(`No contract address configured for ${currencyType}`);
      }

      logger.info(`Executing withdrawal: ${amountToSend} ${currencyType} to ${receiverAddress}`);

      let result;

      // Execute withdrawal based on currency type
      switch (currencyType) {
        case 'USDT-ERC20':
          result = await this.executeERC20Withdrawal(privateKey, receiverAddress, amountToSend, contractAddress);
          break;

        case 'USDT-TRC20':
          result = await this.executeTRC20Withdrawal(privateKey, receiverAddress, amountToSend, contractAddress);
          break;

        default:
          throw new Error(`Unsupported currency type: ${currencyType}`);
      }

      return {
        ...result,
        currencyType: currencyType
      };

    } catch (error) {
      logger.error(`Withdrawal execution failed: ${error.message}`);
      return {
        success: false,
        amount: amountToSend,
        receiverAddress: receiverAddress,
        currencyType: currencyType,
        error: error.message
      };
    }
  }

  /**
   * Execute deposit transfer to admin wallet
   * @param {string} senderAddress - Wallet address that received the deposit
   * @param {string} senderPrivateKey - Private key of the wallet that received deposit
   * @param {string} receiverAddress - Admin wallet address
   * @param {number} amount - Amount to transfer to admin wallet
   * @param {string} contractAddress - USDT contract address
   * @returns {Promise<Object>} Deposit transfer result
   */

async executeDepositTransfer(senderAddress, senderPrivateKey, receiverAddress, amount, contractAddress) {
  try {
    const bodyData = {
      senderAddress,
      senderPrivateKey,
      receiverAddress,
      token: amount.toString(),
      contract: contractAddress
    };

    const response = await axios.post(
      `${this.erc20ApiUrl}/erc20/deposit`,
      bodyData, // JSON body
      {
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json'  // IMPORTANT
        },
        timeout: 1000000  // Timeout in milliseconds 
      }
    );

    const res = response.data;

    if (res && res.responseCode === 200) {
      const result = res.responseResult || {};

      return {
        success: true,
        transactionHash: result.transactionHash,
        details: res.responseResult,
        responseMessage: res.responseMessage
      };
    } else {
      console.error('❌ Transfer failed:', res.responseMessage || 'Unknown error');
      return {
        success: false,
        responseMessage: res.responseMessage,
        response: res
      };
    }

  } catch (error) {
    console.error('🚫 Axios request failed:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}




  /**
   * Execute withdrawal using admin wallet
   * @param {string} receiverAddress - Merchant's wallet address
   * @param {number} amountToSend - Amount after fee deduction
   * @param {string} currencyType - USDT-ERC20 or USDT-TRC20
   * @returns {Promise<Object>} Withdrawal result
   */
  async executeAdminWithdrawal(receiverAddress, amountToSend, currencyType) {
    try {
      const adminPrivateKey = process.env.ADMIN_WALLET_PRIVATE_KEY;
      if (!adminPrivateKey) {
        throw new Error('Admin wallet private key not configured');
      }

      // Get contract address based on currency type
      const contractAddresses = {
        'USDT-ERC20': process.env.USDT_ERC20_CONTRACT,
        'USDT-TRC20': process.env.USDT_TRC20_CONTRACT
      };

      const contractAddress = contractAddresses[currencyType];
      if (!contractAddress) {
        throw new Error(`No contract address configured for ${currencyType}`);
      }

      logger.info(`Executing admin withdrawal: ${amountToSend} ${currencyType} to ${receiverAddress}`);

      let apiUrl;
      if (currencyType === 'USDT-ERC20') {
        apiUrl = `${this.erc20ApiUrl}/erc20/withdraw`;
      } else {
        apiUrl = `${this.trc20ApiUrl}/trc20/withdraw`;
      }

      const response = await axios.post(apiUrl,
        new URLSearchParams({
          privateKey: adminPrivateKey,
          recieverAddress: receiverAddress,
          amountToSend: amountToSend.toString(),
          contract: contractAddress
        }),
        {
          headers: {
            'accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      // Handle API response with detailed blockchain data
      if (response.data && response.data.responseCode === 200) {
        const result = response.data.responseResult || {};
        logger.info(`Withdrawal successful: ${amountToSend} ${currencyType} sent to ${receiverAddress}. TX: ${result.transactionHash}`);

        return {
          success: true,
          transactionHash: result.transactionHash,
          blockHash: result.blockHash,
          blockNumber: result.blockNumber,
          gasUsed: result.gasUsed,
          effectiveGasPrice: result.effectiveGasPrice,
          from: result.from,
          to: result.to,
          status: result.status,
          logs: result.logs,
          amount: amountToSend,
          receiverAddress: receiverAddress,
          currencyType: currencyType,
          contractAddress: contractAddress,
          responseMessage: response.data.responseMessage,
          blockchainDetails: result,
          data: response.data
        };
      } else if (response.data && response.data.responseCode === 501) {
        // Handle API failure response
        logger.error(`Withdrawal API failed: ${response.data.responseMessage}`);
        throw new Error(`Withdrawal failed: ${response.data.responseMessage}`);
      } else {
        throw new Error(`Withdrawal API error: ${response.data?.responseMessage || 'Invalid response format'}`);
      }

    } catch (error) {
      logger.error(`Admin withdrawal failed: ${error.message}`);

      return {
        success: false,
        amount: amountToSend,
        receiverAddress: receiverAddress,
        currencyType: currencyType,
        error: error.message
      };
    }
  }
  async executeDepositTransferTRC20(senderAddress, senderPrivateKey, receiverAddress, amount, contractAddress) {
  try {
      // Transfer tokens from user to receiver
            // const result2 = await tokenTransferUserToUser(
            //     req.body.receiverAddress,
            //     req.body.token,
            //     req.body.senderPrivateKey,
            //     req.body.contract,
            //     req.body.TRCcontractAddress
            // );
             
    const bodyData = {
      senderAddress:senderAddress,
      senderPrivateKey:senderPrivateKey,
      receiverAddress:receiverAddress,
      token: amount.toString(),
      contract: contractAddress
    };

    const response = await axios.post(
      `${this.trc20ApiUrl}/trc20/depositTrc20`,
      bodyData, // JSON body
      {
        headers: {
          'accept': 'application/json',
          'Content-Type': 'application/json'  // IMPORTANT
        },
        timeout: 60000
      }
    );

    const res = response.data;

    if (res && res.responseCode === 200) {
      const result = res.success || {};

      return {
        success: true,
        transactionHash: res.responseResult.txHash,
        details: res.data,
        responseMessage: res.responseMessage
      };
    } else {
      console.error('❌ Transfer failed:', res.message || 'Unknown error');
      return {
        success: false,
        responseMessage: res.responseMessage,
        response: res
      };
    }

  } catch (error) {
    console.error('🚫 Axios request failed:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}


  /**
   * Get wallet counter statistics
   * @returns {Promise<Object>} Counter statistics for all networks
   */
  async getCounterStatistics() {
    try {
      const erc20Count = await WalletCounter.getCurrentCount('ERC20');
      const trc20Count = await WalletCounter.getCurrentCount('TRC20');

      return {
        success: true,
        statistics: {
          ERC20: {
            currentCount: erc20Count,
            network: 'ERC20'
          },
          TRC20: {
            currentCount: trc20Count,
            network: 'TRC20'
          }
        }
      };
    } catch (error) {
      logger.error(`Failed to get counter statistics: ${error.message}`);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Reset counter for a specific network (Admin only)
   * @param {string} network - Network to reset (ERC20 or TRC20)
   * @param {number} newCount - New count value (optional, defaults to current timestamp)
   * @returns {Promise<Object>} Reset result
   */
  async resetCounter(network, newCount = null) {
    try {
      const resetValue = newCount || Date.now();
      const result = await WalletCounter.resetCount(network, resetValue);

      logger.info(`Reset ${network} counter to: ${result}`);

      return {
        success: true,
        network: network,
        newCount: result,
        resetAt: new Date()
      };
    } catch (error) {
      logger.error(`Failed to reset ${network} counter: ${error.message}`);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

module.exports = new BlockchainService();
