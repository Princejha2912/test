const SimpleStats = require('../models/simpleStats');
const logger = require('../logger/logger');

/**
 * Very Simple Statistics Service - Easy to Understand
 */
class SimpleStatsService {

  /**
   * Record a deposit (successful or failed)
   */
  static async recordDeposit(merchantId, amount, isSuccessful) {
    try {
      logger.info(`📊 Recording deposit: ${amount} USDT, Success: ${isSuccessful}`);
      
      await SimpleStats.addDeposit(merchantId, amount, isSuccessful);
      
      logger.info(`✅ Deposit recorded for merchant: ${merchantId}`);
    } catch (error) {
      logger.error(`❌ Failed to record deposit: ${error.message}`);
    }
  }

  /**
   * Record a withdrawal (approved or rejected)
   */
  static async recordWithdrawal(merchantId, amount, isApproved, fee = 0) {
    try {
      logger.info(`📊 Recording withdrawal: ${amount} USDT, Approved: ${isApproved}, Fee: ${fee}`);
      
      await SimpleStats.addWithdrawal(merchantId, amount, isApproved, fee);
      
      logger.info(`✅ Withdrawal recorded for merchant: ${merchantId}`);
    } catch (error) {
      logger.error(`❌ Failed to record withdrawal: ${error.message}`);
    }
  }

  /**
   * Get merchant statistics
   */
  static async getMerchantStats(merchantId) {
    try {
      const stats = await SimpleStats.getMerchantStats(merchantId);
      
      if (!stats) {
        return {
          totalDeposits: 0,
          successfulDeposits: 0,
          failedDeposits: 0,
          totalWithdrawals: 0,
          approvedWithdrawals: 0,
          rejectedWithdrawals: 0,
          totalDepositAmount: 0,
          totalWithdrawalAmount: 0,
          totalFees: 0,
          currentBalance: 0
        };
      }

      return stats;
    } catch (error) {
      logger.error(`❌ Failed to get merchant stats: ${error.message}`);
      return null;
    }
  }

  /**
   * Get platform statistics (all merchants combined)
   */
  static async getPlatformStats() {
    try {
      const stats = await SimpleStats.getPlatformStats();
      
      if (!stats) {
        return {
          totalDeposits: 0,
          successfulDeposits: 0,
          failedDeposits: 0,
          totalWithdrawals: 0,
          approvedWithdrawals: 0,
          rejectedWithdrawals: 0,
          totalDepositAmount: 0,
          totalWithdrawalAmount: 0,
          totalFees: 0
        };
      }

      return stats;
    } catch (error) {
      logger.error(`❌ Failed to get platform stats: ${error.message}`);
      return null;
    }
  }

  /**
   * Get all merchant statistics (for admin)
   */
  static async getAllMerchantStats() {
    try {
      const stats = await SimpleStats.getAllMerchantStats();
      return stats || [];
    } catch (error) {
      logger.error(`❌ Failed to get all merchant stats: ${error.message}`);
      return [];
    }
  }

  /**
   * Calculate simple success rates
   */
  static calculateRates(stats) {
    const depositSuccessRate = stats.totalDeposits > 0 
      ? Math.round((stats.successfulDeposits / stats.totalDeposits) * 100)
      : 0;

    const withdrawalApprovalRate = stats.totalWithdrawals > 0
      ? Math.round((stats.approvedWithdrawals / stats.totalWithdrawals) * 100)
      : 0;

    return {
      depositSuccessRate,
      withdrawalApprovalRate
    };
  }

  /**
   * Get merchant stats with rates
   */
  static async getMerchantStatsWithRates(merchantId) {
    try {
      const stats = await this.getMerchantStats(merchantId);
      const rates = this.calculateRates(stats);

      return {
        ...stats.toObject(),
        ...rates
      };
    } catch (error) {
      logger.error(`❌ Failed to get merchant stats with rates: ${error.message}`);
      return null;
    }
  }

  /**
   * Get platform stats with rates
   */
  static async getPlatformStatsWithRates() {
    try {
      const stats = await this.getPlatformStats();
      const rates = this.calculateRates(stats);

      return {
        ...stats.toObject(),
        ...rates
      };
    } catch (error) {
      logger.error(`❌ Failed to get platform stats with rates: ${error.message}`);
      return null;
    }
  }
}

module.exports = SimpleStatsService;
