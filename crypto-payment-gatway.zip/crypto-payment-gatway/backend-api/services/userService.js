const User = require('../models/user');
const crypto = require('crypto');
const logger = require('../logger/logger');

class UserService {
  constructor() {
    logger.info('👤 User Service initialized');
  }

  /**
   * Create a new client/merchant
   * @param {Object} userData - User data
   * @returns {Object} Created user
   */
  async createClient(userData) {
    try {
      const { name, email, password, walletAddress } = userData;

      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        throw new Error('User with this email already exists');
      }

      // Generate API credentials
      const apiKey = this.generateApiKey();
      const apiSecret = this.generateApiSecret();

      // Create user
      const user = new User({
        name,
        email,
        password,
        tempPassword: password,
        role: 'merchant',
        approved: 'pending',
        apiKey,
        apiSecret,
        walletAddress,
        totalAmt: 0
      });

      await user.save();

      logger.info(`✅ Client created: ${email} with API key: ${apiKey}`);

      return {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        approved: user.approved,
        apiKey: user.apiKey,
        apiSecret: user.apiSecret,
        walletAddress: user.walletAddress,
        totalAmt: user.totalAmt,
        createdAt: user.createdAt
      };
    } catch (error) {
      logger.error(`❌ Error creating client: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get user by ID
   * @param {string} userId - User ID
   * @returns {Object} User data
   */
  async getUserById(userId) {
    try {
      const user = await User.findById(userId).select('-password -tempPassword');
      if (!user) {
        throw new Error('User not found');
      }

      return user;
    } catch (error) {
      logger.error(`❌ Error getting user by ID: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get user by email
   * @param {string} email - User email
   * @returns {Object} User data
   */
  async getUserByEmail(email) {
    try {
      const user = await User.findOne({ email });
      if (!user) {
        throw new Error('User not found');
      }

      return user;
    } catch (error) {
      logger.error(`❌ Error getting user by email: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get user by API key
   * @param {string} apiKey - API key
   * @returns {Object} User data
   */
  async getUserByApiKey(apiKey) {
    try {
      const user = await User.findOne({ apiKey }).select('-password -tempPassword');
      if (!user) {
        throw new Error('Invalid API key');
      }

      return user;
    } catch (error) {
      logger.error(`❌ Error getting user by API key: ${error.message}`);
      throw error;
    }
  }

  /**
   * Approve client
   * @param {string} userId - User ID
   * @param {string} adminId - Admin ID
   * @returns {Object} Updated user
   */
  async approveClient(userId, adminId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      if (user.role !== 'merchant') {
        throw new Error('Only merchants can be approved');
      }

      user.approved = 'approved';
      await user.save();

      logger.info(`✅ Client approved: ${user.email} by admin ${adminId}`);

      return {
        id: user._id,
        name: user.name,
        email: user.email,
        approved: user.approved
      };
    } catch (error) {
      logger.error(`❌ Error approving client: ${error.message}`);
      throw error;
    }
  }

  /**
   * Block client
   * @param {string} userId - User ID
   * @param {string} adminId - Admin ID
   * @returns {Object} Updated user
   */
  async blockClient(userId, adminId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      if (user.role !== 'merchant') {
        throw new Error('Only merchants can be blocked');
      }

      user.approved = 'block';
      await user.save();

      logger.info(`🚫 Client blocked: ${user.email} by admin ${adminId}`);

      return {
        id: user._id,
        name: user.name,
        email: user.email,
        approved: user.approved
      };
    } catch (error) {
      logger.error(`❌ Error blocking client: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get all clients with pagination
   * @param {Object} options - Query options
   * @returns {Object} Clients list
   */
  async getAllClients(options = {}) {
    try {
      const { page = 1, limit = 20, approved, search } = options;
      const skip = (page - 1) * limit;

      // Build query
      const query = { role: 'merchant' };
      if (approved) query.approved = approved;
      if (search) {
        query.$or = [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } }
        ];
      }

      // Get clients
      const clients = await User.find(query)
        .select('-password -tempPassword -apiSecret')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean();

      const total = await User.countDocuments(query);

      return {
        clients,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalRecords: total,
          limit: parseInt(limit)
        }
      };
    } catch (error) {
      logger.error(`❌ Error getting all clients: ${error.message}`);
      throw error;
    }
  }

  /**
   * Update client balance
   * @param {string} clientId - Client ID
   * @param {number} amount - Amount to add/subtract
   * @returns {Object} Updated balance
   */
  async updateClientBalance(clientId, amount) {
    try {
      const user = await User.findByIdAndUpdate(
        clientId,
        { $inc: { totalAmt: amount } },
        { new: true }
      ).select('totalAmt');

      if (!user) {
        throw new Error('Client not found');
      }

      logger.info(`💰 Client balance updated: ${clientId}, change: ${amount}, new balance: ${user.totalAmt}`);

      return {
        clientId,
        newBalance: user.totalAmt,
        change: amount
      };
    } catch (error) {
      logger.error(`❌ Error updating client balance: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get client balance
   * @param {string} clientId - Client ID
   * @returns {Object} Balance info
   */
  async getClientBalance(clientId) {
    try {
      const user = await User.findById(clientId).select('totalAmt name email');
      if (!user) {
        throw new Error('Client not found');
      }

      return {
        clientId,
        name: user.name,
        email: user.email,
        balance: user.totalAmt,
        currency: 'USDT-TRC20'
      };
    } catch (error) {
      logger.error(`❌ Error getting client balance: ${error.message}`);
      throw error;
    }
  }

  /**
   * Update client profile
   * @param {string} clientId - Client ID
   * @param {Object} updateData - Data to update
   * @returns {Object} Updated user
   */
  async updateClientProfile(clientId, updateData) {
    try {
      const allowedFields = ['name', 'walletAddress'];
      const updateFields = {};

      // Only allow specific fields to be updated
      allowedFields.forEach(field => {
        if (updateData[field] !== undefined) {
          updateFields[field] = updateData[field];
        }
      });

      const user = await User.findByIdAndUpdate(
        clientId,
        updateFields,
        { new: true }
      ).select('-password -tempPassword -apiSecret');

      if (!user) {
        throw new Error('Client not found');
      }

      logger.info(`✅ Client profile updated: ${clientId}`);

      return user;
    } catch (error) {
      logger.error(`❌ Error updating client profile: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate API key
   * @returns {string} API key
   */
  generateApiKey() {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(8).toString('hex');
    return `mk_${timestamp}_${random}`;
  }

  /**
   * Generate API secret
   * @returns {string} API secret
   */
  generateApiSecret() {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Validate API credentials
   * @param {string} apiKey - API key
   * @param {string} apiSecret - API secret
   * @returns {Object} User data if valid
   */
  async validateApiCredentials(apiKey, apiSecret) {
    try {
      const user = await User.findOne({ apiKey, apiSecret });
      if (!user) {
        throw new Error('Invalid API credentials');
      }

      if (user.approved !== 'approved') {
        throw new Error('Client account not approved');
      }

      return user;
    } catch (error) {
      logger.error(`❌ Error validating API credentials: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get platform statistics
   * @returns {Object} Platform stats
   */
  async getPlatformStats() {
    try {
      const stats = await User.aggregate([
        { $match: { role: 'merchant' } },
        {
          $group: {
            _id: '$approved',
            count: { $sum: 1 },
            totalBalance: { $sum: '$totalAmt' }
          }
        }
      ]);

      const result = {
        totalClients: 0,
        approvedClients: 0,
        pendingClients: 0,
        blockedClients: 0,
        totalPlatformBalance: 0
      };

      stats.forEach(stat => {
        result.totalClients += stat.count;
        result.totalPlatformBalance += stat.totalBalance;

        switch (stat._id) {
          case 'approved':
            result.approvedClients = stat.count;
            break;
          case 'pending':
            result.pendingClients = stat.count;
            break;
          case 'block':
            result.blockedClients = stat.count;
            break;
        }
      });

      return result;
    } catch (error) {
      logger.error(`❌ Error getting platform stats: ${error.message}`);
      throw error;
    }
  }
}

module.exports = new UserService();
