// app.js
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const cookieParser = require('cookie-parser');
const connectDB = require('./config/db');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./config/swaggerConfig');
const customCors = require('./middleware/corsMiddleware.js');

const authRoutes = require('./routes/authRoute.js');
const adminRoutes = require('./routes/adminRoute.js');
const merchantRoute = require('./routes/merchantRoute.js');
const widthdrawalRoute = require('./routes/widthdrawalRoute.js');
const transactionRoute = require('./routes/transaction.js');
const feeRoutes = require('./routes/feeRoute.js');
const notificationRoutes = require('./routes/notificationRoute.js');
const statisticsRoutes = require('./routes/simpleStatsRoute.js');
const testNotificationRoutes = require('./routes/testNotificationRoute.js');
const walletCounterRoutes = require('./routes/walletCounterRoute.js');
const adminTransactionRoutes = require('./routes/adminTransactionRoute.js');
const dashboardRoutes = require('./routes/dashboardRoute.js');
const Refundroutes = require('./routes/refundRoute.js')
const app = express();


// Security & optimization
app.use(helmet());
app.use(compression());
app.use(morgan('dev'));

app.use(cookieParser());
app.use(express.json());

// DB
connectDB();

// Cors middleware to handle cors errors 
app.use(customCors);

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));
app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    `script-src 'self' 'unsafe-inline';`
  );
  next();
});




// Rate Limiter
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests. Try again later.'
});
app.use(limiter);

// Swagger setup
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  swaggerOptions: {
    persistAuthorization: true,
    withCredentials: true
  },
  customSiteTitle: "Crypto Payment Gateway API Documentation"
}));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api-docs.json', (req, res) => res.json(swaggerSpec));

// Healthcheck
app.get('/api/v1/health', (req, res) => {
  res.json({
    success: true,
    message: 'Crypto Payment Gateway API is running',
    timestamp: new Date().toISOString()
  });
});

// Routes


app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/admin', adminRoutes);
app.use('/api/v1/fee', feeRoutes);
app.use('/api/v1/merchant', merchantRoute);
app.use('/api/v1/refund', Refundroutes);
app.use('/api/v1/transaction', transactionRoute);
app.use('/api/v1/withdrawal', widthdrawalRoute);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/statistics', statisticsRoutes);
app.use('/api/v1/test-notifications', testNotificationRoutes);
app.use('/api/v1/wallet-counter', walletCounterRoutes);
app.use('/api/v1/admin/transactions', adminTransactionRoutes);
app.use('/api/v1/dashboard', dashboardRoutes);

app.get('/', (req, res) => {
  res.send('Welcome to the Crypto Payment Gateway API');
});

module.exports ={ app};
