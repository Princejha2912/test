const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 50 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6 },
  tempPassword: { type: String },

  // Enhanced merchant registration fields
  country: { type: String, trim: true },
  phoneNo: { type: String, trim: true },
  companyName: { type: String, trim: true },
  licenceNo: { type: String, trim: true }, // Optional

  // OTP fields
  otp: { type: String },
  otpExpires: { type: Date },

  feeAmt: 
   { type: Number, default: 0 }
  ,
  approved: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'block'],
    default: 'pending',
  },

  role: {
    type: String,
    enum: ['merchant', 'user', 'admin', 'superadmin'],
    default: 'user',
  },

  apiKey: { type: String },       // For merchant API auth
  apiSecret: { type: String },    // Store securely or hash
  walletAddress: { type: String }, // For fund releases
  walletSecret: { type: String },
  walletPrivateKey: { type: String }, // Merchant wallet private key
  walletNetwork: { type: String },    // ERC20, TRC20, etc.
  walletGeneratedAt: { type: Date },  // When wallet was generated
  totalAmt: { type: Number, default: 0 },
   pendingAmt: { type: Number, default: 0 },
  resetPasswordToken: { type: String },
  resetPasswordExpires: { type: Date },
}, { timestamps: true });

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Generate OTP
userSchema.methods.generateOTP = function() {
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  this.otp = otp;
  this.otpExpires = Date.now() + 10 * 60 * 1000; // 10 minutes
  return otp;
};

// Verify OTP
userSchema.methods.verifyOTP = function(enteredOTP) {
  if (!this.otp || !this.otpExpires) {
    return false;
  }

  if (Date.now() > this.otpExpires) {
    return false; // OTP expired
  }

  return this.otp === enteredOTP;
};

// Clear OTP
userSchema.methods.clearOTP = function() {
  this.otp = undefined;
  this.otpExpires = undefined;
};

module.exports = mongoose.model('User', userSchema);
