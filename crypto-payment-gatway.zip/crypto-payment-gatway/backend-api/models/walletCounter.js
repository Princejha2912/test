const mongoose = require('mongoose');

const walletCounterSchema = new mongoose.Schema({
  network: {
    type: String,
    required: true,
    enum: ['ERC20', 'TRC20'],
    unique: true
  },
  currentCount: {
    type: Number,
    required: true,
    default: 0
  },
  lastUsedAt: {
    type: Date,
    default: Date.now
  }
}, { 
  timestamps: true 
});

// Index for faster queries
walletCounterSchema.index({ network: 1 });

// Static method to get next count for a network
walletCounterSchema.statics.getNextCount = async function(network) {
  try {
    // First check if counter exists
    let counter = await this.findOne({ network: network });

    if (!counter) {
      // If counter doesn't exist, create it with count 1
      counter = await this.create({
        network: network,
        currentCount: 1,
        lastUsedAt: new Date()
      });
      return 1; // First wallet gets count 1
    } else {
      // If counter exists, increment and return new value
      const result = await this.findOneAndUpdate(
        { network: network },
        {
          $inc: { currentCount: 1 },
          $set: { lastUsedAt: new Date() }
        },
        {
          new: true, // Return updated document
          runValidators: true
        }
      );

      return result.currentCount;
    }
  } catch (error) {
    throw new Error(`Failed to get next count for ${network}: ${error.message}`);
  }
};

// Static method to get current count without incrementing
walletCounterSchema.statics.getCurrentCount = async function(network) {
  try {
    const counter = await this.findOne({ network: network });
    return counter ? counter.currentCount : 0;
  } catch (error) {
    throw new Error(`Failed to get current count for ${network}: ${error.message}`);
  }
};

// Static method to reset count for a network (admin use)
walletCounterSchema.statics.resetCount = async function(network, newCount = 1) {
  try {
    const result = await this.findOneAndUpdate(
      { network: network },
      { 
        currentCount: newCount,
        lastUsedAt: new Date()
      },
      { 
        new: true,
        upsert: true,
        runValidators: true
      }
    );
    
    return result.currentCount;
  } catch (error) {
    throw new Error(`Failed to reset count for ${network}: ${error.message}`);
  }
};

// Static method to initialize counters
walletCounterSchema.statics.initializeCounters = async function() {
  try {
    const networks = ['ERC20', 'TRC20'];

    for (const network of networks) {
      await this.findOneAndUpdate(
        { network: network },
        {
          $setOnInsert: {
            currentCount: 1, // Start from 1, first wallet will have count 1
            lastUsedAt: new Date()
          }
        },
        {
          upsert: true,
          runValidators: true
        }
      );
    }

    return true;
  } catch (error) {
    throw new Error(`Failed to initialize counters: ${error.message}`);
  }
};

module.exports = mongoose.model('WalletCounter', walletCounterSchema);
