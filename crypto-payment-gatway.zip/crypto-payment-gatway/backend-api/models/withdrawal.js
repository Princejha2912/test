const mongoose = require('mongoose');

// Simple Withdrawal Model - Only USDT-TRC20 Support
const withdrawalSchema = new mongoose.Schema({
  // Client/Merchant Info
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },

  // Amount Info
  amount: {
    type: Number,
    required: true,

  },

  fee: {
    type: Number,
    default: 0
  },

  netAmount: {
    type: Number,

  },

  // Currency - Only USDT-TRC20
  currencyType: {
    type: String,
    default: 'USDT-ERC20',
    enum: ['USDT-TRC20','USDT-ERC20']
  },

  // Client's wallet address
  clientWallet: {
    type: String,
    required: true
  },

  // Status
  status: {
    type: String,
    enum: ['pending', 'rejected', 'completed', 'failed'],
    default: 'pending',
    index: true
  },
   type: {
    type: String,
    enum: ['withdrawal', 'refund'],
    default: 'withdrawal',
  },

  // Admin Processing
  adminNotes: {
    type: String
  },

  processedAt: {
    type: Date
  },

  // Blockchain transaction data
  transactionHash: {
    type: String
  },

  blockchainData: {
    transactionHash: { type: String },
    blockHash: { type: String },
    blockNumber: { type: Number },
    gasUsed: { type: Number },
    effectiveGasPrice: { type: Number },
    from: { type: String },
    to: { type: String },
    status: { type: Boolean },
    logs: { type: Array },
    contractAddress: { type: String },
    network: { type: String },
    executedAt: { type: Date },
    error: { type: String },
    failedAt: { type: Date },
    blockchainDetails: { type: mongoose.Schema.Types.Mixed }
  },

  processedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },

  // Blockchain info (when completed)
  blockchainTxHash: {
    type: String
  },

  // Client reference (optional)
  clientReference: {
    type: String
  }

}, {
  timestamps: true,
  toJSON: { virtuals: true }
});

// Virtual: Processing time
withdrawalSchema.virtual('processingTime').get(function() {
  if (!this.processedAt) return null;
  return this.processedAt - this.createdAt;
});

// Index for performance
withdrawalSchema.index({ clientId: 1, status: 1 });
withdrawalSchema.index({ status: 1, createdAt: -1 });
module.exports = mongoose.model('Withdrawal', withdrawalSchema);
