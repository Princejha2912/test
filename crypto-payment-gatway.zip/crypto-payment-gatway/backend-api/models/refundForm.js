const mongoose = require('mongoose');

const Refunds = new mongoose.Schema({
 
   withdrawalId: {
  type: mongoose.Schema.Types.ObjectId,
    ref: 'Withdrawal'
  },
  message: {
    type: String,
    required: true
  },
  
  status: {
    type: String,
    enum: ['pending', 'rejected', 'completed', 'failed', 'resolved', 'approved by merchant'],
    default: 'pending'
  },
  submittedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false 
  },
  submittedAt: {
    type: Date,
    default: Date.now
  },
  resolvedAt: Date,
  adminNotes: String
});

module.exports = mongoose.model('Refunds', Refunds);