const cors = require('cors');

const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3004',
  'http://localhost:3001',
  'http://localhost:3002',
  'http://localhost:3003',
  'http://localhost:5000',
  'https://admin.payglobal.co.in',
  'https://merchant.payglobal.co.in',
  'https://gateway.payglobal.co.in',
  'https://erc.payglobal.co.in',
  'https://trc.payglobal.co.in',
  'https://backend.payglobal.co.in'
];

const publicPaths = [
  '/api/v1/transaction/create',
  '/api/v1/refund',
];

const customCorsMiddleware = (req, res, next) => {
  const origin = req.headers.origin;
  const { path, method } = req;

  const isBrowser = !!origin;
  console.log(isBrowser)

  if (!isBrowser) {
    return next();
  }

  const isPublicPath = publicPaths.some(publicPath => path.startsWith(publicPath));

  cors({
    origin: (origin, callback) => {
      if (isPublicPath) {
        callback(null, true); 
      } else if (allowedOrigins.includes(origin)) {
        callback(null, true); 
      } else {
        callback(null, false); 
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Access-Control-Allow-Origin', 'Authorization', 'x-api-secret', 'apikey']
  })(req, res, (err) => {
    if (err || (!isPublicPath && !allowedOrigins.includes(origin))) {
      return res.status(403).json({
        success: false,
        message: 'CORS validation failed',
                errors: `Origin ${origin} is not allowed`
      });
    }
    next();
  });
};

module.exports = customCorsMiddleware;