const express = require('express');
const router = express.Router();
const { getAllTransactions, getAdminMerchantTransactions } = require('../controller/transactionController');

const { authorizeRoles, protect } = require('../middleware/routeProtector.js');
const { adminTransactionListValidation, adminMerchantTransactionValidation } = require('../validations/transactionListValidator');
const { validateRequest } = require('../middleware/validateIncomingRequest');

/**
 * @swagger
 * /admin/transactions:
 *   get:
 *     summary: Get all transactions (Admin)
 *     description: |
 *       Retrieve all transactions across all merchants with advanced filtering, pagination, and search capabilities.
 *       
 *       **Admin Only**: Requires admin or superadmin authentication.
 *       
 *       **Features**:
 *       - Pagination support
 *       - Status filtering (initiated, confirmed, failed, expired, pending, api_failed)
 *       - Currency type filtering (USDT-ERC20, USDT-TRC20)
 *       - Merchant filtering by ID or email search
 *       - Date range filtering
 *       - Sorting options
 *       - Transaction summary statistics
 *       - Merchant information included
 *     tags: [Admin - Transactions]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of transactions per page
 *         example: 10
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [initiated, confirmed, failed, expired, pending, api_failed]
 *         description: Filter by transaction status
 *         example: "confirmed"
 *       - in: query
 *         name: currencyType
 *         schema:
 *           type: string
 *           enum: [USDT-ERC20, USDT-TRC20]
 *         description: Filter by currency type
 *         example: "USDT-ERC20"
 *       - in: query
 *         name: merchantId
 *         schema:
 *           type: string
 *         description: Filter by specific merchant ID
 *         example: "64f7b1234567890abcdef123"
 *       - in: query
 *         name: merchantEmail
 *         schema:
 *           type: string
 *         description: Search merchants by email (partial match)
 *         example: "john@company.com"
 *       - in: query
 *         name: dateFrom
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter transactions from this date (YYYY-MM-DD)
 *         example: "2024-01-01"
 *       - in: query
 *         name: dateTo
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter transactions until this date (YYYY-MM-DD)
 *         example: "2024-01-31"
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, amount, status, confirmedAt]
 *           default: createdAt
 *         description: Field to sort by
 *         example: "createdAt"
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: Sort order
 *         example: "desc"
 *     responses:
 *       200:
 *         description: All transactions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "All transactions retrieved successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     transactions:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           _id:
 *                             type: string
 *                             example: "64f7b1234567890abcdef123"
 *                           transactionId:
 *                             type: string
 *                             example: "dep_1234567890_abcdef"
 *                           amount:
 *                             type: number
 *                             example: 1000
 *                           currencyType:
 *                             type: string
 *                             example: "USDT-ERC20"
 *                           status:
 *                             type: string
 *                             example: "confirmed"
 *                           walletAddress:
 *                             type: string
 *                             example: "0xbb4eaf8010acd1c981e650c515e8fe9cbc4d574b"
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:00:00.000Z"
 *                           confirmedAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:05:00.000Z"
 *                           expiresAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:10:00.000Z"
 *                           merchant:
 *                             type: object
 *                             properties:
 *                               _id:
 *                                 type: string
 *                                 example: "64f7b1234567890abcdef456"
 *                               name:
 *                                 type: string
 *                                 example: "John Doe"
 *                               email:
 *                                 type: string
 *                                 example: "john@company.com"
 *                               companyName:
 *                                 type: string
 *                                 example: "ABC Trading Company"
 *                           verificationData:
 *                             type: object
 *                             properties:
 *                               actualBalance:
 *                                 type: number
 *                                 example: 1000
 *                               expectedAmount:
 *                                 type: number
 *                                 example: 1000
 *                               network:
 *                                 type: string
 *                                 example: "ERC20"
 *                               verifiedAt:
 *                                 type: string
 *                                 format: date-time
 *                                 example: "2024-01-01T10:05:00.000Z"
 *                               failureReason:
 *                                 type: string
 *                                 example: "Insufficient balance"
 *                           adminTransferData:
 *                             type: object
 *                             properties:
 *                               success:
 *                                 type: boolean
 *                                 example: true
 *                               transactionHash:
 *                                 type: string
 *                                 example: "0x1234567890abcdef..."
 *                               transferredAmount:
 *                                 type: number
 *                                 example: 1000
 *                               transferredAt:
 *                                 type: string
 *                                 format: date-time
 *                                 example: "2024-01-01T10:06:00.000Z"
 *                     pagination:
 *                       type: object
 *                       properties:
 *                         currentPage:
 *                           type: integer
 *                           example: 1
 *                         totalPages:
 *                           type: integer
 *                           example: 15
 *                         totalTransactions:
 *                           type: integer
 *                           example: 147
 *                         limit:
 *                           type: integer
 *                           example: 10
 *                         hasNextPage:
 *                           type: boolean
 *                           example: true
 *                         hasPrevPage:
 *                           type: boolean
 *                           example: false
 *                     summary:
 *                       type: object
 *                       properties:
 *                         confirmed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 85
 *                             totalAmount:
 *                               type: number
 *                               example: 125000
 *                         failed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 15
 *                             totalAmount:
 *                               type: number
 *                               example: 8500
 *                     filters:
 *                       type: object
 *                       properties:
 *                         status:
 *                           type: string
 *                           example: "confirmed"
 *                         currencyType:
 *                           type: string
 *                           example: "USDT-ERC20"
 *                         merchantId:
 *                           type: string
 *                           example: "64f7b1234567890abcdef123"
 *                         merchantEmail:
 *                           type: string
 *                           example: "john@company.com"
 *                         sortBy:
 *                           type: string
 *                           example: "createdAt"
 *                         sortOrder:
 *                           type: string
 *                           example: "desc"
 *                         dateFrom:
 *                           type: string
 *                           example: "2024-01-01"
 *                         dateTo:
 *                           type: string
 *                           example: "2024-01-31"
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get('/', protect, authorizeRoles('admin', 'superadmin'), adminTransactionListValidation, validateRequest, getAllTransactions);

/**
 * @swagger
 * /admin/transactions/merchant/{merchantId}:
 *   get:
 *     summary: Get transactions for specific merchant (Admin)
 *     description: |
 *       Retrieve all transactions for a specific merchant with filtering and pagination.
 *
 *       **Admin Only**: Requires admin or superadmin authentication.
 *
 *       **Features**:
 *       - Merchant information included
 *       - Pagination support
 *       - Status filtering
 *       - Currency type filtering
 *       - Date range filtering
 *       - Sorting options
 *       - Transaction summary statistics for the merchant
 *     tags: [Admin - Transactions]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant ID (MongoDB ObjectId)
 *         example: "64f7b1234567890abcdef123"
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of transactions per page
 *         example: 10
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [initiated, confirmed, failed, expired, pending, api_failed]
 *         description: Filter by transaction status
 *         example: "confirmed"
 *       - in: query
 *         name: currencyType
 *         schema:
 *           type: string
 *           enum: [USDT-ERC20, USDT-TRC20]
 *         description: Filter by currency type
 *         example: "USDT-ERC20"
 *       - in: query
 *         name: dateFrom
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter transactions from this date (YYYY-MM-DD)
 *         example: "2024-01-01"
 *       - in: query
 *         name: dateTo
 *         schema:
 *           type: string
 *           format: date
 *         description: Filter transactions until this date (YYYY-MM-DD)
 *         example: "2024-01-31"
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, amount, status, confirmedAt]
 *           default: createdAt
 *         description: Field to sort by
 *         example: "createdAt"
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: Sort order
 *         example: "desc"
 *     responses:
 *       200:
 *         description: Merchant transactions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Transactions for merchant John Doe retrieved successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     merchant:
 *                       type: object
 *                       properties:
 *                         _id:
 *                           type: string
 *                           example: "64f7b1234567890abcdef123"
 *                         name:
 *                           type: string
 *                           example: "John Doe"
 *                         email:
 *                           type: string
 *                           example: "john@company.com"
 *                         companyName:
 *                           type: string
 *                           example: "ABC Trading Company"
 *                         totalAmt:
 *                           type: number
 *                           example: 25000
 *                     transactions:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           _id:
 *                             type: string
 *                             example: "64f7b1234567890abcdef456"
 *                           transactionId:
 *                             type: string
 *                             example: "dep_1234567890_abcdef"
 *                           amount:
 *                             type: number
 *                             example: 1000
 *                           currencyType:
 *                             type: string
 *                             example: "USDT-ERC20"
 *                           status:
 *                             type: string
 *                             example: "confirmed"
 *                           walletAddress:
 *                             type: string
 *                             example: "0xbb4eaf8010acd1c981e650c515e8fe9cbc4d574b"
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:00:00.000Z"
 *                           confirmedAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:05:00.000Z"
 *                     pagination:
 *                       type: object
 *                       properties:
 *                         currentPage:
 *                           type: integer
 *                           example: 1
 *                         totalPages:
 *                           type: integer
 *                           example: 3
 *                         totalTransactions:
 *                           type: integer
 *                           example: 27
 *                         limit:
 *                           type: integer
 *                           example: 10
 *                         hasNextPage:
 *                           type: boolean
 *                           example: true
 *                         hasPrevPage:
 *                           type: boolean
 *                           example: false
 *                     summary:
 *                       type: object
 *                       properties:
 *                         confirmed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 20
 *                             totalAmount:
 *                               type: number
 *                               example: 25000
 *                         failed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 3
 *                             totalAmount:
 *                               type: number
 *                               example: 1500
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Merchant not found
 *       500:
 *         description: Internal server error
 */
router.get('/merchant/:merchantId', protect, authorizeRoles('admin', 'superadmin'), adminMerchantTransactionValidation, validateRequest, getAdminMerchantTransactions);

module.exports = router;
