const express = require('express');
const router = express.Router();

const {
  registerValidation,
  loginValidation,
  changePasswordValidation,
  logoutValidation,
  validateForgot,
  validateReset
} = require('../validations/authValidation.js');
const { validateRequest } = require('../middleware/validateIncomingRequest.js');
const {
  register,
  login,
  logout,
  changePassword,
  forgotPassword,
  resetPassword
} = require('../controller/authController.js');
const { protect ,authorizeRoles } = require('../middleware/routeProtector.js')

/**
 * @swagger
 * components:
 *   schemas:
 *     RegisterRequest:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - password
 *         - confirmPassword
 *       properties:
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "John Doe"
 *           description: Full name of the merchant
 *         email:
 *           type: string
 *           format: email
 *           example: "merchant@example.com"
 *           description: Valid email address
 *         password:
 *           type: string
 *           minLength: 8
 *           example: "securePassword123"
 *           description: Strong password (min 8 characters)
 *         confirmPassword:
 *           type: string
 *           minLength: 8
 *           example: "securePassword123"
 *           description: Password confirmation (must match password)
 *         country:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           example: "United States"
 *           description: Country of operation
 *         phoneNo:
 *           type: string
 *           example: "+1234567890"
 *           description: Valid phone number
 *         companyName:
 *           type: string
 *           minLength: 2
 *           maxLength: 100
 *           example: "ABC Trading Company"
 *           description: Company or business name
 *         licenceNo:
 *           type: string
 *           maxLength: 50
 *           example: "LIC123456789"
 *           description: Business license number (optional)
 *
 *     LoginRequest:
 *       type: object
 *       required:
 *         - email
 *         - password
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           example: "merchant@example.com"
 *           description: Registered email address
 *         password:
 *           type: string
 *           example: "securePassword123"
 *           description: Account password
 *         otp:
 *           type: string
 *           pattern: '^[0-9]{6}$'
 *           example: "123456"
 *           description: 6-digit OTP (required for second step of login)
 *
 *     LoginResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Logged in successfully"
 *         error:
 *           type: string
 *           nullable: true
 *           example: null
 *         data:
 *           type: object
 *           properties:
 *             user:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                   example: "60d5ecb74b24a1234567890a"
 *                 name:
 *                   type: string
 *                   example: "John Doe"
 *                 email:
 *                   type: string
 *                   example: "merchant@example.com"
 *                 role:
 *                   type: string
 *                   enum: [merchant, admin, superadmin]
 *                   example: "merchant"
 *                 approved:
 *                   type: string
 *                   enum: [pending, approved, block]
 *                   example: "approved"
 *
 *     ChangePasswordRequest:
 *       type: object
 *       required:
 *         - currentPassword
 *         - newPassword
 *       properties:
 *         currentPassword:
 *           type: string
 *           example: "oldPassword123"
 *           description: Current account password
 *         newPassword:
 *           type: string
 *           minLength: 6
 *           example: "newSecurePassword456"
 *           description: New password (min 6 characters)
 *
 *     ForgotPasswordRequest:
 *       type: object
 *       required:
 *         - email
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           example: "merchant@example.com"
 *           description: Registered email address
 *
 *     ResetPasswordRequest:
 *       type: object
 *       required:
 *         - password
 *       properties:
 *         password:
 *           type: string
 *           minLength: 6
 *           example: "newPassword123"
 *           description: New password (min 6 characters)
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register new merchant (Admin only)
 *     description: |
 *       Register a new merchant account in the system.
 *
 *       **Admin Only**: Requires admin or superadmin authentication.
 *
 *       **Process**:
 *       1. Admin creates merchant account
 *       2. Merchant status set to 'pending'
 *       3. Admin must approve via `/admin/approve/{userId}`
 *       4. Upon approval, merchant receives API credentials
 *       5. Merchant can then use transaction APIs
 *
 *       **Requirements**:
 *       - Valid TRON wallet address for withdrawals
 *       - Unique email address
 *       - Strong password (min 6 characters)
 *     tags: [Authentication]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterRequest'
 *           example:
 *             name: "John Doe"
 *             email: "merchant@example.com"
 *             password: "securePassword123"
 *             walletAddress: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *     responses:
 *       201:
 *         description: Merchant registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "User registered successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     user:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                           example: "60d5ecb74b24a1234567890a"
 *                         name:
 *                           type: string
 *                           example: "John Doe"
 *                         email:
 *                           type: string
 *                           example: "merchant@example.com"
 *                         role:
 *                           type: string
 *                           example: "merchant"
 *                         approved:
 *                           type: string
 *                           example: "pending"
 *                         walletAddress:
 *                           type: string
 *                           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Validation error or email already exists
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Email already exists"
 *                 error:
 *                   type: string
 *                   example: "Validation error"
 *       401:
 *         description: Unauthorized - Admin authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.post('/register', protect,authorizeRoles('admin', 'superadmin'),registerValidation, validateRequest, register);

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Login with cookie and bearer token authentication
 *     description: |
 *       Authenticate user and receive JWT token as cookie and in response.
 *
 *       **Dual Authentication**: Sets both cookie and returns bearer token
 *
 *       **Cookie Authentication**:
 *       - JWT token automatically set as cookie
 *       - Included in all subsequent requests
 *       - Works with Swagger UI and web applications
 *
 *       **Bearer Token**:
 *       - JWT token returned in response
 *       - Use in Authorization header: `Bearer <token>`
 *       - For API integrations and mobile apps
 *
 *       **CORS Support**: Includes proper CORS headers for cross-origin requests
 *
 *       **Account Status**: Only approved merchants can access transaction APIs
 *     tags: [Authentication]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           example:
 *             email: "merchant@example.com"
 *             password: "securePassword123"
 *     responses:
 *       200:
 *         description: Login successful - Cookie and bearer token provided
 *         headers:
 *           Set-Cookie:
 *             description: JWT authentication token (httpOnly=false for development)
 *             schema:
 *               type: string
 *               example: "token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...; Path=/; Max-Age=604800; SameSite=Lax"
 *           Access-Control-Allow-Origin:
 *             description: CORS origin header
 *             schema:
 *               type: string
 *           Access-Control-Allow-Credentials:
 *             description: CORS credentials header
 *             schema:
 *               type: string
 *               example: "true"
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/LoginResponse'
 *                 - type: object
 *                   properties:
 *                     token:
 *                       type: string
 *                       example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                       description: JWT bearer token for API authentication
 *                     apiCredentials:
 *                       type: object
 *                       properties:
 *                         apiKey:
 *                           type: string
 *                           example: "mk_1234567890_abcdef"
 *                           description: API key for transaction endpoints
 *                         apiSecret:
 *                           type: string
 *                           example: "abc123def456..."
 *                           description: API secret for x-api-secret header
 *       401:
 *         description: Invalid credentials
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Invalid credentials"
 *                 error:
 *                   type: string
 *                   example: "Invalid email or password"
 *       403:
 *         description: Account not approved yet
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Account not approved yet"
 *                 error:
 *                   type: string
 *                   example: "Account pending admin approval"
 *       400:
 *         description: Validation error
 *       500:
 *         description: Internal server error
 */
router.post('/login', loginValidation, validateRequest, login);

/**
 * @swagger
 * /auth/logout:
 *   post:
 *     summary: Logout and clear session
 *     description: |
 *       Logout user and clear authentication cookie.
 *
 *       **Process**:
 *       - Clears authentication cookie
 *       - Invalidates current session
 *       - Requires subsequent login for access
 *
 *       **CORS Support**: Proper cookie clearing for cross-origin requests
 *     tags: [Authentication]
 *     responses:
 *       200:
 *         description: Logout successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Logged out successfully"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       500:
 *         description: Internal server error
 */
router.post('/logout', logoutValidation,validateRequest,logout);

/**
 * @swagger
 * /auth/change-password:
 *   put:
 *     summary: Change account password
 *     description: |
 *       Change the password for the authenticated user account.
 *
 *       **Authentication Required**: Must be logged in
 *
 *       **Security**:
 *       - Requires current password verification
 *       - New password must meet security requirements
 *       - Invalidates existing sessions (optional)
 *     tags: [Authentication]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ChangePasswordRequest'
 *           example:
 *             currentPassword: "oldPassword123"
 *             newPassword: "newSecurePassword456"
 *     responses:
 *       200:
 *         description: Password changed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Password changed successfully"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid current password or validation error
 *       401:
 *         description: Unauthorized - Authentication required
 *       500:
 *         description: Internal server error
 */
router.put('/change-password', changePasswordValidation,validateRequest,protect, changePassword);

/**
 * @swagger
 * /auth/forgot-password:
 *   post:
 *     summary: Request password reset
 *     description: |
 *       Request a password reset link via email.
 *
 *       **Process**:
 *       1. Validates email exists in system
 *       2. Generates secure reset token
 *       3. Sends reset link via email
 *       4. Token expires in 1 hour
 *
 *       **Security**: Rate limited to prevent abuse
 *     tags: [Authentication]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ForgotPasswordRequest'
 *           example:
 *             email: "merchant@example.com"
 *     responses:
 *       200:
 *         description: Reset email sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Password reset email sent"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid email format
 *       404:
 *         description: Email not found
 *       500:
 *         description: Internal server error
 */
router.post('/forgot-password', validateForgot, validateRequest,forgotPassword);

/**
 * @swagger
 * /auth/reset-password/{token}:
 *   post:
 *     summary: Reset password with token
 *     description: |
 *       Reset password using the token received via email.
 *
 *       **Process**:
 *       1. Validates reset token
 *       2. Checks token expiry (1 hour)
 *       3. Updates password
 *       4. Invalidates reset token
 *
 *       **Security**: Token can only be used once
 *     tags: [Authentication]
 *     parameters:
 *       - in: path
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Password reset token from email
 *         example: "abc123def456ghi789"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResetPasswordRequest'
 *           example:
 *             password: "newSecurePassword123"
 *     responses:
 *       200:
 *         description: Password reset successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Password reset successfully"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid or expired token
 *       500:
 *         description: Internal server error
 */
router.post('/reset-password/:token', validateReset,validateRequest, resetPassword);



module.exports = router;