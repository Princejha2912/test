const express = require('express');
const router = express.Router();

const {
  getMyStats,
  getPlatformStats,
  getAllMerchantStats,
  getSpecificMerchantStats
} = require('../controller/simpleStatsController');

/**
 * @swagger
 * components:
 *   schemas:
 *     SimpleStatistics:
 *       type: object
 *       properties:
 *         totalDeposits:
 *           type: number
 *           example: 10
 *           description: Total number of deposits
 *         successfulDeposits:
 *           type: number
 *           example: 8
 *           description: Number of successful deposits
 *         failedDeposits:
 *           type: number
 *           example: 2
 *           description: Number of failed deposits
 *         totalWithdrawals:
 *           type: number
 *           example: 5
 *           description: Total number of withdrawals
 *         approvedWithdrawals:
 *           type: number
 *           example: 4
 *           description: Number of approved withdrawals
 *         rejectedWithdrawals:
 *           type: number
 *           example: 1
 *           description: Number of rejected withdrawals
 *         totalDepositAmount:
 *           type: number
 *           example: 5000
 *           description: Total amount deposited (USDT)
 *         totalWithdrawalAmount:
 *           type: number
 *           example: 2000
 *           description: Total amount withdrawn (USDT)
 *         totalFees:
 *           type: number
 *           example: 100
 *           description: Total fees collected (USDT)
 *         currentBalance:
 *           type: number
 *           example: 2900
 *           description: Current balance (USDT)
 *         depositSuccessRate:
 *           type: number
 *           example: 80
 *           description: Deposit success rate (percentage)
 *         withdrawalApprovalRate:
 *           type: number
 *           example: 80
 *           description: Withdrawal approval rate (percentage)
 *
 *     MerchantStatistics:
 *       type: object
 *       properties:
 *         merchantId:
 *           type: string
 *           example: "60d5ecb74b24a1234567890c"
 *         name:
 *           type: string
 *           example: "John Doe"
 *         email:
 *           type: string
 *           example: "john@example.com"
 *         totalDeposits:
 *           type: number
 *           example: 10
 *         successfulDeposits:
 *           type: number
 *           example: 8
 *         failedDeposits:
 *           type: number
 *           example: 2
 *         totalWithdrawals:
 *           type: number
 *           example: 5
 *         approvedWithdrawals:
 *           type: number
 *           example: 4
 *         rejectedWithdrawals:
 *           type: number
 *           example: 1
 *         totalDepositAmount:
 *           type: number
 *           example: 5000
 *         totalWithdrawalAmount:
 *           type: number
 *           example: 2000
 *         totalFees:
 *           type: number
 *           example: 100
 *         currentBalance:
 *           type: number
 *           example: 2900
 *         depositSuccessRate:
 *           type: number
 *           example: 80
 *         withdrawalApprovalRate:
 *           type: number
 *           example: 80
 */

const { protect, authorizeRoles } = require('../middleware/routeProtector');
const { param } = require('express-validator');
const { validateRequest } = require('../middleware/validateIncomingRequest');

// Merchant ID validation
const merchantIdValidation = [
  param('merchantId')
    .isMongoId()
    .withMessage('Valid merchant ID is required')
];

// Merchant routes - get own statistics

/**
 * @swagger
 * /statistics/my-stats:
 *   get:
 *     summary: Get merchant's own statistics
 *     description: Get transaction statistics for the authenticated merchant
 *     tags: [Statistics]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Merchant statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SimpleStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Access denied - Merchant role required
 *       500:
 *         description: Internal server error
 */
router.get(
  '/my-stats',
  protect,
  authorizeRoles('merchant'),
  getMyStats
);

// Admin routes - get platform and merchant statistics

/**
 * @swagger
 * /statistics/platform:
 *   get:
 *     summary: Get platform-wide statistics
 *     description: Get aggregated transaction statistics for all merchants (admin only)
 *     tags: [Statistics]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Platform statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SimpleStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Access denied - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get(
  '/platform',
  protect,
  authorizeRoles('admin', 'superadmin'),
  getPlatformStats
);

/**
 * @swagger
 * /statistics/all-merchants:
 *   get:
 *     summary: Get all merchant statistics
 *     description: Get transaction statistics for all merchants (admin only)
 *     tags: [Statistics]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: All merchant statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/MerchantStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Access denied - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get(
  '/all-merchants',
  protect,
  authorizeRoles('admin', 'superadmin'),
  getAllMerchantStats
);

/**
 * @swagger
 * /statistics/merchant/{merchantId}:
 *   get:
 *     summary: Get specific merchant statistics
 *     description: Get transaction statistics for a specific merchant (admin only)
 *     tags: [Statistics]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: merchantId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant ID
 *         example: "60d5ecb74b24a1234567890c"
 *     responses:
 *       200:
 *         description: Merchant statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/SimpleStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid merchant ID
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Access denied - Admin role required
 *       404:
 *         description: Merchant statistics not found
 *       500:
 *         description: Internal server error
 */
router.get(
  '/merchant/:merchantId',
  protect,
  authorizeRoles('admin', 'superadmin'),
  merchantIdValidation,
  validateRequest,
  getSpecificMerchantStats
);

module.exports = router;
