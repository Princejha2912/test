    const express = require('express');
    const router = express.Router();
    const { getMerchantDashboard, getAdminDashboard } = require('../controller/dashboardController.js');

    const { authorizeRoles, protect } = require('../middleware/routeProtector.js');


    router.get('/admin', protect, authorizeRoles('admin', 'superadmin'), getAdminDashboard);

    router.get('/merchant', protect, authorizeRoles('merchant'), getMerchantDashboard);

    module.exports = router;
