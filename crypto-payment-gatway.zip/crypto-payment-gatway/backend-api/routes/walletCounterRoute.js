const express = require('express');
const router = express.Router();
const { protect, authorizeRoles } = require('../middleware/routeProtector');
const { validateRequest } = require('../middleware/validateIncomingRequest');
const { body, param } = require('express-validator');

const {
  getCounterStatistics,
  resetCounter,
  getCounterDetails,
  initializeCounters,
  previewNextCount,
  resetCountersToOne
} = require('../controller/walletCounterController');

// Validation middleware
const networkValidator = [
  param('network')
    .isIn(['ERC20', 'TRC20'])
    .withMessage('Network must be ERC20 or TRC20')
];

const resetCounterValidator = [
  body('newCount')
    .optional()
    .isInt({ min: 0 })
    .withMessage('New count must be a positive integer')
];

/**
 * @swagger
 * components:
 *   schemas:
 *     CounterStatistics:
 *       type: object
 *       properties:
 *         ERC20:
 *           type: object
 *           properties:
 *             currentCount:
 *               type: number
 *               example: 1704067200005
 *             network:
 *               type: string
 *               example: "ERC20"
 *         TRC20:
 *           type: object
 *           properties:
 *             currentCount:
 *               type: number
 *               example: 1704067200003
 *             network:
 *               type: string
 *               example: "TRC20"
 *     
 *     CounterDetails:
 *       type: object
 *       properties:
 *         network:
 *           type: string
 *           example: "ERC20"
 *         currentCount:
 *           type: number
 *           example: 1704067200005
 *         lastUsedAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:05:00.000Z"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T09:00:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:05:00.000Z"
 *     
 *     ResetCounterRequest:
 *       type: object
 *       properties:
 *         newCount:
 *           type: number
 *           minimum: 0
 *           example: 1704067300000
 *           description: New count value (optional, defaults to current timestamp)
 */

/**
 * @swagger
 * /wallet-counter/statistics:
 *   get:
 *     summary: Get wallet counter statistics
 *     description: Get current count statistics for all networks (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Counter statistics retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Counter statistics retrieved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/CounterStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get('/statistics', protect, authorizeRoles('admin', 'superadmin'), getCounterStatistics);

/**
 * @swagger
 * /wallet-counter/{network}:
 *   get:
 *     summary: Get detailed counter information
 *     description: Get detailed information for a specific network counter (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: network
 *         required: true
 *         schema:
 *           type: string
 *           enum: [ERC20, TRC20]
 *         description: Network type
 *         example: "ERC20"
 *     responses:
 *       200:
 *         description: Counter details retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "ERC20 counter details retrieved successfully"
 *                 data:
 *                   $ref: '#/components/schemas/CounterDetails'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid network parameter
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Counter not found
 *       500:
 *         description: Internal server error
 */
router.get('/:network', protect, authorizeRoles('admin', 'superadmin'), networkValidator, validateRequest, getCounterDetails);

/**
 * @swagger
 * /wallet-counter/{network}/reset:
 *   post:
 *     summary: Reset counter for a network
 *     description: Reset the counter for a specific network to a new value (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: network
 *         required: true
 *         schema:
 *           type: string
 *           enum: [ERC20, TRC20]
 *         description: Network type
 *         example: "ERC20"
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ResetCounterRequest'
 *           example:
 *             newCount: 1704067300000
 *     responses:
 *       200:
 *         description: Counter reset successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "ERC20 counter reset successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     network:
 *                       type: string
 *                       example: "ERC20"
 *                     newCount:
 *                       type: number
 *                       example: 1704067300000
 *                     resetAt:
 *                       type: string
 *                       format: date-time
 *                       example: "2024-01-01T10:15:00.000Z"
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid network or count parameter
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.post('/:network/reset', protect, authorizeRoles('admin', 'superadmin'), networkValidator, resetCounterValidator, validateRequest, resetCounter);

/**
 * @swagger
 * /wallet-counter/{network}/preview:
 *   get:
 *     summary: Preview next count value
 *     description: Preview what the next count value would be without incrementing (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: network
 *         required: true
 *         schema:
 *           type: string
 *           enum: [ERC20, TRC20]
 *         description: Network type
 *         example: "ERC20"
 *     responses:
 *       200:
 *         description: Next count preview retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Next count preview for ERC20"
 *                 data:
 *                   type: object
 *                   properties:
 *                     network:
 *                       type: string
 *                       example: "ERC20"
 *                     currentCount:
 *                       type: number
 *                       example: 1704067200005
 *                     nextCount:
 *                       type: number
 *                       example: 1704067200006
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       400:
 *         description: Invalid network parameter
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.get('/:network/preview', protect, authorizeRoles('admin', 'superadmin'), networkValidator, validateRequest, previewNextCount);

/**
 * @swagger
 * /wallet-counter/initialize:
 *   post:
 *     summary: Initialize wallet counters
 *     description: Initialize or reinitialize all wallet counters (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Wallet counters initialized successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Wallet counters initialized successfully"
 *                 data:
 *                   $ref: '#/components/schemas/CounterStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.post('/initialize', protect, authorizeRoles('admin', 'superadmin'), initializeCounters);

/**
 * @swagger
 * /wallet-counter/reset-to-one:
 *   post:
 *     summary: Reset counters to start from 1
 *     description: Reset all wallet counters to start from 1 (Admin only)
 *     tags: [Wallet Counter Management]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     responses:
 *       200:
 *         description: Wallet counters reset successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Wallet counters reset to start from 1"
 *                 data:
 *                   $ref: '#/components/schemas/CounterStatistics'
 *                 error:
 *                   type: string
 *                   nullable: true
 *                   example: null
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       500:
 *         description: Internal server error
 */
router.post('/reset-to-one', protect, authorizeRoles('admin', 'superadmin'), resetCountersToOne);

module.exports = router;
