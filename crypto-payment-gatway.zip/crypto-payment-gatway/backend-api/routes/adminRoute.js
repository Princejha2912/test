const express = require('express');
const router = express.Router();

const { authorizeRoles, protect } = require('../middleware/routeProtector.js');
const {
  approveMerchant,
  blockMerchant
} = require('../controller/adminController.js');
const {
  approveMerchantValidation
} = require('../validations/merchantVlidator.js');
const { validateRequest } = require('../middleware/validateIncomingRequest.js');

/**
 * @swagger
 * components:
 *   schemas:
 *     MerchantApprovalResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Merchant approved and credentials sent via email"
 *         data:
 *           type: object
 *           properties:
 *             userId:
 *               type: string
 *               example: "60d5ecb74b24a1234567890c"
 *             name:
 *               type: string
 *               example: "John Doe"
 *             email:
 *               type: string
 *               example: "john@example.com"
 *             approved:
 *               type: string
 *               example: "approved"
 *             apiKey:
 *               type: string
 *               example: "ak_1234567890abcdef"
 *               description: "Generated API key for the merchant"
 *         error:
 *           type: string
 *           nullable: true
 *           example: null
 *
 *     MerchantBlockResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Merchant blocked and notification sent via email"
 *         error:
 *           type: string
 *           nullable: true
 *           example: null
 *
 *     AdminError:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: false
 *         message:
 *           type: string
 *           example: "Merchant not found"
 *         error:
 *           type: string
 *           example: "Invalid merchant user ID"
 */

/**
 * @swagger
 * /admin/approve/{userId}:
 *   patch:
 *     summary: Approve merchant account
 *     description: Approve a merchant account and generate API credentials. Sends approval email with credentials to the merchant.
 *     tags: [Admin]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID to approve
 *         example: "60d5ecb74b24a1234567890c"
 *     responses:
 *       200:
 *         description: Merchant approved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MerchantApprovalResponse'
 *       400:
 *         description: Bad request - Merchant already approved or invalid data
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AdminError'
 *             examples:
 *               already_approved:
 *                 summary: Merchant already approved
 *                 value:
 *                   success: false
 *                   message: "Merchant already approved"
 *                   error: "Already approved"
 *               validation_error:
 *                 summary: Validation error
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   error: "Invalid user ID format"
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Merchant not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AdminError'
 *             example:
 *               success: false
 *               message: "Merchant not found"
 *               error: "Invalid merchant user ID"
 *       500:
 *         description: Internal server error
 */
router.patch(
  '/approve/:userId',
  protect,
  authorizeRoles('admin', 'superadmin'),
  approveMerchantValidation,
  validateRequest,
  approveMerchant
);

/**
 * @swagger
 * /admin/block/{userId}:
 *   patch:
 *     summary: Block merchant account
 *     description: Block a merchant account and send notification email. This prevents the merchant from using the platform.
 *     tags: [Admin]
 *     security:
 *       - BearerAuth: []
 *       - CookieAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant user ID to block
 *         example: "60d5ecb74b24a1234567890c"
 *     responses:
 *       200:
 *         description: Merchant blocked successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MerchantBlockResponse'
 *       400:
 *         description: Bad request - Merchant already blocked or invalid data
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AdminError'
 *             examples:
 *               already_blocked:
 *                 summary: Merchant already blocked
 *                 value:
 *                   success: false
 *                   message: "Merchant already blocked"
 *                   error: "Already blocked"
 *               validation_error:
 *                 summary: Validation error
 *                 value:
 *                   success: false
 *                   message: "Validation failed"
 *                   error: "Invalid user ID format"
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin role required
 *       404:
 *         description: Merchant not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AdminError'
 *             example:
 *               success: false
 *               message: "Merchant not found"
 *               error: "Invalid merchant user ID"
 *       500:
 *         description: Internal server error
 */
router.patch(
  '/block/:userId',
  protect,
  authorizeRoles('admin', 'superadmin'),
  approveMerchantValidation,
  validateRequest,
  blockMerchant
);

module.exports = router;
