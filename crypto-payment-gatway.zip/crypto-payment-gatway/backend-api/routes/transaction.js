const express = require('express');
const router = express.Router();
const { createTransaction, depositeTransaction, getMerchantTransactions, getAllTransactions,startTransactionFromToken} = require('../controller/transactionController');
const {initiateTransactionValidator, validateDepositeTransaction} = require('../validations/transactionValidator')
const { merchantTransactionListValidation ,validateCreateTransaction } = require('../validations/transactionListValidator')
const { apiAuth } = require('../middleware/VerifyMerchant');
const { validateRequest } = require('../middleware/validateIncomingRequest');



router.get('/start/:token', startTransactionFromToken);
/**
 * @swagger
 * components:
 *   schemas:
 *     TransactionCreateResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Transaction initiated"
 *         transactionId:
 *           type: string
 *           example: "dep_1234567890_abcdef"
 *           description: Unique transaction identifier
 *         walletAddress:
 *           type: string
 *           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *           description: Generated wallet address for deposit
 *         amount:
 *           type: number
 *           example: 500
 *           description: Deposit amount in USDT
 *         currencyType:
 *           type: string
 *           example: "USDT-TRC20"
 *           description: Currency type (only USDT-TRC20 supported)
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-01T10:10:00.000Z"
 *           description: Transaction expiry time (10 minutes)
 *         timeRemaining:
 *           type: number
 *           example: 600
 *           description: Time remaining in seconds
 *
 *     DepositConfirmRequest:
 *       type: object
 *       required:
 *         - walletAddress
 *       properties:
 *         walletAddress:
 *           type: string
 *           example: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *           description: The wallet address where payment was sent
 *
 *     DepositConfirmResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "Deposit transaction confirmed"
 *         data:
 *           type: object
 *           properties:
 *             transactionId:
 *               type: string
 *               example: "dep_1234567890_abcdef"
 *             status:
 *               type: string
 *               example: "confirmed"
 *             amount:
 *               type: number
 *               example: 500
 *             currencyType:
 *               type: string
 *               example: "USDT-TRC20"
 *             confirmedAt:
 *               type: string
 *               format: date-time
 *               example: "2024-01-01T10:05:00.000Z"
 *         error:
 *           type: string
 *           nullable: true
 *           example: null
 */

/**
 * @swagger
 * /transaction/{apiKey}/create:
 *   get:
 *     summary: Create USDT-TRC20 deposit transaction
 *     description: |
 *       Create a new deposit transaction for USDT-TRC20 payments.
 *
 *       **Merchant API**: Requires valid API key authentication.
 *
 *       **Process Flow**:
 *       1. Validates merchant API credentials
 *       2. Generates unique transaction ID
 *       3. Creates wallet address for deposit (via third-party API)
 *       4. Sets 10-minute expiry timer
 *       5. Returns wallet address for customer payment
 *       6. Use `/deposite` endpoint to confirm payment
 *
 *       **Currency Support**: Only USDT-TRC20 is supported
 *
 *       **Expiry**: Transaction expires in 10 minutes if not confirmed
 *     tags: [Transactions]
 *     security:
 *       - ApiKeyAuth: []
 *     parameters:
 *       - in: path
 *         name: apiKey
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant API key (same as x-api-secret header)
 *         example: "mk_1234567890_abcdef"
 *       - in: query
 *         name: amount
 *         required: true
 *         schema:
 *           type: number
 *           minimum: 0.01
 *         description: Amount to deposit in USDT
 *         example: 500
 *       - in: query
 *         name: currencyType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [USDT-TRC20]
 *         description: Currency type (only USDT-TRC20 supported)
 *         example: "USDT-TRC20"
 *     responses:
 *       201:
 *         description: Transaction created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TransactionCreateResponse'
 *       400:
 *         description: Invalid parameters or unsupported currency
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Only USDT-TRC20 is supported"
 *                 error:
 *                   type: string
 *                   example: "Validation error"
 *       401:
 *         description: Invalid API credentials
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Invalid API credentials"
 *       403:
 *         description: Merchant account not approved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Merchant account not approved"
 *       500:
 *         description: Internal server error
 */
router.get('/create',validateCreateTransaction,validateRequest,apiAuth  ,createTransaction);

/**
 * @swagger
 * /transaction/{apiKey}/deposite:
 *   post:
 *     summary: Confirm USDT-TRC20 deposit payment
 *     description: |
 *       Confirm that payment has been sent to the generated wallet address.
 *
 *       **Merchant API**: Requires valid API key authentication.
 *
 *       **Process Flow**:
 *       1. Validates merchant API credentials
 *       2. Finds transaction by wallet address
 *       3. Checks if transaction is still valid (not expired)
 *       4. Verifies payment via third-party blockchain API
 *       5. Updates transaction status to confirmed
 *       6. Credits amount to merchant balance
 *       7. Sends notification to Super Admin
 *
 *       **Payment Verification**: Uses third-party blockchain API to verify USDT-TRC20 payment
 *
 *       **Timeout**: Must be called within 10 minutes of transaction creation
 *     tags: [Transactions]
 *     security:
 *       - ApiKeyAuth: []
 *     parameters:
 *       - in: path
 *         name: apiKey
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant API key (same as x-api-secret header)
 *         example: "mk_1234567890_abcdef"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/DepositConfirmRequest'
 *           example:
 *             walletAddress: "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"
 *     responses:
 *       200:
 *         description: Deposit confirmed successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DepositConfirmResponse'
 *       400:
 *         description: Invalid wallet address or transaction issues
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Transaction not found or already processed"
 *                 error:
 *                   type: string
 *                   example: "Invalid transaction"
 *       408:
 *         description: Transaction expired
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Transaction has expired"
 *                 error:
 *                   type: string
 *                   example: "Transaction timeout - 10 minutes exceeded"
 *       401:
 *         description: Invalid API credentials
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Invalid API credentials"
 *       403:
 *         description: Merchant account not approved
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Merchant account not approved"
 *       422:
 *         description: Payment not found on blockchain
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Payment not confirmed on blockchain"
 *                 error:
 *                   type: string
 *                   example: "No payment received at wallet address"
 *       500:
 *         description: Internal server error
 */
// router.post('/:apiKey/deposite',apiAuth, validateDepositeTransaction, validateRequest,depositeTransaction);

/**
 * @swagger
 * /transaction/{apiKey}/list:
 *   get:
 *     summary: Get merchant transactions
 *     description: |
 *       Retrieve all transactions for the authenticated merchant with pagination and filtering options.
 *
 *       **Merchant API**: Requires valid API key authentication.
 *
 *       **Features**:
 *       - Pagination support
 *       - Status filtering (initiated, confirmed, failed, expired, pending, api_failed)
 *       - Currency type filtering (USDT-ERC20, USDT-TRC20)
 *       - Sorting options
 *       - Transaction summary statistics
 *     tags: [Transactions]
 *     security:
 *       - ApiKeyAuth: []
 *     parameters:
 *       - in: path
 *         name: apiKey
 *         required: true
 *         schema:
 *           type: string
 *         description: Merchant API key
 *         example: "mk_1234567890abcdef"
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number for pagination
 *         example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 10
 *         description: Number of transactions per page
 *         example: 10
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [initiated, confirmed, failed, expired, pending, api_failed]
 *         description: Filter by transaction status
 *         example: "confirmed"
 *       - in: query
 *         name: currencyType
 *         schema:
 *           type: string
 *           enum: [USDT-ERC20, USDT-TRC20]
 *         description: Filter by currency type
 *         example: "USDT-ERC20"
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [createdAt, amount, status, confirmedAt]
 *           default: createdAt
 *         description: Field to sort by
 *         example: "createdAt"
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: Sort order
 *         example: "desc"
 *     responses:
 *       200:
 *         description: Merchant transactions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Merchant transactions retrieved successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     transactions:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           _id:
 *                             type: string
 *                             example: "64f7b1234567890abcdef123"
 *                           transactionId:
 *                             type: string
 *                             example: "dep_1234567890_abcdef"
 *                           amount:
 *                             type: number
 *                             example: 1000
 *                           currencyType:
 *                             type: string
 *                             example: "USDT-ERC20"
 *                           status:
 *                             type: string
 *                             example: "confirmed"
 *                           walletAddress:
 *                             type: string
 *                             example: "0xbb4eaf8010acd1c981e650c515e8fe9cbc4d574b"
 *                           createdAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:00:00.000Z"
 *                           confirmedAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:05:00.000Z"
 *                           expiresAt:
 *                             type: string
 *                             format: date-time
 *                             example: "2024-01-01T10:10:00.000Z"
 *                     pagination:
 *                       type: object
 *                       properties:
 *                         currentPage:
 *                           type: integer
 *                           example: 1
 *                         totalPages:
 *                           type: integer
 *                           example: 5
 *                         totalTransactions:
 *                           type: integer
 *                           example: 47
 *                         limit:
 *                           type: integer
 *                           example: 10
 *                         hasNextPage:
 *                           type: boolean
 *                           example: true
 *                         hasPrevPage:
 *                           type: boolean
 *                           example: false
 *                     summary:
 *                       type: object
 *                       properties:
 *                         confirmed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 25
 *                             totalAmount:
 *                               type: number
 *                               example: 25000
 *                         failed:
 *                           type: object
 *                           properties:
 *                             count:
 *                               type: integer
 *                               example: 5
 *                             totalAmount:
 *                               type: number
 *                               example: 2500
 *                     filters:
 *                       type: object
 *                       properties:
 *                         status:
 *                           type: string
 *                           example: "confirmed"
 *                         currencyType:
 *                           type: string
 *                           example: "USDT-ERC20"
 *                         sortBy:
 *                           type: string
 *                           example: "createdAt"
 *                         sortOrder:
 *                           type: string
 *                           example: "desc"
 *       401:
 *         description: Unauthorized - Invalid API key
 *       403:
 *         description: Forbidden - Merchant account not approved
 *       500:
 *         description: Internal server error
 */
router.get('/:apiKey/list', apiAuth, merchantTransactionListValidation, validateRequest, getMerchantTransactions);

module.exports = router;
