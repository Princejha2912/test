/**
 * Script to reset wallet counters to start from 1
 * Run this script to fix existing counters
 */

const mongoose = require('mongoose');
const WalletCounter = require('../models/walletCounter');
require('dotenv').config();

async function resetCountersToOne() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);

    // Reset ERC20 counter to 1
    await WalletCounter.findOneAndUpdate(
      { network: 'ERC20' },
      { 
        currentCount: 1,
        lastUsedAt: new Date()
      },
      { 
        upsert: true,
        runValidators: true
      }
    );

    // Reset TRC20 counter to 1
    await WalletCounter.findOneAndUpdate(
      { network: 'TRC20' },
      { 
        currentCount: 1,
        lastUsedAt: new Date()
      },
      { 
        upsert: true,
        runValidators: true
      }
    );

    // Verify the reset
    const erc20Counter = await WalletCounter.findOne({ network: 'ERC20' });
    const trc20Counter = await WalletCounter.findOne({ network: 'TRC20' });

  

  } catch (error) {
    console.error('❌ Error resetting counters:', error.message);
  } finally {
    // Close MongoDB connection
    await mongoose.connection.close();
    console.log('🔌 MongoDB connection closed');
    process.exit(0);
  }
}

resetCountersToOne();
