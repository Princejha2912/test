const { body } = require('express-validator');

exports.initiateTransactionValidator = [
];


exports.validateDepositeTransaction = [
  body('amount')
    .notEmpty()
    .withMessage('Amount is required')
    .isFloat({ gt: 0 })
    .withMessage('Amount must be greater than 0'),
  body('walletAddress')
    .notEmpty()
    .withMessage('Wallet address is required'),
];

