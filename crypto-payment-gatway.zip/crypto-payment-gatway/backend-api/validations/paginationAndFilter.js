const { query } = require('express-validator');

exports.validatePagination = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1 }).withMessage('Limit must be a positive integer'),
  query('status').optional().isIn(['pending', 'rejected', 'completed', 'failed']).withMessage('Invalid status'),
  query('search').optional().isString().withMessage('Search must be a string'),
  query('fromDate').optional().isISO8601().withMessage('From date must be a valid date'),
  query('toDate').optional().isISO8601().withMessage('To date must be a valid date'),
];