const { body } = require('express-validator');

exports.registerValidation = [
  body('name', 'Name is required').notEmpty().trim(),

  body('email', 'Please include a valid email').isEmail().normalizeEmail(),

  body('password', 'Password must be 8 or more characters')
    .isLength({ min: 8 }),

  body('confirmPassword')
    .notEmpty().withMessage('Please confirm your password')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Passwords do not match');
      }
      return true;
    }),

  // Enhanced merchant fields
  body('country')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Country must be between 2 and 50 characters'),
body('phoneNo')
    .optional()
    .trim()
    .matches(/^(\+?\d{1,3}[- ]?)?\d{10}$/)
    .withMessage('Please provide a valid phone number'),

  body('companyName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Company name must be between 2 and 100 characters'),

  body('licenceNo')
    .optional()
    .trim()
    .isLength({ max: 50 })
    .withMessage('License number must not exceed 50 characters')
 
];


exports.loginValidation = [
  body('email', 'Please include a valid email').isEmail().normalizeEmail(),
  body('password', 'Password is required').exists(),
  body('otp')
    .optional()
    .isLength({ min: 6, max: 6 })
    .withMessage('OTP must be exactly 6 digits')
    .isNumeric()
    .withMessage('OTP must contain only numbers'),
];


exports.changePasswordValidation = [
  body('currentPassword', 'Current password is required').notEmpty(),
  body('newPassword', 'New password must be at least 8 characters long').isLength({ min: 8 }),
];


exports.logoutValidation = [
  body().custom((_, { req }) => {
    if (!req.cookies || !req.cookies.token) {
      throw new Error('No token found in cookies for logout');
    }
    return true;
  })
];



exports.validateForgot = [
  body('email').isEmail().withMessage('Valid email is required')
];

exports.validateReset = [
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
];



