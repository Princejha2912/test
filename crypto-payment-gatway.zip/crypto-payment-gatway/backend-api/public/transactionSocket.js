
socket.on('connect', () => {
  const { transactionId } = window.transactionData || {};

  if (transactionId) {
    socket.emit('track-transaction', { transactionId });
  }
});

socket.on('transaction-status', (data) => {
  const statusBox = document.getElementById('status');

  if (data.status === 'confirmed') {
    statusBox.innerText = "✅ Confirmed!";
  } else if (data.status === 'failed') {
    statusBox.innerText = "❌ Failed: " + (data.message || "Unknown error");
  }
});
