import React, { useEffect, useState } from "react";
import {
  MessageSquare,
  RefreshCw,
  ArrowLeft,
  ArrowRight,
  AlertCircle,
  Edit,
  Copy,
  Check,
  DollarSign,
  Calendar,
  Wallet,
  Clock,
  Filter,
  Search,
  X
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import CopyButton from "../Button/Copy";

// const API_BASE_URL = "http://localhost:5000/api/v1";
  const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';

const AllComplaints = () => {
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  // Update modal state
  const [updateModal, setUpdateModal] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [updateLoading, setUpdateLoading] = useState(false);

  const fetchComplaints = async (pageNumber = 1) => {
    try {
      setLoading(true);
      const response = await fetch(
        `${API_BASE_URL}/refund/merchant?page=${pageNumber}&limit=${limit}`,
        {
          method: "GET",
          credentials: "include", // needed so backend gets the auth session/cookie
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to fetch complaints");
      }

      // ✅ backend returns `data` array and `pagination`
      setComplaints((data.data || []).reverse());
      setTotalPages(data.pagination?.totalPages || 1);
      setError(null);
    } catch (err) {
      console.error("Error fetching complaints:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaints(page);
  }, [page]);

  const refreshData = async () => {
    setIsRefreshing(true);
    await fetchComplaints(page);
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const getComplaintStatusColor = (status) => {
    const statusStyles = {
      "resolved": "bg-emerald-50 text-emerald-700 border-emerald-200 ring-emerald-600/20",
      "pending": "bg-amber-50 text-amber-700 border-amber-200 ring-amber-600/20",
      "in-progress": "bg-blue-50 text-blue-700 border-blue-200 ring-blue-600/20",
      "rejected": "bg-red-50 text-red-700 border-red-200 ring-red-600/20",
      "approved by merchant": "bg-purple-50 text-purple-700 border-purple-200 ring-purple-600/20"
    };
    return statusStyles[status] || "bg-gray-50 text-gray-600 border-gray-200 ring-gray-600/20";
  };

  const openUpdateModal = (complaint) => {
    setSelectedComplaint({...complaint, action: "approve", adminNotes: ""});
    setUpdateModal(true);
  };

  const handleUpdate = async () => {
    if (!selectedComplaint?._id) return;

    const bodyData = {
      action: selectedComplaint.action || "approve",
      status: selectedComplaint.status || "resolved",
      adminNotes: selectedComplaint.adminNotes || "Updated via merchant UI"
    };

    setUpdateLoading(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/refund/merchant/${selectedComplaint._id}`,
        {
          method: "PUT",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(bodyData),
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to update complaint");
      }

      alert(data.message || "Complaint updated successfully!");
      setUpdateModal(false);
      fetchComplaints(page); // refresh the list after update
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setUpdateLoading(false);
    }
  };

  const filteredComplaints = complaints.filter(complaint => {
    const matchesSearch = complaint.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         complaint.message?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || complaint.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-slate-600 font-medium">Loading withdrawals...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-800 mb-2">Something went wrong</h3>
          <p className="text-slate-600 mb-6">{error}</p>
          <button
            onClick={refreshData}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate(-1)}
                className="p-2 rounded-xl hover:bg-white hover:shadow-md transition-all duration-200 bg-white/50"
                title="Back"
              >
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </button>
              <div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-800">
                  Withdrawal Requests
                </h1>
                <p className="text-slate-600 mt-1">Manage and track all withdrawal requests</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-2 px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 rounded-xl shadow-sm border border-slate-200 transition-all duration-200 lg:hidden"
              >
                <Filter className="w-4 h-4" />
                <span>Filters</span>
              </button>
              
              <button
                onClick={refreshData}
                disabled={isRefreshing}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>
          </div>

          {/* Search and Filters */}
          <div className={`bg-white rounded-2xl shadow-lg border border-slate-200 p-4 sm:p-6 ${showFilters || window.innerWidth >= 1024 ? 'block' : 'hidden lg:block'}`}>
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search withdrawals..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 lg:w-auto">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  {/* <option value="approved by merchant">Approved</option> */}
                  <option value="resolved">Resolved</option>
                  <option value="rejected">Rejected</option>
                </select>
                
                <button
                  onClick={() => setShowFilters(false)}
                  className="lg:hidden p-3 text-slate-500 hover:text-slate-700 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Complaints Grid */}
        <div className="grid gap-6">
          {filteredComplaints.length > 0 ? (
            filteredComplaints.map((complaint) => (
              <div
                key={complaint._id}
                className="bg-white rounded-2xl shadow-lg border border-slate-200 hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="p-6">
                  {/* Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-slate-800">
                          {complaint.title || "Withdrawal Request"}
                        </h3>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium border ring-1 ${getComplaintStatusColor(complaint.status)}`}>
                          {complaint.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">
                        {complaint.message || "No description available"}
                      </p>
                    </div>
                    
                    {complaint.status !== "resolved" && complaint.status !== "rejected" &&(
                      <button
                        onClick={() => openUpdateModal(complaint)}
                        className="flex items-center space-x-2 px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl transition-all duration-200 border border-blue-200"
                      >
                        <Edit className="w-4 h-4" />
                        <span className="font-medium">Update</span>
                      </button>
                    )}
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-100">
                    {/* Amount */}
                    <div className="bg-slate-50 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <DollarSign className="w-4 h-4 text-slate-500" />
                        <span className="text-sm font-medium text-slate-700">Amount</span>
                      </div>
                      <p className="text-lg font-bold text-slate-900">
                        ${complaint.withdrawalId?.amount !== undefined ? complaint.withdrawalId.amount.toLocaleString() : "N/A"}
                      </p>
                      <p className="text-sm font-semibold text-emerald-600 mt-1">
                        Net: ${complaint.withdrawalId?.amount !== undefined && complaint.withdrawalId?.fee !== undefined
                          ? (complaint.withdrawalId.amount - complaint.withdrawalId.fee).toLocaleString()
                          : "N/A"}
                      </p>
                    </div>

                    {/* Wallet */}
                    <div className="bg-slate-50 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Wallet className="w-4 h-4 text-slate-500" />
                        <span className="text-sm font-medium text-slate-700">Wallet</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <p className="text-sm font-mono text-slate-600 truncate max-w-[120px]">
                          {complaint.withdrawalId?.clientWallet || "N/A"}
                        </p>
                        {complaint.withdrawalId?.clientWallet && (
                          <CopyButton value={complaint.withdrawalId.clientWallet} />
                        )}
                      </div>
                    </div>

                    {/* Submitted */}
                    <div className="bg-slate-50 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Calendar className="w-4 h-4 text-slate-500" />
                        <span className="text-sm font-medium text-slate-700">Submitted</span>
                      </div>
                      <p className="text-sm text-slate-600">
                        {complaint.submittedAt ? new Date(complaint.submittedAt).toLocaleDateString() : "N/A"}
                      </p>
                      <p className="text-xs text-slate-500">
                        {complaint.submittedAt ? new Date(complaint.submittedAt).toLocaleTimeString() : ""}
                      </p>
                    </div>

                    {/* Updated */}
                    <div className="bg-slate-50 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-slate-500" />
                        <span className="text-sm font-medium text-slate-700">Updated</span>
                      </div>
                      <p className="text-sm text-emerald-600 font-medium">
                        {complaint.withdrawalId?.updatedAt ? new Date(complaint.withdrawalId.updatedAt).toLocaleDateString() : "N/A"}
                      </p>
                      <p className="text-xs text-slate-500">
                        {complaint.withdrawalId?.updatedAt ? new Date(complaint.withdrawalId.updatedAt).toLocaleTimeString() : ""}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-12 text-center">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-xl font-semibold text-slate-600 mb-2">No withdrawals found</h3>
              <p className="text-slate-500">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-8 pt-6 border-t border-slate-200">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex items-center space-x-2 px-6 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-slate-600">
              Page {page} of {totalPages}
            </span>
          </div>
          
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="flex items-center space-x-2 px-6 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
          >
            <span>Next</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Update Modal */}
      {updateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">Update Request</h3>
                <button
                  onClick={() => setUpdateModal(false)}
                  className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Action */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Action
                  </label>
                  <select
                    value={selectedComplaint?.action || "approve"}
                    onChange={(e) =>
                      setSelectedComplaint((prev) => ({
                        ...prev,
                        action: e.target.value,
                      }))
                    }
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="approve">Approve</option>
                    <option value="reject">Reject</option>
                  </select>
                </div>

                {/* Status */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Status
                  </label>
                  <select
                    value={selectedComplaint?.status || "resolved"}
                    onChange={(e) =>
                      setSelectedComplaint((prev) => ({
                        ...prev,
                        status: e.target.value,
                      }))
                    }
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="resolved">Resolved</option>
                    <option value="pending">Pending</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Admin Notes
                  </label>
                  <textarea
                    value={selectedComplaint?.adminNotes || ""}
                    onChange={(e) =>
                      setSelectedComplaint((prev) => ({
                        ...prev,
                        adminNotes: e.target.value,
                      }))
                    }
                    className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    rows="4"
                    placeholder="Add any notes about this update..."
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-slate-200">
                <button
                  onClick={() => setUpdateModal(false)}
                  className="px-6 py-3 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdate}
                  disabled={updateLoading}
                  className="px-6 py-3 rounded-xl bg-blue-600 text-white hover:bg-blue-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed min-w-[100px]"
                >
                  {updateLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin mx-auto" />
                  ) : (
                    "Update"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AllComplaints;