"use client"
import { useState, useEffect } from "react"
import {
  DollarSign,
  CreditCard,
  List,
  ChevronLeft,
  ChevronRight,
  Eye,
  ExternalLink,
  Calendar,
  Wallet,
  Hash,
  Filter,
  RotateCcw,
} from "lucide-react"

const Button = ({ onClick, children, variant = "primary", disabled = false, icon: Icon, className = "" }) => {
  const baseClasses =
    "flex items-center justify-center space-x-2 px-4 py-2.5 sm:px-6 sm:py-1.5 rounded-xl font-medium transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base"
  const variants = {
    primary:
      "bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-purple-500/25 transform hover:scale-[1.02]",
    success:
      "bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-green-500/25 transform hover:scale-[1.02]",
    danger:
      "bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-lg hover:shadow-red-500/25 transform hover:scale-[1.02]",
    outline:
      "border border-slate-300 bg-white/80 backdrop-blur-sm text-slate-700 hover:bg-slate-50 hover:border-slate-400 shadow-sm",
    secondary: "bg-slate-200 hover:bg-slate-300 text-slate-700 shadow-sm transform hover:scale-[1.02]",
  }

  return (
    <button onClick={onClick} disabled={disabled} className={`${baseClasses} ${variants[variant]} ${className}`}>
      {Icon && <Icon className="w-2 h-2 sm:w-5 sm:h-5" />}
      <span className="inline">{children}</span>
    </button>
  )
}

const AllTransactions = () => {
  const [allTransactions, setAllTransactions] = useState([]) // Store all fetched transactions for current tab
  const [filteredTransactions, setFilteredTransactions] = useState([])
  const [displayedTransactions, setDisplayedTransactions] = useState([]) // Transactions to show on current page
  const [selectedTab, setSelectedTab] = useState("deposit")
  const [currentPage, setCurrentPage] = useState(1)
  const [limit] = useState(10)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [hasNextPage, setHasNextPage] = useState(true)
  const [backButtonVisible, setBackButtonVisible] = useState(true)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState(null)
  const [totalPages, setTotalPages] = useState(1)
  const [isFiltering, setIsFiltering] = useState(false)
  const [totalTransactions, setTotalTransactions] = useState(0)

  // Filter states
  const [dateFilter, setDateFilter] = useState({
    startDate: "",
    endDate: "",
  })
  const [statusFilter, setStatusFilter] = useState("")
  const [showFilters, setShowFilters] = useState(false)

  // const API_BASE_URL = "http://localhost:5000/api/v1"
  const API_BASE_URL = "https://backend.payglobal.co.in/api/v1";


  // Get unique statuses dynamically from all transactions
  const getUniqueStatuses = () => {
    const statuses = [...new Set(allTransactions.map((tx) => tx.status))]
    return statuses.sort()
  }

  // Check if any filters are active
  const hasActiveFilters = () => {
    return dateFilter.startDate || dateFilter.endDate || statusFilter
  }

  // Apply filters to all transactions
  const applyFilters = () => {
    let filtered = [...allTransactions]

    // Apply date filter
    if (dateFilter.startDate) {
      filtered = filtered.filter((tx) => {
        const txDate = new Date(tx.createdAt)
        const startDate = new Date(dateFilter.startDate)
        return txDate >= startDate
      })
    }

    if (dateFilter.endDate) {
      filtered = filtered.filter((tx) => {
        const txDate = new Date(tx.createdAt)
        const endDate = new Date(dateFilter.endDate)
        endDate.setHours(23, 59, 59, 999)
        return txDate <= endDate
      })
    }

    // Apply status filter
    if (statusFilter) {
      filtered = filtered.filter((tx) => tx.status === statusFilter)
    }

    setFilteredTransactions(filtered)
    // Calculate pagination for filtered results
    const totalFilteredPages = Math.ceil(filtered.length / limit)
    setTotalPages(totalFilteredPages)
    // Reset to page 1 when filters change
    setCurrentPage(1)
    // Get transactions for current page
    const startIndex = 0 // Start from page 1
    const endIndex = startIndex + limit
    setDisplayedTransactions(filtered.slice(startIndex, endIndex))
    // Update hasNextPage based on filtered results
    setHasNextPage(totalFilteredPages > 1)
  }

  // Clear all filters
  const clearFilters = () => {
    setDateFilter({ startDate: "", endDate: "" })
    setStatusFilter("")
    setIsFiltering(false)
    setCurrentPage(1)
    // Reset to show all transactions with original pagination
    setFilteredTransactions(allTransactions)
    const startIndex = 0
    const endIndex = startIndex + limit
    setDisplayedTransactions(allTransactions.slice(startIndex, endIndex))
    setTotalPages(Math.ceil(allTransactions.length / limit))
    setHasNextPage(allTransactions.length > limit)
  }

  // Fetch transactions for current page only
  const fetchTransactions = async (page = 1) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`${API_BASE_URL}/dashboard/merchant?${selectedTab}Page=${page}&limit=${limit}`, {
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        const dashboardData = data.data
        let recentTransactions = []

        if (selectedTab === "deposit") {
          recentTransactions = dashboardData.recentTransactions?.deposits || []
        } else if (selectedTab === "payout") {
          // Only get withdrawal transactions (exclude refunds)
          const withdrawals = dashboardData.recentTransactions?.withdrawals || []
          recentTransactions = withdrawals.filter((tx) => tx.type === "withdrawal" || !tx.type)
        } else if (selectedTab === "refund") {
          // Only get refund transactions from withdrawals
          const withdrawals = dashboardData.recentTransactions?.withdrawals || []
          recentTransactions = withdrawals.filter((tx) => tx.type === "refund")
        }

        const formattedTransactions = recentTransactions.map((tx, index) => {
          const amount = Number(tx.amount) || 0
          const actualBalance = Number(tx.actualBalance) || 0
          let paymentStatus = ""

          if (selectedTab === "deposit" && actualBalance !== undefined) {
            if (actualBalance > amount) {
              paymentStatus = "Overpaid"
            } else if (actualBalance < amount) {
              paymentStatus = "Underpaid"
            } else {
              paymentStatus = "Exact Paid"
            }
          }

          return {
            ...tx,
            type: selectedTab,
            _id: `${selectedTab}_${tx.wallet || tx.clientWallet}_${tx.amount || "no-amount"}_${tx.email}_${page}_${index}`,
            createdAt: tx.createdAt || new Date().toISOString(),
            displayAmount: amount,
            actualBalance: actualBalance,
            paymentStatus: paymentStatus,
          }
        })

        if (page === 1) {
          // First page - replace all transactions
          setAllTransactions(formattedTransactions)
          setFilteredTransactions(formattedTransactions)
          setDisplayedTransactions(formattedTransactions)
          setTotalTransactions(formattedTransactions.length)

          // Better total pages calculation for first page
          if (formattedTransactions.length < limit) {
            // If first page has less than limit, we know there's only 1 page
            setTotalPages(1)
            setHasNextPage(false)
          } else {
            // If first page is full, assume at least 2 pages (current + potential next)
            setTotalPages(2)
            setHasNextPage(true)
          }
        } else {
          // Subsequent pages - append to existing transactions
          const updatedTransactions = [...allTransactions, ...formattedTransactions]
          setAllTransactions(updatedTransactions)
          setFilteredTransactions(updatedTransactions)

          // Show current page transactions
          const startIndex = (page - 1) * limit
          const endIndex = startIndex + limit
          setDisplayedTransactions(updatedTransactions.slice(startIndex, endIndex))
          setTotalTransactions(updatedTransactions.length)

          // Update total pages based on actual data we have
          if (formattedTransactions.length < limit) {
            // Current page is not full, so this is the last page
            const exactTotalPages = Math.ceil(updatedTransactions.length / limit)
            setTotalPages(exactTotalPages)
            setHasNextPage(false)
          } else {
            // Current page is full, there might be more pages
            const currentDataPages = Math.ceil(updatedTransactions.length / limit)
            setTotalPages(currentDataPages + 1) // Add 1 for potential next page
            setHasNextPage(true)
          }
        }

        // Update pagination info
        setHasNextPage(formattedTransactions.length === limit)
      } else {
        setAllTransactions([])
        setFilteredTransactions([])
        setDisplayedTransactions([])
        setHasNextPage(false)
        setTotalTransactions(0)
      }
    } catch (err) {
      console.error("Failed to fetch transactions:", err)
      setError(err.message)
      setAllTransactions([])
      setFilteredTransactions([])
      setDisplayedTransactions([])
      setHasNextPage(false)
      setTotalTransactions(0)
    } finally {
      setLoading(false)
    }
  }

  // Handle page changes
  const handlePageChange = (direction) => {
    const newPage = Math.max(1, currentPage + direction)

    if (hasActiveFilters()) {
      // Handle filtered pagination
      const maxPage = Math.ceil(filteredTransactions.length / limit)
      if (newPage <= maxPage && newPage >= 1) {
        setCurrentPage(newPage)
        const startIndex = (newPage - 1) * limit
        const endIndex = startIndex + limit
        setDisplayedTransactions(filteredTransactions.slice(startIndex, endIndex))
        setHasNextPage(newPage < maxPage)
      }
    } else {
      // Handle normal pagination
      if (direction === 1) {
        // Going to next page
        const currentDataPages = Math.ceil(allTransactions.length / limit)

        if (newPage > currentDataPages) {
          // Need to fetch more data
          if (hasNextPage) {
            setCurrentPage(newPage)
            // Don't update totalPages here, let fetchTransactions handle it
            fetchTransactions(newPage)
          }
        } else {
          // Data already available
          setCurrentPage(newPage)
          const startIndex = (newPage - 1) * limit
          const endIndex = startIndex + limit
          setDisplayedTransactions(allTransactions.slice(startIndex, endIndex))
          // Don't change hasNextPage or totalPages when navigating through existing data
        }
      } else {
        // Going to previous page
        if (newPage >= 1) {
          setCurrentPage(newPage)
          const startIndex = (newPage - 1) * limit
          const endIndex = startIndex + limit
          setDisplayedTransactions(allTransactions.slice(startIndex, endIndex))
          // Don't change pagination state when going backwards through existing data
        }
      }
    }
  }

  useEffect(() => {
    setCurrentPage(1)
    setAllTransactions([])
    setFilteredTransactions([])
    setDisplayedTransactions([])
    fetchTransactions(1)
  }, [selectedTab])

  useEffect(() => {
    const pathname = typeof window !== "undefined" ? window.location.pathname : ""
    if (pathname === "/admin") {
      setBackButtonVisible(false)
    } else {
      setBackButtonVisible(true)
    }
  }, [])

  // Apply filters whenever filter criteria change
  useEffect(() => {
    if (hasActiveFilters()) {
      setIsFiltering(true)
      applyFilters()
    } else if (isFiltering) {
      // Only clear if we were previously filtering
      clearFilters()
    }
  }, [dateFilter, statusFilter, allTransactions])

  const handleBackClick = () => {
    if (typeof window !== "undefined") {
      window.history.back()
    }
  }

  const getTransactionIcon = (type, status) => {
    if (type === "deposit") {
      if (status === "completed" || status === "approved" || status === "confirmed") {
        return (
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center shadow-sm">
            <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
          </div>
        )
      }
      return (
        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-100 to-purple-200 rounded-xl flex items-center justify-center shadow-sm">
          <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
        </div>
      )
    }

    if (type === "payout") {
      if (status === "completed" || status === "approved" || status === "confirmed") {
        return (
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center shadow-sm">
            <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
          </div>
        )
      }
      return (
        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-red-100 to-red-200 rounded-xl flex items-center justify-center shadow-sm">
          <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" />
        </div>
      )
    }

    if (type === "refund") {
      if (status === "completed" || status === "approved" || status === "confirmed") {
        return (
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center shadow-sm">
            <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
          </div>
        )
      }
      return (
        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center shadow-sm">
          <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-orange-600" />
        </div>
      )
    }

    return (
      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-red-100 to-red-200 rounded-xl flex items-center justify-center shadow-sm">
        <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" />
      </div>
    )
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "completed":
        return "bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-green-300"
      case "approved":
      case "confirmed":
        return "bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-green-300"
      case "pending":
      case "processing":
        return "bg-gradient-to-r from-yellow-100 to-yellow-200 text-yellow-800 border-yellow-300"
      case "failed":
      case "blocked":
      case "cancelled":
        return "bg-gradient-to-r from-red-100 to-red-200 text-red-800 border-red-300"
      case "initiated":
        return "bg-gradient-to-r from-orange-100 to-orange-200 text-orange-800 border-orange-300"
      case "expired":
        return "bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300"
      case "rejected":
        return "bg-gradient-to-r from-red-100 to-red-200 text-red-800 border-red-300"
      default:
        return "bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300"
    }
  }

  const getAmountColor = (transaction) => {
    if (transaction.type === "deposit") {
      if (transaction.status === "initiated") {
        return "text-orange-600"
      }
      if (transaction.paymentStatus === "Underpaid") {
        return "text-red-600"
      }
      return "text-green-600"
    }
    if (transaction.type === "refund") {
      return "text-blue-600"
    }
    return "text-red-600"
  }

  const getUnderpaidStatusColor = (transaction) => {
    if (transaction.paymentStatus === "Underpaid") {
      return "bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300"
    }
    return getStatusColor(transaction.status)
  }

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction)
    setShowDetailsModal(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-3 sm:p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          {backButtonVisible && (
            <Button onClick={handleBackClick} variant="outline" icon={ChevronLeft} className="w-fit bg-transparent">
              Back
            </Button>
          )}
          <div className="text-center sm:text-right">
            <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
              All Transactions
            </h1>
            <p className="text-slate-600 text-sm sm:text-base">Manage your deposits, payouts, and refunds</p>
          </div>
        </div>

        {/* Tabs Section */}
        <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-slate-200/50 p-4 sm:p-6 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div className="flex space-x-2 sm:space-x-4">
              <button
                onClick={() => setSelectedTab("deposit")}
                className={`flex-1 sm:flex-none py-3 px-4 sm:px-6 rounded-xl font-semibold transition-all duration-300 text-sm sm:text-base ${
                  selectedTab === "deposit"
                    ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg transform scale-[1.02]"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span className="hidden sm:inline">💰 </span>Deposits
              </button>
              <button
                onClick={() => setSelectedTab("payout")}
                className={`flex-1 sm:flex-none py-3 px-4 sm:px-6 rounded-xl font-semibold transition-all duration-300 text-sm sm:text-base ${
                  selectedTab === "payout"
                    ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg transform scale-[1.02]"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span className="hidden sm:inline">💸 </span>Payouts
              </button>
              <button
                onClick={() => setSelectedTab("refund")}
                className={`flex-1 sm:flex-none py-3 px-4 sm:px-6 rounded-xl font-semibold transition-all duration-300 text-sm sm:text-base ${
                  selectedTab === "refund"
                    ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg transform scale-[1.02]"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span className="hidden sm:inline">🔄 </span>Withdraw
              </button>
            </div>
            {/* Filter Toggle Button */}
            <Button
              onClick={() => setShowFilters(!showFilters)}
              variant={showFilters ? "primary" : "outline"}
              icon={Filter}
              className="w-fit"
            >
              Filters
            </Button>
          </div>

          {/* Filters Section */}
          {showFilters && (
            <div className="bg-slate-50/80 rounded-xl p-4 sm:p-6 mb-6 border border-slate-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Date Filters */}
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-slate-700">
                    <Calendar className="inline w-4 h-4 mr-1" />
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={dateFilter.startDate}
                    onChange={(e) => setDateFilter((prev) => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-slate-700">
                    <Calendar className="inline w-4 h-4 mr-1" />
                    End Date
                  </label>
                  <input
                    type="date"
                    value={dateFilter.endDate}
                    onChange={(e) => setDateFilter((prev) => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-sm"
                  />
                </div>
                {/* Status Filter */}
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-slate-700">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-sm"
                  >
                    <option value="">All Statuses</option>
                    {getUniqueStatuses().map((status) => (
                      <option key={status} value={status}>
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>
                {/* Clear Filters Button */}
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-transparent">Actions</label>
                  <Button onClick={clearFilters} variant="outline" icon={RotateCcw} className="w-full bg-transparent">
                    Clear Filters
                  </Button>
                </div>
              </div>
              {/* Filter Summary */}
              {hasActiveFilters() && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800 font-medium">
                    Active Filters:
                    {dateFilter.startDate && (
                      <span className="ml-2 px-2 py-1 bg-blue-100 rounded text-xs">
                        From: {new Date(dateFilter.startDate).toLocaleDateString()}
                      </span>
                    )}
                    {dateFilter.endDate && (
                      <span className="ml-2 px-2 py-1 bg-blue-100 rounded text-xs">
                        To: {new Date(dateFilter.endDate).toLocaleDateString()}
                      </span>
                    )}
                    {statusFilter && (
                      <span className="ml-2 px-2 py-1 bg-blue-100 rounded text-xs">
                        Status: {statusFilter.charAt(0).toUpperCase() + statusFilter.slice(1)}
                      </span>
                    )}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="bg-gradient-to-r from-red-100 to-red-200 border border-red-300 text-red-800 px-4 py-3 rounded-xl mb-6 shadow-sm">
              <div className="flex items-center space-x-2">
                <span className="text-red-600">⚠️</span>
                <span className="font-medium">Error: {error}</span>
              </div>
            </div>
          )}

          {/* Transactions List */}
          <div>
            <div className="flex items-center justify-between mb-4 sm:mb-6">
              <h2 className="text-lg sm:text-xl font-bold text-slate-800">
                {selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)} Transactions
                {hasActiveFilters() && (
                  <span className="text-sm font-normal text-blue-600 ml-2">
                    ({filteredTransactions.length} of {allTransactions.length} shown)
                  </span>
                )}
              </h2>
              <div className="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                Page {currentPage} of {totalPages}
              </div>
            </div>

            {loading ? (
              <div className="text-center py-12 sm:py-16">
                <div className="animate-spin rounded-full h-10 w-10 sm:h-12 sm:w-12 border-b-3 border-blue-500 mx-auto"></div>
                <p className="text-slate-500 mt-4 text-sm sm:text-base">Loading transactions...</p>
              </div>
            ) : (
              <div className="space-y-3 sm:space-y-4">
                {displayedTransactions.length === 0 ? (
                  <div className="text-center py-12 sm:py-16">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <List className="w-8 h-8 sm:w-10 sm:h-10 text-slate-400" />
                    </div>
                    <p className="text-slate-500 text-base sm:text-lg font-medium">
                      {allTransactions.length === 0
                        ? `No ${selectedTab} transactions found`
                        : "No transactions match your filters"}
                    </p>
                    <p className="text-slate-400 text-sm sm:text-base mt-2">
                      {allTransactions.length === 0
                        ? "Your transactions will appear here once available"
                        : "Try adjusting your filter criteria"}
                    </p>
                  </div>
                ) : (
                  displayedTransactions.map((transaction) => (
                    <div
                      key={transaction._id}
                      className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white hover:shadow-lg hover:scale-[1.01] cursor-pointer transition-all duration-300"
                      onClick={() => handleTransactionClick(transaction)}
                    >
                      {/* Mobile Layout */}
                      <div className="block sm:hidden p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {getTransactionIcon(transaction.type, transaction.status)}
                            <div>
                              <div className="font-semibold text-slate-800 text-sm">
                                {transaction.type === "deposit"
                                  ? "Deposit"
                                  : transaction.type === "payout"
                                    ? "Payout"
                                    : "Refund"}
                              </div>
                              <div className="text-xs text-slate-500">
                                {transaction.walletAddress || transaction.clientWallet
                                  ? `${(transaction.walletAddress || transaction.clientWallet).substring(0, 8)}...`
                                  : "N/A"}
                              </div>
                            </div>
                          </div>
                          <Eye size={16} className="text-blue-600" />
                        </div>
                        <div className="flex justify-between items-center">
                          <span
                            className={`px-2 py-1 text-xs font-medium rounded-lg ${getUnderpaidStatusColor(transaction)}`}
                          >
                            {transaction.status.toUpperCase()}
                          </span>
                          <div className="text-right">
                            <div className={`font-bold text-sm ${getAmountColor(transaction)}`}>
                              ${transaction.displayAmount || "0.00"}
                            </div>
                            {transaction.type === "deposit" && transaction.actualBalance !== undefined && (
                              <div className="text-xs text-blue-600">Actual: ${transaction.actualBalance}</div>
                            )}
                          </div>
                        </div>
                        {transaction.type === "deposit" && transaction.paymentStatus && (
                          <div className="text-center">
                            <span
                              className={`text-xs font-semibold px-2 py-1 rounded-full ${
                                transaction.paymentStatus === "Overpaid"
                                  ? "bg-green-100 text-green-700"
                                  : transaction.paymentStatus === "Underpaid"
                                    ? "bg-red-100 text-red-700"
                                    : "bg-blue-100 text-blue-700"
                              }`}
                            >
                              {transaction.paymentStatus}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Desktop Layout */}
                      <div className="hidden sm:flex items-center justify-between p-4 sm:p-6">
                        <div className="flex items-center space-x-4">
                          {getTransactionIcon(transaction.type, transaction.status)}
                          <div className="space-y-1">
                            <div className="font-semibold text-slate-800">
                              {transaction.type === "deposit"
                                ? "Deposit"
                                : transaction.type === "payout"
                                  ? "Payout"
                                  : "Refund"}
                              {(transaction.status === "failed" || transaction.status === "rejected") &&
                                ` (${transaction.status})`}
                            </div>
                            <div className="text-slate-500 text-sm">
                              {transaction.walletAddress || transaction.clientWallet
                                ? `${(transaction.walletAddress || transaction.clientWallet).substring(0, 12)}...`
                                : "N/A"}
                            </div>
                            <div className="flex items-center space-x-4 text-xs text-slate-400">
                              <span>Status: {transaction.status}</span>
                              <span>•</span>
                              <span>{new Date(transaction.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right space-y-2">
                            <div className={`font-bold text-lg ${getAmountColor(transaction)}`}>
                              ${transaction.displayAmount || "0.00"}
                            </div>
                            {transaction.type === "deposit" &&
                              transaction.actualBalance !== undefined &&
                              transaction.status === "confirmed" && (
                                <div className="text-sm text-blue-600">Actual: ${transaction.actualBalance}</div>
                              )}
                            {transaction.type === "deposit" &&
                              transaction.paymentStatus &&
                              transaction.status === "confirmed" && (
                                <div className="text-sm">
                                  <span
                                    className={`font-semibold ${
                                      transaction.paymentStatus === "Overpaid"
                                        ? "text-green-700"
                                        : transaction.paymentStatus === "Underpaid"
                                          ? "text-red-700"
                                          : "text-blue-700"
                                    }`}
                                  >
                                    {transaction.paymentStatus}
                                  </span>
                                </div>
                              )}
                            {/* {(transaction.type === "payout" || transaction.type === "refund") &&
                              transaction.netAmount && (
                                <div className="text-sm text-red-600">
                                  Received: {transaction.netAmount.toFixed(3)} USDT
                                </div>
                              )} */}
                            <span
                              className={`inline-block px-3 py-1 text-xs font-medium rounded-lg ${getUnderpaidStatusColor(transaction)}`}
                            >
                              {transaction.status.toUpperCase()}
                            </span>
                          </div>
                          <Eye size={20} className="text-blue-600 hover:text-blue-800" />
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Pagination Controls */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mt-8 pt-6 border-t border-slate-200">
            <Button
              onClick={() => handlePageChange(-1)}
              disabled={currentPage === 1}
              variant={currentPage === 1 ? "secondary" : "primary"}
              icon={ChevronLeft}
              className="group"
            >
              <span className="hidden sm:inline">
                Previous {selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)}
              </span>
              <span className="sm:hidden">Previous</span>
            </Button>
            <div className="flex items-center space-x-3 px-4 py-2 bg-slate-100 rounded-xl border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-700">
                <span className="text-sm sm:text-base font-bold">
                  Page {currentPage} of {totalPages}
                </span>
              </div>
              {hasActiveFilters() && (
                <div className="hidden sm:flex items-center space-x-1">
                  <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                  <span className="text-xs text-blue-600 font-medium">Filtered: {filteredTransactions.length}</span>
                </div>
              )}
            </div>
            <Button
              onClick={() => handlePageChange(1)}
              disabled={
                !hasNextPage || (hasActiveFilters() && currentPage >= Math.ceil(filteredTransactions.length / limit))
              }
              variant={
                !hasNextPage || (hasActiveFilters() && currentPage >= Math.ceil(filteredTransactions.length / limit))
                  ? "secondary"
                  : "primary"
              }
              icon={ChevronRight}
              className="group"
            >
              <span className="hidden sm:inline">
                Next {selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)}
              </span>
              <span className="sm:hidden">Next</span>
              {/* <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 rotate-180 transition-transform duration-300 group-hover:translate-x-1" /> */}
            </Button>
          </div>
        </div>
      </div>

      {/* Transaction Details Modal */}
      {showDetailsModal && selectedTransaction && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white/95 backdrop-blur-lg rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 sm:p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-800">Transaction Details</h2>
                <p className="text-sm text-slate-600 mt-1">Complete transaction information</p>
              </div>
              <Button onClick={() => setShowDetailsModal(false)} variant="primary">
                Close Details
              </Button>
            </div>
            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div className="space-y-6 sm:space-y-8">
                {/* Status Banner */}
                <div className="text-center">
                  <span
                    className={`inline-block px-4 py-2 text-sm font-bold rounded-xl ${getStatusColor(selectedTransaction.status)}`}
                  >
                    {selectedTransaction.status.toUpperCase()}
                  </span>
                </div>
                {/* Basic Information */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  <div className="bg-slate-50 rounded-xl p-4">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      <Hash className="inline w-4 h-4 mr-1" />
                      Transaction ID
                    </label>
                    <p className="text-sm font-mono text-slate-800 break-all bg-white px-3 py-2 rounded-lg">
                      {selectedTransaction.transactionId || selectedTransaction.id}
                    </p>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      <DollarSign className="inline w-4 h-4 mr-1" />
                      Amount
                    </label>
                    <p className="text-lg font-bold text-slate-800">${selectedTransaction.amount}</p>
                  </div>
                  {selectedTransaction.actualBalance !== undefined &&
                    selectedTransaction.type === "deposit" &&
                    selectedTransaction.status === "confirmed" && (
                      <div className="bg-blue-50 rounded-xl p-4">
                        <label className="block text-sm font-semibold text-blue-700 mb-2">Actual Amount Received</label>
                        <p className="text-lg font-bold text-blue-800">${selectedTransaction.actualBalance}</p>
                      </div>
                    )}
                  {selectedTransaction.netAmount !== undefined && (
                    <div className="bg-green-50 rounded-xl p-4">
                      <label className="block text-sm font-semibold text-green-700 mb-2">Net Amount</label>
                      <p className="text-lg font-bold text-green-800">${selectedTransaction.netAmount}</p>
                    </div>
                  )}
                  {selectedTransaction.fee !== undefined && (
                    <div className="bg-red-50 rounded-xl p-4">
                      <label className="block text-sm font-semibold text-red-700 mb-2">Fee</label>
                      <p className="text-lg font-bold text-red-800">${selectedTransaction.fee}</p>
                    </div>
                  )}
                  <div className="bg-slate-50 rounded-xl p-4">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Currency Type</label>
                    <p className="text-sm font-medium text-slate-800">{selectedTransaction.currencyType}</p>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      <Wallet className="inline w-4 h-4 mr-1" />
                      Wallet Address
                    </label>
                    <p className="text-sm font-mono text-slate-800 break-all bg-white px-3 py-2 rounded-lg">
                      {selectedTransaction.walletAddress || selectedTransaction.clientWallet}
                    </p>
                  </div>
                </div>
                {/* Payment Status for Deposits */}
                {selectedTransaction.type === "deposit" &&
                  selectedTransaction.paymentStatus &&
                  selectedTransaction.status === "confirmed" && (
                    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 sm:p-6">
                      <label className="block text-sm font-semibold text-slate-700 mb-3">Payment Status</label>
                      <div className="text-center">
                        <span
                          className={`inline-block px-6 py-3 text-base font-bold rounded-xl ${
                            selectedTransaction.paymentStatus === "Overpaid"
                              ? "bg-green-100 text-green-800 border-2 border-green-300"
                              : selectedTransaction.paymentStatus === "Underpaid"
                                ? "bg-red-100 text-red-800 border-2 border-red-300"
                                : "bg-blue-100 text-blue-800 border-2 border-blue-300"
                          }`}
                        >
                          {selectedTransaction.paymentStatus}
                        </span>
                      </div>
                    </div>
                  )}
                {/* Timestamps */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  <div className="bg-slate-50 rounded-xl p-4">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      <Calendar className="inline w-4 h-4 mr-1" />
                      Created At
                    </label>
                    <p className="text-sm text-slate-800">{new Date(selectedTransaction.createdAt).toLocaleString()}</p>
                  </div>
                  {selectedTransaction.updatedAt && (
                    <div className="bg-slate-50 rounded-xl p-4">
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        <Calendar className="inline w-4 h-4 mr-1" />
                        Updated At
                      </label>
                      <p className="text-sm text-slate-800">
                        {new Date(selectedTransaction.updatedAt).toLocaleString()}
                      </p>
                    </div>
                  )}
                  {selectedTransaction.processedAt && (
                    <div className="bg-green-50 rounded-xl p-4">
                      <label className="block text-sm font-semibold text-green-700 mb-2">
                        <Calendar className="inline w-4 h-4 mr-1" />
                        Processed At
                      </label>
                      <p className="text-sm text-green-800">
                        {new Date(selectedTransaction.processedAt).toLocaleString()}
                      </p>
                    </div>
                  )}
                  {selectedTransaction.confirmedAt && (
                    <div className="bg-blue-50 rounded-xl p-4">
                      <label className="block text-sm font-semibold text-blue-700 mb-2">
                        <Calendar className="inline w-4 h-4 mr-1" />
                        Confirmed At
                      </label>
                      <p className="text-sm text-blue-800">
                        {new Date(selectedTransaction.confirmedAt).toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
                {/* Transaction Hash */}
                {(selectedTransaction.transactionHash ||
                  selectedTransaction.blockchainTxHash ||
                  selectedTransaction.adminTransferData?.transactionHash) && (
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 sm:p-6">
                    <label className="block text-sm font-semibold text-slate-700 mb-3">
                      <Hash className="inline w-4 h-4 mr-1" />
                      Transaction Hash
                    </label>
                    {(() => {
                      const hash =
                        selectedTransaction.transactionHash ||
                        selectedTransaction.blockchainTxHash ||
                        selectedTransaction.adminTransferData?.transactionHash
                      let explorerUrl = ""
                      if (selectedTransaction.currencyType === "USDT-TRC20") {
                        explorerUrl = `https://nile.tronscan.org/#/transaction/${hash}`
                      } else if (selectedTransaction.currencyType === "USDT-ERC20") {
                        explorerUrl = `https://sepolia.etherscan.io/tx/${hash}`
                      } else {
                        explorerUrl = "#"
                      }
                      return (
                        <div className="space-y-3">
                          <p className="text-sm font-mono text-slate-800 break-all bg-white px-3 py-2 rounded-lg border">
                            {hash}
                          </p>
                          <button
                            onClick={() => window.open(explorerUrl, "_blank")}
                            className="inline-flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-sm font-medium rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105"
                          >
                            <ExternalLink size={16} />
                            <span>View on Explorer</span>
                          </button>
                        </div>
                      )
                    })()}
                  </div>
                )}
                {/* Admin Notes */}
                {selectedTransaction.adminNotes && (
                  <div className="bg-yellow-50 rounded-xl p-4 sm:p-6">
                    <label className="block text-sm font-semibold text-yellow-800 mb-3">Admin Notes</label>
                    <p className="text-sm text-yellow-800 bg-white px-4 py-3 rounded-lg border border-yellow-200">
                      {selectedTransaction.adminNotes}
                    </p>
                  </div>
                )}
              </div>
            </div>
            {/* Modal Footer */}
            <div className="p-4 sm:p-6 border-t border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
              <div className="flex justify-end">
                <Button onClick={() => setShowDetailsModal(false)} variant="primary">
                  Close Details
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AllTransactions
