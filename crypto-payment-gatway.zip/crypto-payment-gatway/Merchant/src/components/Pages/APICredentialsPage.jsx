import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from 'react-router-dom';

import {
  Copy,
  Check,
  AlertCircle,
  ExternalLink,
  Eye,
  EyeOff,
  QrCode,
  Wallet,
  ChevronLeft,
  MessageSquare,
} from "lucide-react";

const APICredentialsPage = () => {
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [userId, setUserId] = useState("");
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedSecret, setCopiedSecret] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [apiResponse, setApiResponse] = useState(null);
  const [backButtonVisible, setBackButtonVisible] = useState(true);
   const navigate = useNavigate();
  const location = useLocation();

  // const API_BASE_URL = "http://localhost:5000/api/v1";
  const API_BASE_URL = 'https://backend.payglobal.co.in/api/v1';

  useEffect(() => {
    // Get user data from localStorage
    const getUserDataFromStorage = () => {
      try {
        const storedUserId = localStorage.getItem("userId");

        console.log("localStorage contents:", {
          userId: storedUserId,
          allKeys: Object.keys(localStorage),
        });

        if (
          !storedUserId ||
          storedUserId === "null" ||
          storedUserId === "undefined"
        ) {
          setError("User not logged in. Please login first.");
          setLoading(false);
          return null;
        }

        setUserId(storedUserId);
        console.log("Retrieved user data from localStorage:", {
          userId: storedUserId,
        });

        return storedUserId;
      } catch (error) {
        console.error("Error retrieving user data from localStorage:", error);
        setError("Failed to retrieve user data");
        setLoading(false);
        return null;
      }
    };

    // Fetch API Key using the logged-in user's ID
    const fetchApiKey = async () => {
      const currentUserId = getUserDataFromStorage();

      if (!currentUserId) {
        console.log("No valid user ID found, stopping API call");
        return;
      }

      console.log("Making API call with userId:", currentUserId);

      try {
        const response = await fetch(
          `${API_BASE_URL}/merchant/${currentUserId}`,
          {
            method: "GET",
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        console.log("Response status:", response.status);
        console.log("Response headers:", [...response.headers.entries()]);

        if (!response.ok) {
          throw new Error(
            `Failed to fetch API key: ${response.status} ${response.statusText}`
          );
        }

        const data = await response.json();
        console.log("Full API response data:", data);
        setApiResponse(data);

        // Try different possible locations for the API key and secret
        let foundApiKey = null;
        let foundApiSecret = null;

        // Check for API Key
        if (data && data.apiKey) {
          foundApiKey = data.apiKey;
        } else if (data && data.data && data.data.apiKey) {
          foundApiKey = data.data.apiKey;
        } else if (data && data.merchant && data.merchant.apiKey) {
          foundApiKey = data.merchant.apiKey;
        } else if (data && data.api_key) {
          foundApiKey = data.api_key;
        } else if (data && data.key) {
          foundApiKey = data.key;
        }

        // Check for API Secret
        if (data && data.apiSecret) {
          foundApiSecret = data.apiSecret;
        } else if (data && data.data && data.data.apiSecret) {
          foundApiSecret = data.data.apiSecret;
        } else if (data && data.merchant && data.merchant.apiSecret) {
          foundApiSecret = data.merchant.apiSecret;
        } else if (data && data.api_secret) {
          foundApiSecret = data.api_secret;
        } else if (data && data.secret) {
          foundApiSecret = data.secret;
        }

        let hasErrors = false;
        let errorMessages = [];

        if (foundApiKey) {
          setApiKey(foundApiKey);
        } else {
          hasErrors = true;
          errorMessages.push("API Key not found in response");
        }

        if (foundApiSecret) {
          setApiSecret(foundApiSecret);
        } else {
          hasErrors = true;
          errorMessages.push("API Secret not found in response");
        }

        if (hasErrors) {
          setError(
            errorMessages.join(". ") + ". Check the API response structure."
          );
          console.log("Available keys in response:", Object.keys(data));
        } else {
          setError("");
        }
      } catch (error) {
        console.error("Error fetching API key:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchApiKey();
  }, []);

   const handleBackClick = () => {
    navigate(-1); // navigate one step back in history
  };

  useEffect(() => {
    if (location.pathname === "/dashboard") {
      setBackButtonVisible(false);
    } else {
      setBackButtonVisible(true);
    }
  }, [location.pathname]);

  // Copy to clipboard function
  const copyToClipboard = async (text, type) => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === "key") {
        setCopiedKey(true);
        setTimeout(() => setCopiedKey(false), 2000);
      } else if (type === "secret") {
        setCopiedSecret(true);
        setTimeout(() => setCopiedSecret(false), 2000);
      } else if (type === "url") {
        setCopiedUrl(true);
        setTimeout(() => setCopiedUrl(false), 2000);
      }
    } catch (error) {
      console.error(`Failed to copy ${type}:`, error);
    }
  };

  // Generate QR Generator URL
  const generateQRGeneratorUrl = () => {
    const baseUrl = "https://gateway.payglobal.co.in";
    // const baseUrl = "http://localhost:3003";

    return `${baseUrl}/qr-generator?api_key=${apiKey}&api_secret=${apiSecret}`;
  };

  // Open QR Generator in new tab
  const openQRGenerator = () => {
    if (apiKey && apiSecret) {
      window.open(generateQRGeneratorUrl(), "_blank");
    }
  };

  const Button = ({
  onClick,
  children,
  variant = "primary",
  disabled = false,
  icon: Icon,
  className = "", // Add this line to ensure className can be passed
}) => {
  const baseClasses =
    "flex items-center justify-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed";
  const variants = {
    primary:
      "bg-purple-600 hover:bg-purple-700 text-white shadow-lg hover:shadow-purple-500/25",
    success:
      "bg-green-600 hover:bg-green-700 text-white shadow-lg hover:shadow-green-500/25",
    danger:
      "bg-red-600 hover:bg-red-700 text-white shadow-lg hover:shadow-red-500/25",
    outline:
      "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variants[variant]} ${className}`} // className passed here
    >
      {Icon && <Icon className="w-5 h-5" />}
      <span>{children}</span>
    </button>
  );
};

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-4">
          {backButtonVisible && (
            <Button
              onClick={handleBackClick}
              variant="outline"
              icon={ChevronLeft}
              className="mr-3"
            >
              Back
            </Button>
          )}
        </div>
        {/* Header */}
        <div className="text-center mb-8">
          <div className="bg-blue-600 text-white rounded-2xl p-8 shadow-xl">
            <div className="bg-white/20 backdrop-blur-sm rounded-full p-4 w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <Wallet className="w-10 h-10" />
            </div>
            <h1 className="text-4xl font-bold mb-2">API Credentials</h1>
            <p className="text-blue-100 text-lg">
              Your gateway to cryptocurrency payment processing
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - Credentials */}
          <div className="space-y-6">
            {/* API Credentials Card */}
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8">
              <div className="flex items-center mb-6">
                <div className="bg-blue-100 rounded-full p-3 mr-4">
                  <Wallet className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    Your API Credentials
                  </h2>
                  <p className="text-gray-600">
                    Use these to authenticate with our payment API
                  </p>
                </div>
              </div>

              {/* User ID Display */}
              {userId && (
                <div className="mb-6 p-4 bg-gray-50 rounded-xl">
                  <span className="text-sm font-semibold text-gray-700">
                    User ID:{" "}
                  </span>
                  <span className="text-sm font-mono text-gray-900">
                    {userId}
                  </span>
                </div>
              )}

              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                  <span className="ml-3 text-gray-700 font-medium">
                    Loading your credentials...
                  </span>
                </div>
              ) : error ? (
                <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6">
                  <div className="flex items-center text-red-700 mb-3">
                    <AlertCircle className="w-5 h-5 mr-2" />
                    <span className="font-semibold">
                      Error Loading Credentials
                    </span>
                  </div>
                  <p className="text-red-600 text-sm">{error}</p>
                  {apiResponse && (
                    <details className="mt-4">
                      <summary className="text-sm font-medium cursor-pointer">
                        Debug Info
                      </summary>
                      <div className="mt-2 text-xs font-mono bg-gray-100 p-2 rounded">
                        Available fields: {Object.keys(apiResponse).join(", ")}
                      </div>
                    </details>
                  )}
                </div>
              ) : (
                <div className="space-y-6">
                  {/* API Key */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      API Key
                    </label>
                    <div className="flex items-center">
                      <div className="flex-1 p-4 bg-gray-50 border-2 border-gray-200 rounded-l-xl font-mono text-sm">
                        {apiKey || "YOUR_API_KEY_HERE"}
                      </div>
                      <button
                        onClick={() => copyToClipboard(apiKey, "key")}
                        className="bg-blue-600 text-white px-4 py-4 rounded-r-xl hover:bg-blue-700 transition-colors border-2 border-blue-600"
                        title="Copy API key"
                        disabled={!apiKey}
                      >
                        {copiedKey ? (
                          <Check className="w-5 h-5 text-green-200" />
                        ) : (
                          <Copy className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* API Secret */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      API Secret
                    </label>
                    <div className="flex items-center">
                      <div className="flex-1 p-4 bg-gray-50 border-2 border-gray-200 rounded-l-xl font-mono text-sm">
                        {showSecret
                          ? apiSecret || "YOUR_API_SECRET_HERE"
                          : "••••••••••••••••••••••••••••••••"}
                      </div>
                      <button
                        onClick={() => setShowSecret(!showSecret)}
                        className="bg-gray-600 text-white px-4 py-4 hover:bg-gray-700 transition-colors border-2 border-gray-600"
                        title={showSecret ? "Hide secret" : "Show secret"}
                      >
                        {showSecret ? (
                          <EyeOff className="w-5 h-5" />
                        ) : (
                          <Eye className="w-5 h-5" />
                        )}
                      </button>
                      <button
                        onClick={() => copyToClipboard(apiSecret, "secret")}
                        className="bg-blue-600 text-white px-4 py-4 rounded-r-xl hover:bg-blue-700 transition-colors border-2 border-blue-600"
                        title="Copy API secret"
                        disabled={!apiSecret}
                      >
                        {copiedSecret ? (
                          <Check className="w-5 h-5 text-green-200" />
                        ) : (
                          <Copy className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Security Warning */}
                  <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4">
                    <div className="flex items-center text-red-700 mb-2">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      <span className="font-semibold">Security Warning</span>
                    </div>
                    <p className="text-red-600 text-sm">
                      Keep these credentials secure and never share them
                      publicly. Store them safely in environment variables.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Start Card */}
            {apiKey && apiSecret && (
              <div className="bg-blue-600 rounded-2xl shadow-xl p-8 text-white">
                <div className="flex items-center mb-6">
                  <QrCode className="w-8 h-8 mr-3" />
                  <div>
                    <h3 className="text-xl font-bold">Quick Start</h3>
                    <p className="text-green-100">
                      Test your API credentials instantly
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <button
                    onClick={openQRGenerator}
                    className="w-full bg-white text-green-700 py-4 px-6 rounded-xl font-bold hover:bg-gray-100 transition-colors flex items-center justify-center"
                  >
                    <QrCode className="w-5 h-5 mr-2" />
                    Open QR Code Generator
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </button>

                  <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
                    <p className="text-sm text-green-100 mb-2">
                      Or copy the direct URL:
                    </p>
                    <div className="flex items-center">
                      <code className="flex-1 text-xs bg-black/20 p-2 rounded text-green-100 truncate">
                        {generateQRGeneratorUrl()}
                      </code>
                      <button
                        onClick={() =>
                          copyToClipboard(generateQRGeneratorUrl(), "url")
                        }
                        className="ml-2 bg-white/20 text-white p-2 rounded hover:bg-white/30 transition-colors"
                      >
                        {copiedUrl ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Best Practices */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-blue-900 mb-4">
                Best Practices
              </h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    1
                  </div>
                  <p className="text-blue-800 text-sm">
                    Always use HTTPS in production environments
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    2
                  </div>
                  <p className="text-blue-800 text-sm">
                    Store API credentials securely using environment variables
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    3
                  </div>
                  <p className="text-blue-800 text-sm">
                    Never expose API secrets in client-side code
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    4
                  </div>
                  <p className="text-blue-800 text-sm">
                    Implement proper error handling for all API calls
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                    5
                  </div>
                  <p className="text-blue-800 text-sm">
                    Handle transaction timeouts and API response errors
                    gracefully
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Documentation */}
          <div className="space-y-6">
            {/* API Documentation */}
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                API Documentation
              </h3>

              <div className="space-y-6">
                {/* Base URL */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">Base URL</h4>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <code className="text-sm font-mono text-gray-900">
                      {API_BASE_URL}
                    </code>
                  </div>
                </div>

                {/* Authentication */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Authentication
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Include your API key and secret in the headers:
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <pre className="text-xs font-mono text-gray-900 whitespace-pre-wrap">
                      {`Headers:
Content-Type: application/json
x-api-secret: ${apiSecret || "YOUR_API_SECRET"}
apiKey: ${apiKey || "YOUR_API_KEY"}`}
                    </pre>
                  </div>
                </div>

                {/* Create Transaction */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Create Transaction
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Generate a payment link for cryptocurrency transactions:
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <pre className="text-xs font-mono text-gray-900 whitespace-pre-wrap">
                      {`GET /transaction/create?amount=100.00&currencyType=USDT-ERC20&callbackUrl=https://example.com/callback

Headers:
Content-Type: application/json
x-api-secret: ${apiSecret || "YOUR_API_SECRET"}
apiKey: ${apiKey || "YOUR_API_KEY"}

Query Parameters:
• amount: Payment amount (required)
• currencyType: USDT-ERC20 or USDT-TRC20 (required)
• callbackUrl: URL for payment callbacks (optional)

Response:
{
  "success": true,
  "url": "https://payment-link.com/pay/...",
  "transactionId": "tx_123456789"
}

Error Response:
{
  "success": false,
  "error": "Error message",
  "message": "Detailed error description"
}`}
                    </pre>
                  </div>
                </div>

                {/* Submit Refund/Withdrawal */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Submit Refund/Withdrawal Request
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    File a refund or withdrawal request:
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <pre className="text-xs font-mono text-gray-900 whitespace-pre-wrap">
                      {`POST /refund

Headers:
Content-Type: application/json
x-api-secret: ${apiSecret || "YOUR_API_SECRET"}
apiKey: ${apiKey || "YOUR_API_KEY"}

Body:
{
  "walletAddress": "0x123...",
  "amount": "100.00",
  "subject": "Withdrawal Request",
  "message": "Transaction details",
  "currencyType": "USDT-ERC20"
}

Required Fields:
• walletAddress: Wallet address for refund/withdrawal

Optional Fields:
• amount: Transaction amount
• subject: Request subject
• message: Detailed message
• currencyType: USDT-ERC20 or USDT-TRC20

Response:
{
  "success": true,
  "message": "Request submitted successfully"
}

Error Response:
{
  "success": false,
  "message": "Error description"
}`}
                    </pre>
                  </div>
                </div>

                {/* Currency Types */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Supported Currency Types
                  </h4>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <pre className="text-xs font-mono text-gray-900 whitespace-pre-wrap">
                      {`Available Currency Types:
• USDT-ERC20: USDT on Ethereum network
• USDT-TRC20: USDT on Tron network

Usage:
Pass currencyType parameter in transaction creation
and refund/withdrawal requests.`}
                    </pre>
                  </div>
                </div>

                {/* Error Handling */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Error Handling
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Common error scenarios and how to handle them:
                  </p>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <pre className="text-xs font-mono text-gray-900 whitespace-pre-wrap">
                      {`Common Error Codes:
• 400: Bad Request - Invalid parameters
• 401: Unauthorized - Invalid API credentials
• 500: Internal Server Error - Server issue

Error Response Format:
{
  "success": false,
  "error": "Short error code",
  "message": "Detailed error message"
}

Best Practices:
• Always check the 'success' field in response
• Handle both 'error' and 'message' fields
• Implement retry logic for 5xx errors
• Validate parameters before API calls`}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default APICredentialsPage;