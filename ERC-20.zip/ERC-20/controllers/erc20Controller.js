var Web3 = require('web3');
const bip39 = require('bip39');
const { hdkey } = require('ethereumjs-wallet');
const ethers = require('ethers');

const web3 = new Web3("https://sepolia.infura.io/v3/93803746869e45eeadc114df056fe2a1");
// const web3 = new Web3("https://go.getblock.io/70838a4b71774d1896abef492006a0dd");

const { contractABI } = require("../config/erc20");
const mnemonic = "uncover slide spray lab gospel echo brush enable stairs quick truck verify";

module.exports = {

    generateMnemonic: async (req, res) => {
        try {
            let mnemonic = bip39.generateMnemonic();
            return res.status(200).send({ responseCode: 200, responseMessage: "Generated.", responseResult: mnemonic });
        } catch (error) {
            return res.status(501).send({ responseMessage: "Couldn't Generate Wallet", responseResult: error });
        }
    },

    generateAddress: (req, res) => {
        try {
            const seed = bip39.mnemonicToSeedSync(req.query.mnemonic)

            let hdwallet = hdkey.fromMasterSeed(seed);
            let countvalue = req.query.count ? req.query.count : 0;
            let path = `m/44'/60'/0'/0/${countvalue}`;

            let wallet = hdwallet.derivePath(path).getWallet();
            let address = "0x" + wallet.getAddress().toString("hex");
            let privateKey = wallet.getPrivateKey().toString("hex");
            res.send({ responseCode: 200, responseMessage: "Account Created successfully.", responseResult: { address: address, privateKey: privateKey } });
            // return { address, privateKey };
        } catch (error) {
            console.log(error)
            res.send({ responseCode: 501, responseMessage: "Something went wrong!!!", responseResult: error.message });
        }

    },

    getBalance: async (req, res) => {
        try {
            if (!req.query.address) {
                return res.status(404).json({ Message: `Invalid payment details.` })
            }
            const myContract = new web3.eth.Contract(contractABI, req.query.contract);
            var userBalance = await myContract.methods.balanceOf(req.query.address).call();
            const decimals = await myContract.methods.decimals().call()
            userBalance = ethers.utils.formatUnits(userBalance, decimals)
            return res.status(200).send({ responseCode: 200, responseMessage: "Balance fetched successfully.", responseResult: { balance: Number(userBalance) } });
        } catch (error) {

            return res.status(501).send({ responseCode: 501, responseMessage: "Something went wrong!", error: error.message })

        }
    },

    withdraw: async (req, res) => {
        try {
            if (!req.body.recieverAddress || !req.body.privateKey || !req.body.amountToSend) {
                return res.status(404).json({ Message: `Invalid payment details.` })
            }
            let { recieverAddress, privateKey, amountToSend,contract } = req.body;
            const myContract = new web3.eth.Contract(contractABI, contract);
            const decimals = await myContract.methods.decimals().call()
            const balance = ethers.utils.parseUnits(amountToSend.toString(), decimals);

            const Data = await myContract.methods.transfer(recieverAddress, balance.toString()).encodeABI();

            const rawTransaction = {
                to: contract,
                gasPrice: web3.utils.toHex('30000000000'), // Always in Wei (30 gwei)
                gasLimit: web3.utils.toHex('200000'), // Always in Wei
                data: Data // Setting the pid 12 with 0 alloc and 0 deposit fee
            };
            console.log("rawTransaction==>>", rawTransaction)
            console.log("privateKey====>>", privateKey)
            const signPromise = await web3.eth.accounts.signTransaction(rawTransaction, privateKey.toString());
            console.log("signPromise====>", signPromise);

            web3.eth.sendSignedTransaction(signPromise.rawTransaction).then((data) => {
                console.log({ responseCode: 200, Status: "Success", Hash: signPromise.transactionHash });
                return res.status(200).json({ responseCode: 200, responseMessage: "Success", responseResult: data });
            }).catch((error) => {

                console.log({ responseCode: 501, responseMessage: "Something went wrong!", error: error });

                res.status(501).send({ responseCode: 501, responseMessage: "Something went wrong!", error: error });
            })

        } catch (error) {
            console.log("error==>>", error);
            return res.status(501).send({ responseCode: 501, responseMessage: "Something went wrong!", error: error.message })

        }
    },

    transfer: async (req, res) => {
        try {
            if (!req.body.senderAddress || !req.body.recieverAddress || !req.body.privateKey) {
                return res.status(404).json({ Message: `Invalid payment details.` })
            }
            let { senderAddress, recieverAddress, privateKey, contract } = req.body;
            const myContract = new web3.eth.Contract(contractABI, contract);
            var balance = await myContract.methods.balanceOf(senderAddress).call();

            const Data = await myContract.methods.transfer(recieverAddress, balance.toString()).encodeABI();

            const rawTransaction = {
                to: contract,
                gasPrice: web3.utils.toHex('30000000000'), // Always in Wei (30 gwei)
                gasLimit: web3.utils.toHex('200000'), // Always in Wei
                data: Data // Setting the pid 12 with 0 alloc and 0 deposit fee
            };
            const signPromise = await web3.eth.accounts.signTransaction(rawTransaction, privateKey.toString());


            web3.eth.sendSignedTransaction(signPromise.rawTransaction).then((data) => {


                console.log({ responseCode: 200, Status: "Success", Hash: signPromise.transactionHash });
                return res.status(200).json({ responseCode: 200, responseMessage: "Success", responseResult: data });

            }).catch((error) => {

                console.log({ responseCode: 501, responseMessage: "Something went wrong!", error: error });

                res.status(501).send({ responseCode: 501, responseMessage: "Something went wrong!", error: error });

            })

        } catch (error) {
            return res.status(501).send({ responseCode: 501, responseMessage: "Something went wrong!", error: error.message })

        }
    }

}



