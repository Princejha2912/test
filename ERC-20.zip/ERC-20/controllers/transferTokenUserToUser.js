const axios = require('axios')
const bip39 = require('bip39')
const ethers = require('ethers');
require('dotenv').config();

const RPC = 'https://sepolia.infura.io/v3/93803746869e45eeadc114df056fe2a1'; // testnet

const Web3 = require("web3");
const EthereumTx = require('ethereumjs-tx').Transaction;
const Common = require('ethereumjs-common');
const { hdkey } = require('ethereumjs-wallet');
var web3 = new Web3(new Web3.providers.HttpProvider(RPC));
const { contractABI } = require("../config/erc20");
const mnemonic = "uncover slide spray lab gospel echo brush enable stairs quick truck verify";

const AdminAddress = process.env.AdminAddress;
const AdminPrivateKey = process.env.AdminPrivateKey;

const getCurrentGasPrices = async () => {
    try {
        const gasPrice = await web3.eth.getGasPrice();
        return Number(gasPrice); // in wei
    } catch (error) {
        console.error("Gas price fetch error:", error);
        return 10 * 1e9; // fallback to 10 Gwei
    }
};

const EthHelper = async () => {
    let gasPrice = await getCurrentGasPrices();
    let gasLimit = 21000;
    let fee = gasLimit * gasPrice;
    let txFee = Number(web3.utils.fromWei(fee.toString(), "ether"));
    return { fee: txFee, gasPrice: gasPrice };
};
    

const accountBalance = async (senderAddress) => {
    try {
        const response = await web3.eth.getBalance(senderAddress);
        let balance = web3.utils.fromWei(response, "ether")
        return Number(balance)
    } catch (error) {
        console.log("accountBalance catch err==>>>", error);
    }

}

const preETHTransfer = async (senderAddress, amountToSend) => {
    const { fee } = await EthHelper()
    let balance = await accountBalance(senderAddress)
    if (balance - amountToSend - fee < 0) {
        console.log('insufficient funds', balance);
        return { status: false, message: 'Low Balance', balance: balance }
    } else {
        return { status: true, message: 'Transfer Possible' }

    }

}

const transferAdminToUserForGasFee = async (adminAddress, adminPrivateKey, userAddress, amountToSend) => {
    try {
        var nonce = await web3.eth.getTransactionCount(adminAddress);
        const { gasPrice } = await EthHelper(adminAddress, amountToSend);
        console.log("gass Price", gasPrice);
        const { status } = await preETHTransfer(adminAddress, amountToSend);

        if (status == false) {
            return ({ responseCode: 404, responseMessage: "Low Balance.", responseResult: [] });
        }

        let txObject = {
            to: userAddress,
            value: web3.utils.toHex(
                web3.utils.toWei(amountToSend.toString(), "ether")
            ),
            gasLimit: 21000,
            gasPrice: gasPrice,
            nonce: nonce,
        };

        const common = Common.default.forCustomChain(
                'mainnet', {
                name: 'sepolia',
                networkId: "0xAA36A7", // testnet  
                chainId: "0xAA36A7",   // testnet
            },
                "petersburg",
            );

        const transaction = new EthereumTx(txObject, { common: common });
        let privKey = Buffer.from(adminPrivateKey, "hex");
        transaction.sign(privKey);
        const serializedTransaction = transaction.serialize();
        const raw = "0x" + Buffer.from(serializedTransaction).toString("hex");
        const signTransaction = await web3.eth.sendSignedTransaction(raw);
        console.log({
            responseCode: 200,
            Status: "Success",
            Hash: signTransaction.transactionHash,
        });
        return {
            Status: true,
            Hash: signTransaction.transactionHash,
            message: "Success",
        };
    } catch (error) {
        console.log("error", error);
        return {
            Status: false,
            message: "Something went wrong!",
        };
    }
}

const tokenTransferUserToUser = async (recieverAddress, privateKey, amountToSend, contract) => {
    try {
        if (recieverAddress || privateKey || amountToSend) {
        }
        const myContract = new web3.eth.Contract(contractABI, contract);
        const decimals = await myContract.methods.decimals().call()
        const balance = ethers.utils.parseUnits(amountToSend.toString(), decimals);
        const Data = await myContract.methods.transfer(recieverAddress, balance.toString()).encodeABI();
        const rawTransaction = {
            to: contract,
            gasPrice: web3.utils.toHex('30000000000'), // Always in Wei (30 gwei)
            gasLimit: web3.utils.toHex('200000'), // Always in Wei
            data: Data // Setting the pid 12 with 0 alloc and 0 deposit fee
        };
        const signPromise = await web3.eth.accounts.signTransaction(rawTransaction, privateKey.toString());
        let data = await web3.eth.sendSignedTransaction(signPromise.rawTransaction)
        if (data) {
            console.log({ responseCode: 200, Status: "Success", Hash: signPromise.transactionHash });
            return { responseCode: 200, responseMessage: "Success", responseResult: data };
        }
    }
    catch (error) {
        console.log({ responseCode: 501, responseMessage: "Something went wrong!", error: error.message })

    }
}

const remeningAmountTransferToAdmin = async (senderAddress, privateKey, recieverAddress) => {
    try {
        var nonce = await web3.eth.getTransactionCount(senderAddress);
        const { fee, gasPrice } = await EthHelper()
        let balance = await accountBalance(senderAddress)
        console.log('sender balance ==>', balance)
        let amountToSend = balance - fee;
        if (amountToSend > 0) {
            let txObject = {
                "to": recieverAddress,
                "value": web3.utils.toHex(web3.utils.toWei(amountToSend.toString(), 'ether')),
                "gas": 21000,
                "gasPrice": gasPrice,
                "nonce": nonce,
            };
            const common = Common.default.forCustomChain(
                'mainnet', {
                name: 'sepolia',
                networkId: "0xAA36A7", // testnet  
                chainId: "0xAA36A7",   // testnet
            },
                "petersburg",
            );
            const transaction = new EthereumTx(txObject, { common: common });
            let privKey = Buffer.from(privateKey, 'hex');
            transaction.sign(privKey);
            const serializedTransaction = transaction.serialize();
            const signTransaction = await web3.eth.sendSignedTransaction('0x' + serializedTransaction.toString('hex'))
            console.log(signTransaction.transactionHash);
            console.log({ responseCode: 200, Status: "Transfer Successful", responseResult: signTransaction });
            return { responseCode: 200, Status: "Transfer Successful", responseResult: signTransaction };
        } else {
            console.log({ status: true, message: 'Transfer Possible' });
            return { responseCode: 200, status: true, message: 'Transfer Possible' };
        }
    } catch (error) {
        console.log({ responseCode: 501, responseMessage: "Something went wrong!", responseResult: error })
        return { responseCode: 501, responseMessage: "Something went wrong!", responseResult: error };
    }
}


const deposit = async (req, res) => {
    try {
        if(req.body.token<=0){
            return res.send({responseCode:401,responseMessage:'Please provide token value must be greater then to 0.'})
        }
        let tranferETH = 0.01;
        let result1 = await transferAdminToUserForGasFee(AdminAddress, AdminPrivateKey, req.body.senderAddress, tranferETH);
        if (result1 && result1.Status == true) {
            let result2 = await tokenTransferUserToUser(req.body.receiverAddress, req.body.senderPrivateKey, req.body.token, req.body.contract)
            if (result2 && result2.responseCode == 200) {
                let data = await remeningAmountTransferToAdmin(req.body.senderAddress, req.body.senderPrivateKey, AdminAddress)
                if (data) {
                    console.log('249 ==>', data);
                    return res.send({ responseCode: 200, responseMessage: 'Success', responseResult: data.responseResult });
                }
            }
        }

    } catch (error) {
        console.log(error)
        return res.send({ responseCode: 501, responseMessage: "Something went wrong!", responseResult: error.message });
    }
}

module.exports = { deposit }

